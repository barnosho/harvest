# Harvest: state machines

This file covers every piece of state in Harvest that changes over time, version 1.17. Some of these state machines are explicit (a flag or a status column). Most are implicit: a handful of variables that only make sense together. For each one it lists the states, the rules that must always hold (invariants), and every transition with the code that performs it. The second half lists the invalid states the code could actually reach, how each was confirmed, how it was fixed, and the test that guards it.

**Keeping this file current.** When a change adds a variable, a meta key, a column or a new way into or out of a state, update the table for that machine. A new bug gets the next issue number, and its test in `StateMachines.kt` carries the same number. Code is referred to by function name, not line number, because line numbers drift.

Persisted state lives in the `meta` table of `harvest.db`, read by `Db.get` / `Db.set`. Key names are given in `code` style below.

---

## Part 1: the machines

### M1. Knock mode (explicit flag, implicit sub-states)

This is the main loop of the app. `knocking` is the flag; which sub-state you're in follows from `rowKey`, `insideId`, `againMode` and whether `currentStop()` returns a house.

| State | Defined by | What's on screen |
|---|---|---|
| Planning | `knocking = false` | Map with the plan card and nav bar |
| Walking a row | `knocking`, `insideId = null`, `currentStop() != null` | Knock panel on a house or a flat entrance |
| Inside a flat | `knocking`, `insideId != null`, a home inside still open | Knock panel walking the homes inside |
| Flat done | `knocking`, `insideId != null`, nothing open inside | "Everyone in this flat is done" |
| Row done | `knocking`, `insideId = null`, `currentStop() == null` | End-of-row view: across the street, next row, second try |
| Neighbourhood done | Row done and `Next.choose` returns nothing | "… is done", Choose where next |

Second try (`againMode`) is a modifier on every knocking state; see M3.

**Persisted:** `knocking`, `row`, `asc`, `inside`, `again`, `anchor`, `last`, `sel`, `skipped`, `walkAt`. In memory only: `flash` and `flashStop` (the line confirming the last tap, and the house its "change" link goes back to), `hintId`, `switchOffer`, `focusedId`.

**Invariants**
1. `knocking` is true exactly while an outing is under way. Every way out goes through `endWalk`, which ends the session (M2), releases the street claim (M13), ends a second try, and settles lock-screen visibility (M9).
2. While knocking, `rowKey` names a row that exists. When the data changes, `applyData` re-resolves the row through `selectedId` or `rowAnchor`; if it can't, `buildKnockOverlay` ends the walk through `endWalk(LATER)`.
3. The current house survives a rebuild of the activity or the process being killed: `selectedId` and `skipped` are written by `persistPosition` every time the panel is drawn.
4. The walking direction `asc` points away from the last house recorded in this row (`lastId`). At the start of a row, before anything is recorded, it points toward the longer stretch of open houses.
5. "Next" never jumps to the far start of the row: after the last open house in your direction, it takes the nearest open house behind you and turns round (`findNext` / `advanceFrom`).
6. A walk untouched for `STALE_WALK` (8 h, measured by `walkAt`) is over. `onStart` ends it with `endWalk(NOW)`.

**Transitions**

| From | Event | To | Code |
|---|---|---|---|
| Planning | Start knocking / Start at N | Walking (at the tapped house, else the open one nearest you) | `knockRow` → `enterRow` → `startKnocking` |
| Planning | Try the N not-home homes again (plan card) | Walking, second try | `knockRow(again = true)` → `beginAgain` |
| Walking | Not home / Not interested / We talked → outcome | Walking at the next house, or Row done | `record` → `advanceFrom` |
| Walking | Tap a house of this row on the map, or take the GPS hint | Walking at that house; direction follows you if it's open | `pick` / status tap → `jumpTo` |
| Walking | ‹ › arrows | Walking at the neighbour; direction unchanged | `stepTo` |
| Walking | Tap "… · change" on the confirmation line | Walking at the house just recorded; the next outcome replaces its old one, then the walk continues where you were | `updateStatus` → `record` (replacing) |
| Walking | Tap a house in another row → Switch to | Walking that row | `pick` → `switchOffer` → `startAt` |
| Walking | More → Skip | Walking at the next house; the skipped one waits for the end | `skip` |
| Walking | More → Walk the other way | Walking, `asc` flipped | `moreSheet` |
| Walking at a flat | Go inside | Inside a flat | `buildKnockOverlay` |
| Inside a flat | Last open home recorded | Flat done | `record` |
| Inside / Flat done | Back to the street | Walking at the next stop after the flat | `endOfRow`, `moreSheet` |
| Row done | Across the street / Next: … | Walking the next row | `endOfRow` → `enterRow` |
| Row done | Try the N not-home homes again | Walking, second try, from the not-home house nearest you | `endOfRow` → `beginAgain` → `enterRow` |
| Row done (second try) | Back to new homes | Walking, normal | `endOfRow` |
| Neighbourhood done | Choose where next | Planning, neighbourhood layer on | `finishKnocking` |
| Any knocking state | Finish (button or back) → confirm | Planning | `confirmFinish` → `finishKnocking` → `endWalk(UNLOCK)` |
| Any knocking state | Data changed and the row can't be found | Planning | `buildKnockOverlay` → `endWalk(LATER)` |
| Any knocking state | App comes to the front with `walkAt` older than 8 h | Planning | `onStart` → `endWalk(NOW)` |
| Any | Activity rebuilt (dark-mode switch, process death) | The same state, the same house | `onCreate` restores the persisted keys |

### M2. Outing session (database table `session`)

| State | Defined by |
|---|---|
| None | No row with `ended = 0` for this user |
| Open | `ended = 0`, last knock under 1 hour ago |
| Gone quiet | `ended = 0`, last knock 1 hour or more ago |
| Ended | `ended = 1` |

**Invariants:** at most one open session per user. Every visit row carries the session it belongs to.

| From | Event | To | Code |
|---|---|---|---|
| None / Ended | First knock | Open | `Db.record` → `sessionFor` |
| Open | Knock | Open (`last` moves on) | `sessionFor` |
| Gone quiet | Knock | Old one Ended, a new one Open | `sessionFor` |
| Any | Finish or any other end of a walk | Ended | `endWalk` → `Db.endSession` |
| Any | Erase recorded knocks | All rows deleted | `Db.eraseKnocks` |
| Any | A teammate's row arrives by sync | Stored (newest `updated` wins) | `Db.applyRemote` |

### M3. A home's state this round (derived from visits)

`Db.doors` folds the visit log into `Door.outcome`, `ts`, `notHomeCount` and `dnk`. Visits from before the neighbourhood's `round_start` don't count, except don't-knock, which carries over to new rounds.

| State | Defined by |
|---|---|
| New | `outcome = null`, not don't-knock |
| Not home (second-try candidate) | `outcome = NOT_HOME`, not don't-knock (`isAgain`) |
| Done | Any other outcome |
| Don't knock | `dnk = true` |

**Pending** depends on the mode. Normally a home is pending when it's New. In a second try it's pending when it's Not home and was last tried before `againSince`. A second try is one pass: `againSince` is set once when the pass starts and stays put through row switches.

| From | Event | To | Code |
|---|---|---|---|
| New | Outcome recorded | That outcome | `record` → `Db.record`, `Door.apply` |
| Any recorded | Step back and tap a different outcome | The new outcome; the old visit is voided | `record` (replacing) → `Db.void`, `refreshDoor` |
| Any | Don't knock | Don't knock (also in later rounds) | `record(DO_NOT_KNOCK)` |
| Any except Don't knock | New round (yours or a teammate's) | New | `Db.newRound`, then a reload |
| Any | Erase recorded knocks | New | `Db.eraseKnocks` |
| Any | A teammate records it | Their outcome after the next sync and reload | `Db.applyRemote` → `reloadAsync` |

### M4. A recorded knock (table `visit`)

Live (`voided = 0`) → Voided (`voided = 1`), through a replaced outcome or Erase. A visit is never deleted, so the void reaches teammates. Sync flag: Dirty (`dirty = 1`) → Sent (`dirty = 0`) through `Db.markSent`. `markSent` only clears the flag if `updated` is unchanged, so an edit made during a sync is sent next time.

### M5. In-memory data vs the database (reloads)

| State | Defined by |
|---|---|
| Current | The in-memory `doors` include every knock recorded on this phone |
| Reload reading | An `io` read is under way; `reloadGen` and `writeSeq` were captured in its `Snapshot` |

**Invariant:** a snapshot is only applied if it's the newest reload (`gen == reloadGen`), the activity is still alive, and no knock was recorded since it started reading (`seq == writeSeq`). Otherwise it's dropped, or read again.

| From | Event | To | Code |
|---|---|---|---|
| Current | A sync brought changes, an import finished, the working set changed, a new round, Erase | Reload reading | `reloadAsync` |
| Reload reading | Result arrives and is still valid | Current, with the new data | `deliver` → `applyData` |
| Reload reading | You recorded a knock while it read | Reload reading again | `deliver` → `reloadAsync` |
| Reload reading | A newer reload started, or the activity is destroyed | Result dropped | `deliver` |

### M6. Neighbourhood (table `territory`, plus `importing` in memory)

| State | Defined by |
|---|---|
| Known | A row exists with `imported = 0` |
| Importing | Its code is in `importing` |
| Waiting to retry | Not imported, not importing, `importRetry` scheduled |
| Loaded | `imported = 1` |
| Removed | `deleted = 1` (no current button removes one; a later `putTerritory` brings it back) |

**Invariant:** a neighbourhood in the working set that isn't loaded is either importing or has a retry scheduled. The retry waits 20 s, doubling up to 5 minutes, and resets after a success.

| From | Event | To | Code |
|---|---|---|---|
| (none) | You come near it, choose it as a destination, or a teammate adds it | Known | `setWork`, `chooseTarget`, `addBuurt`, sync |
| Known (in the working set) | | Importing | `importMissing` |
| Importing | Success | Loaded, and a reload | `importMissing` callback |
| Importing | Failure | Waiting to retry (the toast is shown once) | `importMissing` callback |
| Waiting to retry | Timer | Importing | `importRetry` |

### M7. Working set (`work`, `target`, `workLat`/`workLon`, settle candidate)

- **Idle:** where you are is known and loaded.
- **Settling:** you're more than 300 m from the last lookup; once you've stayed within 150 m for 30 s, the lookup runs.
- **Looking up:** `Pdok.buurtenIn` is under way on `bg`. If it fails, `workLat` is reset, so the next GPS fix tries again.
- **Updated:** `setWork` stores the neighbourhoods and starts imports and a reload.

Only on foot (speed 3 m/s or less), and never in tests (`autoLoad = false`). A destination chosen in "Where to knock" (`target`) stays in the working set for 12 hours.

### M8. Activity and map lifecycle

The activity goes Created → Started → Resumed → Paused → Stopped → Destroyed. The map (`HMap`) is made once per activity; its style moves from Loading (data queued in `pending`) to Ready (`onReady`), then to Dead after `destroy()`.

**Invariants**
1. No work may reach a destroyed activity or map. `gone` is set first in `onDestroy`. Every `main.post` from a background thread checks it, the handler's queue is cleared, and the executors are shut down. `HMap` ignores every call after `destroy()` (counted in `lateCalls`) because MapLibre throws on a destroyed style (`Style.validateState`).
2. GPS runs only between `onStart` and `onStop`. The sync loop runs only between `onResume` and `onPause`.
3. The activity is rebuilt on a dark-mode switch (the manifest doesn't handle `uiMode`). Everything M1 needs is persisted, so the rebuild is invisible.

### M9. Showing over the lock screen (`setShowWhenLocked`)

- **Off:** the default.
- **On:** while knocking.
- **Waiting for unlock:** after Finish while the phone is locked.

| From | Event | To | Code |
|---|---|---|---|
| Off | Start knocking, or a restored walk in `onCreate` | On | `startKnocking`, `onCreate` |
| On | Finish, phone unlocked | Off | `leaveLockScreen` |
| On | Finish, phone locked | Waiting for unlock (the unlock prompt shows) | `leaveLockScreen` → `requestDismissKeyguard` |
| Waiting for unlock | Unlocked | Off | `onDismissSucceeded` |
| Waiting for unlock | Unlock cancelled or replaced | stays (the app you're looking at stays visible) | no-op |
| Waiting for unlock / On while not knocking | Screen off or the app leaves the screen | Off | `onStop` |
| On | Walk older than 8 h when you open the app | Off immediately | `endWalk(NOW)` |

**Invariant:** the app is never hidden behind the lock screen while you're looking at it. Outside a walk, it doesn't show over the lock screen once it has left the screen.

### M10. Planning pick (`pickKey`, `pickDoor`, `userPicked`)

- **Suggested:** `userPicked = false`. GPS moves the suggestion (`suggestedRow`).
- **Picked:** you tapped a house, or a follow-up's Map. GPS no longer moves it, and "Start at N" starts at that house.

**Invariant:** `pickDoor` is always a door of `pickKey`'s row, because `applyData` re-resolves `pickKey` from `pickDoor` after every reload. Every way of picking sets both. Finish returns to Suggested.

### M11. Neighbourhood layer (`areasOn`, `areaPick`, `areaGen`)

Off ↔ On (persisted as `areas`). On holds the figures for the neighbourhoods in view, refreshed when the view reaches another area. Off releases them and bumps `areaGen`, so a result still on its way is dropped. On with `areaPick` set shows one neighbourhood's card.

### M12. Team sync

**Team:** none ↔ joined. Changed only through `Db.setTeam` (Join, Create, Leave), which also resets `since`.

**Sync:** idle ↔ syncing (`syncing`). It runs on its own `syncEx` thread, so it never waits behind an import. The loop runs every 30 s while the app is on screen, plus 5 s after each knock (`scheduleSync`).

**One round** (`Sync.run`):
1. Read the dirty rows.
2. POST them with `since`.
3. Mark them sent.
4. Apply the received events (newest `updated` wins).
5. Commit `since`, only if the team is still the one the round started with (`Db.commitPull`, synchronized with `setTeam`).

**Invariants**
1. `since` is always a position in the current team's log.
2. A failed round changes nothing that matters: unsent rows stay dirty, and `since` doesn't move, so the same events come again.
3. Your name is your identity in the team (claims, "Me" stats, sessions). Joining or creating a team requires a real name, not empty and not "Me".

### M12b. Export and import (Setup → Your data)

**Export** writes one JSON file (`app: "harvest"`, `format: 1`) with every row of territory, visit (voided ones too), session, followup, claim, address and buurt_stat, plus your name. It leaves out the team code and server, so a test phone importing it can't sync into the real team.

**Import** merges the file into this phone by the same rule as a sync:

| What | Rule | Code |
|---|---|---|
| territory, visit, session, followup, claim | Newest `updated` wins, whichever side it's on; rows taken from the file are marked dirty so they reach a team | `Db.importFrom` |
| territory `imported` flag | Stays as it is on this phone, unless homes were copied in | `Db.importFrom` |
| address | Copied only for neighbourhoods this phone hasn't loaded; a loaded one keeps its own homes | `Db.importFrom` |
| buurt_stat | Missing ones filled in (it's a cache) | `Db.importFrom` |
| your name | Taken only if this phone has none, or "Me" | `Db.importFrom` |
| working set | Every neighbourhood the file has homes for is added, so it shows offline | `onActivityResult` |

**Invariants:** importing the same file twice changes nothing. An older file never undoes newer work, so knocks erased with "Erase recorded knocks" stay erased. A file that isn't a Harvest export, or comes from a newer format, is refused and nothing changes. File work runs on the sync thread, so it never runs at the same time as a sync.

Tests: `ExportImport.kt`.

### M13. Street claim (table `claim`, one row per user)

- **None:** `street = ''`.
- **Claimed:** set on every `saveWalk` while knocking.
- **Stale:** more than 3 hours old, ignored by `otherClaims`.

`endWalk` clears it.

### M14. Follow-up (table `followup`)

Open (`done = 0`) → Done (the Done button, or Erase).

---

## Part 2: invalid states the code could reach (all fixed in 1.15)

Ranked by impact. Each issue's test is in `app/src/test/java/nl/barnosho/harvest/StateMachines.kt`, named `issueN_…`.

**How the tests were checked:** a copy of the code with every fix below reverted to the old behaviour fails all 12 tests. The fixed code passes them, along with the 10 earlier tests (22 in total).

### Issue 1: crash when background work finishes after the activity was rebuilt (high)

- **Path:** the system switches to dark mode at sunset while an import or reload is running. The activity is destroyed and rebuilt. The old activity's result arrives and goes through `applyData` → `refreshBase` → `HMap.setData` → `style.getSourceAs`.
- **Evidence:**
  - MapLibre 12.3.1 bytecode: `MapLibreMap.onDestroy` calls `Style.clear()`, which sets `fullyLoaded = false`.
  - `getSourceAs` and `getLayer` call `validateState`, which throws `IllegalStateException` when `fullyLoaded` is false.
  - Before the fix, no callback checked whether the activity was still alive. The manifest doesn't handle `uiMode`, so a dark-mode switch rebuilds the activity.
- **Fix:**
  - The `gone` flag, checked in every posted callback.
  - `main.removeCallbacksAndMessages(null)` in `onDestroy`.
  - Executors shut down in `onDestroy`.
  - `HMap` ignores calls after `destroy()` (M8).
- **Test:** `issue1_aReloadFinishingAfterRecreateNeverReachesTheOldMap`. Tests run without a graphics chip, so they can't hit MapLibre's exception itself. Instead the test asserts that the destroyed activity makes no map calls at all (`HMap.lateCalls == 0`).

### Issue 2: the walk lost your place after a rebuild or process death (high)

- **Path:** the activity is rebuilt (dark-mode switch), or Android kills the process while the phone is in your pocket. `onCreate` restored the row and direction but not `selectedId` or `skipped`. `currentStop()` then fell back to the first open house in walking order, which is the far end of the row if you started mid-row. Skipped houses came back straight away.
- **Fix:** `sel` and `skipped` are persisted (`persistPosition`) and restored in `onCreate`. Without a stored house (a walk saved by 1.14), `currentStop` continues from `lastId` in the walking direction.
- **Tests:** `issue2_yourHouseAndSkipsSurviveARecreate`, `issue2_withNothingSelectedTheWalkContinuesFromTheLastHouse`.

### Issue 3: a reload that read before your tap undid it (high)

- **Path:** a sync receives teammates' knocks, which happens every 30 s with a team out. `reloadAsync` reads the database on `io`. You tap "Not home" during that read, so `record` updates the house in memory. Then the read's result, from before your tap, replaced `doors`. The house showed as open again, and `advanceFrom` could send you back to it.
- **Evidence:** before the fix, the reload's result was only checked against `reloadGen`, not against knocks recorded meanwhile.
- **Fix:** `writeSeq` counts local knocks. `deliver` drops a snapshot that started before the latest knock and reads again (M5).
- **Test:** `issue3_aStaleReloadDoesNotPutAKnockedHouseBack`.

### Issue 4: a failed neighbourhood import was never retried while you stayed in the area (medium)

- **Path:** an import fails (a weak connection in a stairwell, a dropped request among the many it makes). The toast said "It will retry when you're online", but `importMissing` was only called on startup, on a changed working set, after a sync that received something, and when a neighbourhood was added. While you stay in the same area, `setWork` returns early (`codes == work`). That neighbourhood stayed empty until a restart or until you walked away.
- **Fix:** the retry timer described in M6.
- **Test:** `issue4_aFailedImportRetriesWithoutLeavingTheArea`.

### Issue 5: leaving knock mode left pieces behind (medium)

- **(a) A silent exit.** `buildKnockOverlay`, finding no row, set `knocking = false` without ending the session or the lock-screen view. The planning map then stayed visible over the lock screen.
- **(b) A cancelled unlock hid the app.** In 1.14, cancelling the unlock prompt after Finish switched off showing over the lock screen while you were looking at the app. That hid it, which is the same symptom as the original Finish bug.
- **(c) A walk that never ended.** Going home without Finish left the app in knock mode, on yesterday's street, over the lock screen, with no end.
- **Fix:**
  - `endWalk` is the only way out, with three lock-screen modes (M9).
  - `onStop` turns the lock-screen view off whenever you're not knocking.
  - `walkAt` records when the walk last changed, and a walk older than 8 hours ends when you open the app.
- **Tests:** `issue5_cancellingTheUnlockKeepsTheAppUntilTheScreenGoesOff`, `issue5_aWalkLeftOverFromEarlierEndsWhenYouComeBack`. Path (a) needs the working set to change under you mid-walk and has no test of its own. It now goes through the same `endWalk`.

### Issue 6: team sync (medium)

- **(a) Sync waited behind imports.** Sync shared the single `bg` thread with neighbourhood imports, which make dozens of requests and can take minutes. While importing (exactly when you arrive somewhere new), knocks and claims didn't sync and "Sync now" did nothing. Fix: its own `syncEx` thread. Test: `issue6_syncIsNotStuckBehindALongImport`.
- **(b) A sync for the old team could set the new team's position.** You leave team A and join B while a sync for A is under way. A's round then wrote A's log position into `since`, and B's events before that position were never pulled. Fix: `Db.commitPull` / `Db.setTeam`, synchronized (M12). Test: `issue6_aSyncForTheOldTeamCannotMoveTheNewTeamsPosition`.
- **(c) Joining as "Me".** The name field is prefilled with "Me", so you could join without changing it. Two phones called "Me" overwrite each other's claim and can't see it (`otherClaims` skips your own name). They also share sessions and "Me" stats. Fix: Join and Create require a real name. Test: `issue6_joiningATeamNeedsYourOwnName`.

### Issue 7: switching rows during a second try started the pass over (low)

- **Path:** "Switch to" a not-home house in another row went through `startAt` → `beginAgain()`, which reset `againSince` to now. Homes already tried again in this pass became pending again.
- **Fix:** `startAt` keeps a second try that's already running.
- **Test:** `issue7_switchingRowsDuringASecondTryDoesNotBringBackHomesAlreadyTried`.
- **Related:** `pick` now always works with the live door (looked up by id), so a tapped house's state can't be stale.

### Issue 8: a follow-up's Map button snapped back after a reload (low)

- **Path:** it set `pickKey` without `pickDoor` or `userPicked`, breaking M10's invariant. The next `applyData` moved the pick back to `pickDoor`'s row.
- **Fix:** it sets all three.
- **Test:** `issue8_theFollowUpMapPickSurvivesAReload`.

### Fixed earlier (1.14)

- **Finish hid the app behind the lock screen** (`setShowWhenLocked(false)` while locked). Now M9.
- **The walking direction ignored where you started,** and "next" wrapped to the start of the row. Now M1 invariants 4 and 5.
- **A house tapped while planning was ignored** by Start knocking. Now M10.
- **A second try started at an arbitrary house.**

Tests: `WalkDirection.kt`.

---

## Part 3: reviewed, not changed

These were examined and judged either correct by design or too unlikely to justify a change. They're listed so the next review doesn't start from zero.

- **Renaming yourself mid-walk.** The old name's claim stays visible to teammates for up to 3 hours, and the old session stays open. Rare, and it causes no wrong data.
- **One outing becoming two sessions.** A pause of more than an hour inside an outing starts a new session. Finish's summary then counts only the second part.
- **Clock skew.** Sync uses newest `updated` wins between phones' clocks. Visits are written once and only ever voided, so skew can only reorder claims and sessions.
- **Teammates on different app versions.** A newer version with an extra column would make `insertWithOnConflict` drop that row silently (it returns -1, it doesn't throw). Not reachable while everyone installs the same build.
- **Duplicate import after a rebuild.** A neighbourhood whose import was under way when the activity was rebuilt is imported once more by the new activity. The result is the same, at the cost of the download.
- **The server.** The server (Cloudflare Worker) isn't in this repository. This document assumes it stores events by `(kind, id)` with newest `updated` winning, so a resent batch is harmless.
