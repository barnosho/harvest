# Harvest: interface audit (1.16)

This is a task-based interaction-cost audit of the knocking flow: a cognitive walkthrough with keystroke-level counting, judged against field conditions, followed by a pass with Nielsen's heuristics. Every finding has a measured cost. Changes keep the 1.10 look; nothing was redesigned.

**Keeping this file current.** When a change adds a step to a task in the table below, update its count. New controls on the knock panel are covered automatically by `UxAudit.u2`, which measures every tappable view.

## Field conditions every step is judged against

- One hand, often while holding tracts.
- A glance between doors, not reading.
- Low sun by day, darkness in the evening (dark mode).
- Cold fingers or gloves (November).
- Interrupted mid-task by a conversation; the phone locks in between.

## The tasks, counted

Taps are counted from the knock panel.

| Task | Taps | Reads / decisions | Verdict |
|---|---|---|---|
| Start a street (suggested) | 1 | Plan card: street, open homes, distance | fine |
| Start at a house you choose | 2 (house, Start at N) | The button names the house | fine (1.14) |
| Not home | 1 | none (84 dp, bottom of screen) | fine |
| Not interested | 1 | none | fine |
| Gospel presented | 2 | Pick from 4 | fine |
| Saved | 3 | Pick from 4, then a count | fine: rare, worth the care |
| Come back later | 3 (+ optional name) | Pick a day | fine |
| Fix a mis-tap | was 2 (‹, outcome), now 2 (the "change" link, outcome) | was: know that ‹ leads back; now: the line says it | **U5** |
| Skip a house | 2 (More, Skip) | | fine |
| Don't knock | 2 (More, Don't knock) | | **U4** (order) |
| Go through a flat | 1 + 1 per home + 1 (back to the street) | | fine, but **U3** |
| Switch to another row | 2 (tap a house, Switch to) | | **U2** (target size) |
| Take the GPS hint | 1 | Read "You seem to be at …" | **U2** |
| Next row / across the street | 1 | | fine |
| Second try | 1 at the end of a row | | fine |
| Finish | 2 (Finish, confirm) | A summary to read | fine: deliberate |

## Checks that passed (no change)

- **Contrast (WCAG):** measured for every text and background pair in both modes. The lowest is white on the dark-mode green button at 4.93:1. Muted text is 7.2:1 in dark mode and 5.2:1 in light mode. All above the 4.5:1 guideline.
- **Glanceability:** the house number is 50 sp, centred, the largest thing on screen.
- **Thumb reach:** every outcome sits in the bottom third.
- **Interruptions:** the walk survives screen-off, the lock screen, a dark-mode switch and process death (state-machine issues 2 and 5).
- **Error prevention:** Finish asks first; a wrong outcome can be changed.

## Findings and changes, by measured cost

### U1. The most important outcomes gave no touch confirmation

- **Evidence:** the panel's three buttons buzz (`HapticFeedbackConstants.CONFIRM`). Every outcome recorded from a sheet went through `record(…, v = null)`: Gospel presented, Saved, Just talked, Come back later and Don't knock. Those are 5 of the 7 outcomes, and the ones recorded while you're still talking to someone, eyes off the screen.
- **Change:** sheet buttons pass the tapped view on, so every outcome buzzes.
- **Test:** `UxAudit.u1_everyOutcomeConfirmsByTouch`.

### U2. Tap targets under 48 dp

- **Evidence, measured in the test rendering:**
  - ‹ › arrows: 22 dp tall.
  - Pills ("Back to N", the neighbourhood switch): 40 dp.
  - Status line, which is the only way to accept "Switch to …" and "You seem to be at …": about 34 dp.
  - More and Finish: about 37 dp.
  - The guideline is 48 dp, and cold fingers need it more.
- **Change:**
  - Arrows: 56 dp.
  - Status line, More and Finish: 48 dp.
  - Tappable pills: still drawn 40 dp high, but they take touches over 48 dp through a transparent 4 dp edge.
- **Test:** `UxAudit.u2_everyControlOnTheKnockPanelIsAFullThumbTarget` walks every tappable view on screen. Its first run measured the arrows at 22 dp and the pills at 40 dp. The status line, More and Finish had already been given 48 dp by then; their old sizes are worked out from font size and padding.

### U3. Inside a flat, the hint pointed at something impossible

- **Evidence:** "Not this house? Tap it on the map." The homes inside a flat aren't on the map one by one; the way to another home is ‹ ›.
- **Change:** inside a flat it reads "Not this home? Use ‹ ›."
- **Test:** `UxAudit.u3_insideAFlatTheHintDoesNotSendYouToTheMap`.

### U4. The More sheet put the sticky choice first

- **Evidence:** "Don't knock" was the first button, exactly where the thumb lands when the sheet opens. It's the only outcome that stays with a house in every later round. Skip, the harmless reason to open More, was second.
- **Change:** order is now Skip, then Walk the other way (or Back to the street), then Don't knock, set apart at the bottom.
- **Test:** `UxAudit.u4_theMoreSheetPutsSkipFirstAndDontKnockLast`.

### U5. Fixing a mis-tap relied on ‹, which doesn't always lead back

- **Evidence:** after a mis-tap, the confirmation line ("14: Not interested") wasn't actionable. The documented way back was ‹. But since 1.14 the walk follows you and turns round at the end of a row, so after a jump or a turn ‹ leads to a different house. The test sets up exactly that case.
- **Change:** the confirmation line reads "14: Not interested · change". Tapping it goes back to that house; the next outcome replaces the old one (M3), and the walk then continues where you were. It's 2 taps, as before, but now visible and always right.
- **Test:** `UxAudit.u5_theLastHouseIsOneTapAwayToChangeItEvenAfterTheWalkTurned`.

### U6. Opposite outcomes 4 dp apart

- **Evidence:** "Not interested" and "We talked" sit side by side with a 4 dp gap. A slip records the opposite outcome. The usual minimum spacing is 8 dp.
- **Change:** 10 dp.
- **Test:** `UxAudit.u6_negativeAndPositiveButtonsHaveRoomBetweenThem`.

## Left for you to decide (judgement, not measured cost)

- **"Come back later" takes a quarter of the We-talked sheet,** though follow-ups are rare for you. Moving it under More would make the sheet a two-way choice (Presented / Saved, with Just talked smaller). It wasn't changed: it costs nothing when unused, and moving it is a preference, not a fix.
- **The permanent hint "Not this house? Tap it on the map."** is noise once you know it. It could disappear after the first few outings. Left as is.
