package nl.barnosho.harvest

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Palette: field green on cool paper. Follows the system's light or dark mode. */
object C {
    var dark = false
    var PRIMARY = 0; var ON_PRIMARY = 0; var PAPER = 0; var CARD = 0; var INK = 0; var ON_INK = 0; var MUTED = 0; var LINE = 0; var FIELD = 0; var DONE = 0; var NEW = 0
    const val WHEAT = 0xFFE7C66B.toInt()

    fun init(isDark: Boolean) {
        dark = isDark
        if (isDark) {
            PAPER = 0xFF111412.toInt(); CARD = 0xFF1C211E.toInt(); INK = 0xFFEDF0EC.toInt(); ON_INK = 0xFF111412.toInt()
            MUTED = 0xFF9BA49E.toInt(); LINE = 0xFF2F3632.toInt(); FIELD = 0xFF8FC89C.toInt(); DONE = 0xFF262C28.toInt(); NEW = 0xFF1C211E.toInt()
            PRIMARY = 0xFF4E7A5C.toInt(); ON_PRIMARY = 0xFFFFFFFF.toInt()   // clearly the main button, without glaring at night
        } else {
            PAPER = 0xFFF2F4F1.toInt(); CARD = 0xFFFFFFFF.toInt(); INK = 0xFF1C221E.toInt(); ON_INK = 0xFFFFFFFF.toInt()
            MUTED = 0xFF5F6862.toInt(); LINE = 0xFFD5DBD5.toInt(); FIELD = 0xFF2F5D3A.toInt(); DONE = 0xFFE5E9E4.toInt(); NEW = 0xFFFFFFFF.toInt()
            PRIMARY = INK; ON_PRIMARY = 0xFFFFFFFF.toInt()
        }
    }

    /** A colour dot for an outcome, readable on both backgrounds. */
    fun dot(o: Outcome?, dnk: Boolean): Int? = when {
        dnk -> if (dark) 0xFF6E7570.toInt() else Outcome.DO_NOT_KNOCK.color
        o == null -> null
        else -> o.color
    }
}

val SERIF: Typeface = Typeface.create("serif", Typeface.BOLD)

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun View.dp(v: Int) = context.dp(v)

fun rounded(color: Int, radius: Float, stroke: Int = 0, strokeColor: Int = 0) = GradientDrawable().apply {
    setColor(color); cornerRadius = radius
    if (stroke > 0) setStroke(stroke, strokeColor)
}

fun Context.text(s: CharSequence, size: Float = 16f, color: Int = C.INK, bold: Boolean = false, serif: Boolean = false) =
    TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        typeface = when { serif -> SERIF; bold -> Typeface.DEFAULT_BOLD; else -> Typeface.DEFAULT }
    }

fun Context.button(label: String, bg: Int, fg: Int = C.ON_INK, height: Int = 52, onClick: (View) -> Unit) =
    TextView(this).apply {
        text = label; textSize = 16f; setTextColor(fg); typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; minHeight = dp(height)
        setPadding(dp(14), dp(6), dp(14), dp(6))
        background = RippleDrawable(ColorStateList.valueOf(0x33000000), rounded(bg, dp(14).toFloat(),
            if (bg == C.CARD || bg == C.PAPER) dp(1) else 0, C.LINE), null)
        isClickable = true; isFocusable = true
        setOnClickListener(onClick)
    }

fun Context.vbox(pad: Int = 0, build: LinearLayout.() -> Unit = {}) = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL; setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); build()
}

fun Context.hbox(pad: Int = 0, build: LinearLayout.() -> Unit = {}) = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); build()
}

fun Context.input(hint: String, value: String = "") = EditText(this).apply {
    this.hint = hint; setText(value); textSize = 16f; setTextColor(C.INK); setHintTextColor(C.MUTED)
    background = rounded(C.CARD, dp(10).toFloat(), dp(1), C.LINE)
    setPadding(dp(12), dp(10), dp(12), dp(10)); isSingleLine = true
}

/** Add a child with weight / margins in one line. */
fun LinearLayout.add(v: View, weight: Float = 0f, w: Int = -1, h: Int = -2, top: Int = 0, side: Int = 0): View {
    val horiz = orientation == LinearLayout.HORIZONTAL
    val lp = LinearLayout.LayoutParams(
        if (horiz && weight > 0) 0 else if (w == -1) ViewGroup.LayoutParams.MATCH_PARENT else if (w == -2) ViewGroup.LayoutParams.WRAP_CONTENT else dp(w),
        if (!horiz && weight > 0) 0 else if (h == -1) ViewGroup.LayoutParams.MATCH_PARENT else if (h == -2) ViewGroup.LayoutParams.WRAP_CONTENT else dp(h),
        weight
    )
    lp.topMargin = dp(top); lp.leftMargin = dp(side); lp.rightMargin = dp(side)
    addView(v, lp); return v
}

fun Context.divider() = View(this).apply { setBackgroundColor(C.LINE) }

fun fmtDist(m: Double) = when {
    m == Double.MAX_VALUE -> ""
    m < 1000 -> "${m.toInt()} m"
    else -> String.format("%.1f km", m / 1000)
}

fun fmtAgo(ts: Long): String {
    val m = (System.currentTimeMillis() - ts) / 60000
    return when {
        m < 1 -> "just now"; m < 60 -> "${m} min ago"; m < 60 * 24 -> "${m / 60} h ago"
        else -> "${m / 1440} days ago"
    }
}

fun fmtDuration(min: Long) = if (min < 60) "${min} min" else "${min / 60} h ${min % 60} min"

// ---------- one family of surfaces ----------

/** Lift a surface off the map with a real shadow (cheap: drawn by the system from the background's outline). */
fun View.lift(dpUp: Int) { elevation = dpUp * resources.displayMetrics.density; outlineProvider = android.view.ViewOutlineProvider.BACKGROUND }

/**
 * A floating control on the map: 40 dp high (a tappable one takes touches over 48 dp), fully rounded, lifted by a shadow rather than outlined.
 * In dark mode shadows don't show, so a hairline edge takes their place.
 */
fun Context.pill(label: String, lead: View? = null, onClick: ((View) -> Unit)? = null): LinearLayout {
    val p = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        minimumHeight = dp(40); setPadding(dp(if (lead != null) 12 else 16), 0, dp(16), 0)
        val bg = rounded(C.CARD, dp(20).toFloat(), if (C.dark) dp(1) else 0, C.LINE)
        background = if (onClick != null) RippleDrawable(ColorStateList.valueOf(0x22000000), bg, null) else bg
        // a tappable pill still looks 40 dp high, but takes touches over a full 48 dp: 4 dp of invisible edge
        if (onClick != null) {
            background = android.graphics.drawable.InsetDrawable(background, 0, dp(4), 0, dp(4)); minimumHeight = dp(48)
            setPadding(dp(if (lead != null) 12 else 16), 0, dp(16), 0)   // a new background resets padding to its own insets
        }
        lift(3)
        if (onClick != null) { isClickable = true; isFocusable = true; setOnClickListener(onClick) }
    }
    if (lead != null) p.add(lead, w = 12, h = 12, side = 0).also { (it.layoutParams as LinearLayout.LayoutParams).rightMargin = dp(8) }
    // tappable pills are bold; information pills are regular, so they don't read as buttons
    p.add(text(label, 14f, C.INK, bold = onClick != null), w = -2)
    return p
}

/** The surface panels rise from: full width, rounded top corners, a soft shadow above. */
fun Context.sheetSurface(color: Int = C.CARD) = GradientDrawable().apply {
    setColor(color)
    val r = dp(24).toFloat(); cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    if (C.dark) setStroke(dp(1), C.LINE)
}

/** The small grab handle at the top of a sheet. */
fun Context.handle() = View(this).apply { background = rounded(C.LINE, dp(2).toFloat()) }

/** A thin progress line: how far along the row you are. */
fun Context.progressLine(frac: Float): View {
    val outer = LinearLayout(this).apply { background = rounded(C.LINE, dp(2).toFloat()); weightSum = 1f }
    outer.addView(View(this).apply { background = rounded(C.FIELD, dp(2).toFloat()) },
        LinearLayout.LayoutParams(0, -1, frac.coerceIn(0.001f, 1f)))
    return outer
}

/** A small square in a colour: the on/off sign for a map layer, the key for an outcome. */
fun Context.square(color: Int, ring: Int = 0) = View(this).apply { background = rounded(color, dp(3).toFloat(), if (ring != 0) dp(2) else 0, ring) }
