package nl.barnosho.harvest

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Where people are most likely to be receptive, from open government data (CBS neighbourhood figures 2024)
 * and the building register, sharpened over time by your own results.
 *
 * The working rule it encodes: social-rent flats first, avoid homes for the elderly,
 * expensive owner-occupied streets last. Every score comes with the reasons behind it.
 */
class BuurtStat(
    val code: String, val name: String, val gemeente: String,
    val corp: Int?, val flats: Int?, val woz: Int?, val old: Int?, val bijstandPct: Double?, val households: Int,
    val lat: Double, val lon: Double,
    val rings: List<DoubleArray>,   // outline(s), simplified: each ring is [lon, lat, lon, lat, …]
) {
    /** 0–100, or null when CBS publishes too little about this neighbourhood to judge. */
    val score: Int? by lazy {
        if (corp == null && flats == null && woz == null) return@lazy null
        val parts = ArrayList<Pair<Double, Double>>()
        corp?.let { parts += 0.45 to it.toDouble() }                                            // social rent: the strongest signal
        flats?.let { parts += 0.25 to it.toDouble() }                                           // flats rather than houses
        woz?.let { parts += 0.20 to ((450 - it) / 3.0).coerceIn(0.0, 100.0) }                  // modest home values
        bijstandPct?.let { parts += 0.10 to (it * 10).coerceIn(0.0, 100.0) }                   // people on social assistance
        var s = parts.sumOf { it.first * it.second } / parts.sumOf { it.first }
        old?.let { if (it > 25) s -= (it - 25) * 1.2 }                                         // many elderly: lower
        s.toInt().coerceIn(0, 100)
    }

    fun reasons(): List<String> = buildList {
        corp?.let { add("$it% social rent") }
        flats?.let { add("$it% flats") }
        woz?.let { add("homes around €${it}k") }
        old?.let { if (it > 25) add("$it% aged 65+") }
    }

    fun toJson(): JSONObject = JSONObject().put("code", code).put("name", name).put("gemeente", gemeente)
        .put("corp", corp ?: -1).put("flats", flats ?: -1).put("woz", woz ?: -1).put("old", old ?: -1)
        .put("bij", bijstandPct ?: -1.0).put("hh", households).put("lat", lat).put("lon", lon)
        .put("rings", JSONArray(rings.map { r -> JSONArray(r.toList()) }))

    companion object {
        fun fromJson(o: JSONObject): BuurtStat {
            fun opt(k: String) = o.optInt(k, -1).takeIf { it >= 0 }
            val rs = o.getJSONArray("rings")
            return BuurtStat(o.getString("code"), o.optString("name"), o.optString("gemeente"),
                opt("corp"), opt("flats"), opt("woz"), opt("old"), o.optDouble("bij", -1.0).takeIf { it >= 0 }, o.optInt("hh"),
                o.getDouble("lat"), o.getDouble("lon"),
                (0 until rs.length()).map { i -> val a = rs.getJSONArray(i); DoubleArray(a.length()) { a.getDouble(it) } })
        }

        /** From a CBS OGC feature. Outlines are simplified to ~8 m, plenty for colouring a map. */
        fun fromFeature(f: JSONObject): BuurtStat? {
            val p = f.getJSONObject("properties")
            fun v(k: String) = p.optInt(k, -1).takeIf { it >= 0 }
            val hh = v("aantal_huishoudens") ?: 0
            if (p.optString("water") == "JA" || hh < 20) return null
            val inw = v("aantal_inwoners")
            val bij = v("aantal_personen_met_een_alg_bijstandsuitkering_tot")
            val rings = ArrayList<DoubleArray>()
            val g = f.optJSONObject("geometry") ?: return null
            val polys = if (g.optString("type") == "MultiPolygon") g.getJSONArray("coordinates") else JSONArray().put(g.getJSONArray("coordinates"))
            for (i in 0 until polys.length()) {
                val outer = polys.getJSONArray(i).getJSONArray(0)
                val pts = (0 until outer.length()).map { doubleArrayOf(outer.getJSONArray(it).getDouble(0), outer.getJSONArray(it).getDouble(1)) }
                val simple = simplify(pts, 8.0)
                rings += DoubleArray(simple.size * 2) { k -> simple[k / 2][k % 2] }
            }
            val all = rings.flatMap { r -> (r.indices step 2).map { doubleArrayOf(r[it], r[it + 1]) } }
            if (all.isEmpty()) return null
            return BuurtStat(p.getString("buurtcode"), p.optString("buurtnaam"), p.optString("gemeentenaam"),
                v("perc_huurwoningen_in_bezit_woningcorporaties"), v("percentage_meergezinswoning"), v("gemiddelde_woningwaarde"),
                v("percentage_personen_65_jaar_en_ouder"), if (inw != null && inw > 0 && bij != null) bij * 100.0 / inw else null, hh,
                all.map { it[1] }.average(), all.map { it[0] }.average(), rings)
        }

        // Douglas–Peucker in metres
        private fun simplify(pts: List<DoubleArray>, tol: Double): List<DoubleArray> {
            if (pts.size < 4) return pts
            val keep = BooleanArray(pts.size); keep[0] = true; keep[pts.size - 1] = true
            val stack = ArrayDeque<Pair<Int, Int>>(); stack.add(0 to pts.size - 1)
            while (stack.isNotEmpty()) {
                val (a, b) = stack.removeLast()
                var far = -1; var fd = 0.0
                for (i in a + 1 until b) { val d = segDist(pts[i], pts[a], pts[b]); if (d > fd) { fd = d; far = i } }
                if (far >= 0 && fd > tol) { keep[far] = true; stack.add(a to far); stack.add(far to b) }
            }
            return pts.filterIndexed { i, _ -> keep[i] }
        }

        private fun segDist(p: DoubleArray, a: DoubleArray, b: DoubleArray): Double {
            val mx = 68000.0; val my = 111300.0
            val bx = (b[0] - a[0]) * mx; val by = (b[1] - a[1]) * my; val px = (p[0] - a[0]) * mx; val py = (p[1] - a[1]) * my
            val l2 = bx * bx + by * by
            val t = if (l2 == 0.0) 0.0 else ((px * bx + py * by) / l2).coerceIn(0.0, 1.0)
            return kotlin.math.hypot(px - t * bx, py - t * by)
        }
    }

    fun contains(lat: Double, lon: Double): Boolean = rings.any { r ->
        var inside = false; var j = r.size - 2
        var i = 0
        while (i < r.size) {
            val xi = r[i]; val yi = r[i + 1]; val xj = r[j]; val yj = r[j + 1]
            if ((yi > lat) != (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) inside = !inside
            j = i; i += 2
        }
        inside
    }
}

/** Your own results in a neighbourhood. */
class Observed(val doors: Int, val presented: Int, val saved: Int)

object Receptivity {
    /** The neighbourhood's score, blended with your own presentation rate once you've knocked enough doors there. */
    fun buurt(stat: BuurtStat?, seen: Observed?): Int? {
        val base = stat?.score
        if (seen == null || seen.doors < 30) return base
        val mine = (seen.presented * 400.0 / seen.doors).coerceIn(0.0, 100.0)   // a quarter of doors presented = top
        return if (base == null) mine.toInt() else (0.6 * base + 0.4 * mine).toInt()
    }

    /** A stop: flats from the social-housing era score up, care buildings down, houses a bit below their area. */
    fun stop(s: Stop, area: Int?): Int {
        val a = area ?: 35
        if (!s.isBuilding) return (a * 0.85).toInt()
        val d = s.first
        if (d.care) return max(0, a - 60)
        val era = when {
            d.built == 0 -> 0
            d.built <= 1985 -> 15      // portiek- and galerijflats: the classic social-rent stock
            d.built <= 2005 -> 5
            else -> -10                // newer flats are more often owner-occupied or for seniors
        }
        return min(100, a + era + 5)
    }

    fun label(score: Int?) = when {
        score == null -> "No figures published"
        score >= 55 -> "Very promising"
        score >= 40 -> "Promising"
        score >= 25 -> "Mixed"
        else -> "Unlikely"
    }

    /** Map tint: warm for promising, cool and faint for unlikely. */
    fun color(score: Int?): Int = when {
        score == null -> 0x00000000
        score >= 55 -> 0xFFD9822B.toInt()
        score >= 40 -> 0xFFE7B54A.toInt()
        score >= 25 -> 0xFFB7C4A8.toInt()
        else -> 0xFF9AA5B1.toInt()
    }
}
