package nl.barnosho.harvest

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

private fun http(url: String, body: String? = null, auth: String? = null): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 10000; c.readTimeout = 20000
    c.setRequestProperty("User-Agent", "Harvest/1.0")
    if (auth != null) c.setRequestProperty("Authorization", "Bearer $auth")
    if (body != null) {
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
    }
    val code = c.responseCode
    val text = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
    if (code >= 400) throw Exception("Server answered $code: ${text.take(120)}")
    return text
}

/** Dutch address register (BAG) via PDOK Locatieserver. Territory = CBS neighbourhood (buurt). */
object Pdok {
    private const val B = "https://api.pdok.nl/bzk/locatieserver/search/v3_1"

    class Buurt(val code: String, val name: String, val gemeente: String, val wijk: String, val lat: Double? = null, val lon: Double? = null)

    /** A town, district or neighbourhood by name: where it is and how far to zoom in. */
    fun place(text: String): Triple<Double, Double, Double>? {
        val r = JSONObject(http("$B/free?q=${enc(text)}&fq=type:(woonplaats OR gemeente OR wijk OR buurt)&rows=1&fl=type,centroide_ll"))
        val d = r.getJSONObject("response").getJSONArray("docs").optJSONObject(0) ?: return null
        val p = point(d.optString("centroide_ll")) ?: return null
        val z = when (d.optString("type")) { "buurt" -> 15.0; "wijk" -> 14.5; else -> 13.0 }
        return Triple(p.first, p.second, z)
    }

    /** CBS 2024 figures and outlines for every neighbourhood overlapping a map area. */
    fun stats(south: Double, west: Double, north: Double, east: Double): List<BuurtStat> {
        val out = ArrayList<BuurtStat>()
        var url: String? = String.format(java.util.Locale.ROOT,
            "https://api.pdok.nl/cbs/wijken-en-buurten-2024/ogc/v1/collections/buurten/items?f=json&limit=200&bbox=%.4f,%.4f,%.4f,%.4f", west, south, east, north)
        var pages = 0
        while (url != null && pages++ < 6) {
            val d = JSONObject(http(url))
            val f = d.getJSONArray("features")
            for (i in 0 until f.length()) try { BuurtStat.fromFeature(f.getJSONObject(i))?.let { out += it } } catch (e: Exception) {}
            val links = d.getJSONArray("links")
            url = (0 until links.length()).map { links.getJSONObject(it) }.firstOrNull { it.optString("rel") == "next" }?.optString("href")
        }
        return out
    }

    /** Neighbourhoods (CBS) overlapping a map area, skipping water and areas where nobody lives. */
    fun buurtenIn(south: Double, west: Double, north: Double, east: Double): List<Buurt> {
        val bbox = String.format(java.util.Locale.ROOT, "%.5f,%.5f,%.5f,%.5f", west, south, east, north)
        val d = JSONObject(http("https://api.pdok.nl/cbs/wijken-en-buurten-2025/ogc/v1/collections/buurten/items?f=json&limit=40&bbox=$bbox"))
        val f = d.getJSONArray("features")
        return (0 until f.length()).map { f.getJSONObject(it).getJSONObject("properties") }
            .filter { it.optString("water") != "JA" && it.optInt("aantal_huishoudens", 1) > 0 }
            .map { Buurt(it.getString("buurtcode"), it.optString("buurtnaam"), it.optString("gemeentenaam"), "") }
    }

    fun buurtAt(lat: Double, lon: Double): Buurt? {
        val r = JSONObject(http("$B/reverse?lat=$lat&lon=$lon&type=adres&rows=1&fl=buurtcode,buurtnaam,gemeentenaam,wijknaam"))
        val d = r.getJSONObject("response").getJSONArray("docs").optJSONObject(0) ?: return null
        return Buurt(d.getString("buurtcode"), d.optString("buurtnaam"), d.optString("gemeentenaam"), d.optString("wijknaam"))
    }

    /** Free-text neighbourhood search; every typed word must appear in neighbourhood, district or town. */
    fun searchBuurten(text: String): List<Buurt> {
        val words = text.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val r = JSONObject(http("$B/free?q=${enc(text)}&fq=type:buurt&rows=100&fl=buurtcode,buurtnaam,gemeentenaam,wijknaam,centroide_ll"))
        val docs = r.getJSONObject("response").getJSONArray("docs")
        return (0 until docs.length()).map { docs.getJSONObject(it) }
            .map { val p = point(it.optString("centroide_ll")); Buurt(it.getString("buurtcode"), it.optString("buurtnaam"), it.optString("gemeentenaam"), it.optString("wijknaam"), p?.first, p?.second) }
            .filter { b -> val hay = "${b.name} ${b.gemeente} ${b.wijk}".lowercase(); words.all { it in hay } }
            .sortedWith(compareBy({ it.gemeente }, { it.name }))
    }

    fun addresses(buurtcode: String): List<Door> {
        val docs = ArrayList<JSONObject>()
        var start = 0
        while (true) {
            val r = JSONObject(http("$B/free?q=*:*&fq=type:adres&fq=buurtcode:${enc(buurtcode)}&rows=100&start=$start" +
                "&fl=nummeraanduiding_id,straatnaam,huis_nlt,postcode,centroide_ll&sort=${enc("id asc")}"))
                .getJSONObject("response")
            val arr = r.getJSONArray("docs")
            for (i in 0 until arr.length()) docs += arr.getJSONObject(i)
            start += 100
            if (arr.length() == 0 || start >= r.getInt("numFound")) break
        }
        // Building data (what each address is used for, and which building it's in). If this fails,
        // keep every address rather than lose the neighbourhood.
        val vbos = try { buildingData(docs) } catch (e: Exception) { emptyList() }
        // Street centre lines, so walking order follows the pavement. Without them: odd/even fallback.
        // rows now follow the house numbers (see Walks), so the road register's centre lines are no longer downloaded
        val nwb = emptyList<JSONObject>()
        val doors = buildDoors(buurtcode, docs, vbos, nwb)
        // construction year per flat building: the social-rent portiek- and galerijflats are mostly 1950–1985
        for (pand in doors.mapNotNull { it.building }.toSet()) {
            val year = try {
                JSONObject(http("https://api.pdok.nl/kadaster/bag/ogc/v2/collections/pand/items/$pand?f=json")).getJSONObject("properties").optInt("bouwjaar")
            } catch (e: Exception) { 0 }
            if (year > 0) doors.filter { it.building == pand }.forEach { it.built = year }
        }
        return doors
    }

    private fun buildingData(docs: List<JSONObject>): List<JSONObject> {
        val pts = docs.mapNotNull { point(it.optString("centroide_ll")) }
        if (pts.isEmpty()) return emptyList()
        val bbox = "${pts.minOf { it.second } - 0.0005},${pts.minOf { it.first } - 0.0005},${pts.maxOf { it.second } + 0.0005},${pts.maxOf { it.first } + 0.0005}"
        val out = ArrayList<JSONObject>()
        var url: String? = "https://api.pdok.nl/kadaster/bag/ogc/v2/collections/verblijfsobject/items?f=json&limit=1000&bbox=$bbox"
        var pages = 0
        while (url != null && pages++ < 40) {
            val d = JSONObject(http(url))
            val f = d.getJSONArray("features")
            for (i in 0 until f.length()) out += f.getJSONObject(i).getJSONObject("properties")
            val links = d.getJSONArray("links")
            url = (0 until links.length()).map { links.getJSONObject(it) }.firstOrNull { it.optString("rel") == "next" }?.optString("href")
        }
        return out
    }

    private fun roadData(docs: List<JSONObject>): List<JSONObject> {
        val pts = docs.mapNotNull { point(it.optString("centroide_ll")) }
        if (pts.isEmpty()) return emptyList()
        val bbox = "${pts.minOf { it.second } - 0.0005},${pts.minOf { it.first } - 0.0005},${pts.maxOf { it.second } + 0.0005},${pts.maxOf { it.first } + 0.0005}"
        val out = ArrayList<JSONObject>()
        var url: String? = "https://api.pdok.nl/rws/nationaal-wegenbestand-wegen/ogc/v1/collections/wegvakken/items?f=json&limit=1000&bbox=$bbox"
        var pages = 0
        while (url != null && pages++ < 20) {
            val d = JSONObject(http(url))
            val f = d.getJSONArray("features")
            for (i in 0 until f.length()) out += f.getJSONObject(i)
            val links = d.getJSONArray("links")
            url = (0 until links.length()).map { links.getJSONObject(it) }.firstOrNull { it.optString("rel") == "next" }?.optString("href")
        }
        return out
    }

    /** lat, lon from "POINT(lon lat)" */
    fun point(s: String): Pair<Double, Double>? {
        val p = Regex("POINT\\(([-0-9.]+) ([-0-9.]+)\\)").find(s) ?: return null
        return p.groupValues[2].toDouble() to p.groupValues[1].toDouble()
    }

    /**
     * Keeps homes only (drops shops, schools, offices, and homes not in use yet) and marks flats:
     * a building with 4 or more homes becomes one entrance you knock as a group.
     */
    fun buildDoors(buurtcode: String, docs: List<JSONObject>, vbos: List<JSONObject>, nwb: List<JSONObject> = emptyList()): List<Door> {
        // an address can have old, withdrawn records too; prefer the one in use
        val best = HashMap<String, JSONObject>()
        for (v in vbos) {
            val id = v.optString("hoofdadres_identificatie"); if (id.isEmpty()) continue
            val cur = best[id]
            if (cur == null || (!inUse(cur) && inUse(v))) best[id] = v
        }
        class Raw(val doc: JSONObject, val lat: Double, val lon: Double, val pand: String?)
        val kept = ArrayList<Raw>()
        for (d in docs) {
            val id = d.optString("nummeraanduiding_id")
            val p = point(d.optString("centroide_ll"))
            if (id.isEmpty() || p == null) continue
            val v = best[id]
            if (v != null && (!inUse(v) || !v.optString("gebruiksdoel").contains("woonfunctie"))) continue
            val pand = v?.optJSONArray("pand.href")?.optString(0)?.substringAfterLast('/')?.ifEmpty { null }
            kept += Raw(d, p.first, p.second, pand)
        }
        val flats = kept.groupingBy { it.pand }.eachCount().filter { it.key != null && it.value >= 4 }.keys
        // a building that also holds a care function is usually a home for the elderly
        val care = vbos.filter { it.optString("gebruiksdoel").contains("gezondheidszorgfunctie") }
            .mapNotNull { it.optJSONArray("pand.href")?.optString(0)?.substringAfterLast('/') }.toSet()
        val out = kept.map { r ->
            Door(r.doc.getString("nummeraanduiding_id"), buurtcode, r.doc.optString("straatnaam"), r.doc.optString("huis_nlt"),
                r.doc.optString("postcode"), r.lat, r.lon, if (r.pand in flats) r.pand else null).apply { this.care = r.pand != null && r.pand in care }
        }
        if (nwb.isNotEmpty()) {
            val orlOf = best.mapValues { it.value.optString("openbare_ruimte_identificatie") }.filterValues { it.isNotEmpty() }
            StreetLines.place(out, orlOf, StreetLines.chains(nwb))
        }
        return out
    }

    private fun inUse(v: JSONObject) = v.optString("status").let { it.contains("in gebruik") || it.contains("Verbouwing") }
}

/** Team sync against the Harvest Cloudflare Worker. Everything is an event with an `updated` stamp; newest wins. */
object Sync {
    class Result(val sent: Int, val received: Int)

    fun run(db: Db): Result {
        val server = db.get("server").trimEnd('/')
        val team = db.get("team")
        if (server.isEmpty() || team.isEmpty()) throw Exception("No team set up yet")
        val since = db.get("since", "0").toLong()
        val out = db.dirtyEvents()
        val body = JSONObject().put("since", since).put("events", JSONArray(out))
        val r = JSONObject(http("$server/sync", body.toString(), team))
        db.markSent(out)
        val evs = r.getJSONArray("events")
        val list = (0 until evs.length()).map { evs.getJSONObject(it) }
        // You may have left this team (or joined another) while this request was under way. Its position in the
        // old team's event log must not become the new team's, or the new team's earlier events are never pulled.
        // Apply first, then move the position: if applying fails, the same events are fetched again next time.
        val changed = db.applyRemote(list)
        db.commitPull(team, r.getLong("seq"))
        return Result(out.size, changed)
    }
}
