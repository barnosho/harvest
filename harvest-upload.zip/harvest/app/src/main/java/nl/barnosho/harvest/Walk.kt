package nl.barnosho.harvest

import kotlin.math.cos
import kotlin.math.sqrt

fun numOf(d: Door) = d.num.takeWhile(Char::isDigit).toIntOrNull() ?: 0
val numOrder = compareBy<Door>({ numOf(it) }, { it.num })

fun metres(aLat: Double, aLon: Double, bLat: Double, bLon: Double): Double {
    val x = (bLon - aLon) * cos(Math.toRadians((aLat + bLat) / 2)) * 111320
    val y = (bLat - aLat) * 110540
    return sqrt(x * x + y * y)
}

/** One place you stop: a house, or the entrance of a flat with several homes behind it. */
class Stop(val doors: List<Door>) {
    val first get() = doors.first()
    val id get() = first.id
    val isBuilding get() = doors.size > 1
    val label get() = if (isBuilding) "${doors.first().num}–${doors.last().num}" else first.num
    fun dist(o: Stop) = metres(first.lat, first.lon, o.first.lat, o.first.lon)
}

/**
 * A row is what you walk without crossing: same side, house numbers in order, no big gap.
 * A normal street is two rows facing each other; a junction splits a row; a woonerf has many short rows.
 */
class Row(val street: String, val index: Int, val stops: List<Stop>, val sect: String = "", val side: String = "") {
    val key get() = "$street|$index"
    /** The row's house numbers, lowest to highest, e.g. "4–20": names the side without odd/even. */
    val range get(): String {
        val all = stops.flatMap { it.doors }.sortedWith(numOrder)
        val lo = numOf(all.first()); val hi = numOf(all.last())
        return if (all.size == 1) all.first().num else if (lo == hi) "$lo" else "$lo–$hi"
    }
    /** Other side of the same street, and actually opposite: some home of it within 40 m of one of ours. */
    fun facing(o: Row) = street == o.street && side != o.side && side != "c" &&
        stops.any { a -> o.stops.any { b -> a.dist(b) < 40.0 } }
}

object Walks {
    private const val LINK = 40.0   // metres: the next number further away than this starts a new row

    /**
     * Rows follow the house numbers, the way you walk them: from a home to the next number on the same side,
     * a few metres further. Most Dutch streets have odd numbers on one side and even on the other, ascending;
     * some (courtyards, one-sided streets) number straight along: 7, 8, 9, 10. Which of the two a street uses is
     * read from the homes themselves. A row turns a corner when the numbers do (159 → 161 around a side arm),
     * skips a missing number, and ends where the next number is far away (a junction, a park, another stretch).
     */
    fun rows(doors: List<Door>): Map<String, List<Row>> {
        val out = HashMap<String, List<Row>>()
        for ((street, list) in doors.groupBy { it.street }) {
            val stops = list.groupBy { it.building ?: "door:${it.id}" }.values
                .map { Stop(it.sortedWith(numOrder)) }
                .sortedWith(compareBy({ numOf(it.first) }, { it.first.num }))
            val byNum = stops.associateBy { numOf(it.first) }
            val d1 = byNum.keys.mapNotNull { n -> byNum[n + 1]?.let { byNum[n]!!.dist(it) } }
            val d2 = byNum.keys.mapNotNull { n -> byNum[n + 2]?.let { byNum[n]!!.dist(it) } }
            val consecutive = d1.size >= 3 && d2.size >= 3 && median(d1) < median(d2)
            val groups = if (consecutive) listOf("c" to stops)
                else listOf("p1" to stops.filter { numOf(it.first) % 2 == 1 }, "p0" to stops.filter { numOf(it.first) % 2 == 0 })
            val rows = ArrayList<Row>()
            for ((side, g) in groups) {
                var cur = ArrayList<Stop>()
                for (s in g) {
                    if (cur.isNotEmpty() && cur.last().dist(s) > LINK) { rows += Row(street, rows.size, cur, "", side); cur = ArrayList() }
                    cur += s
                }
                if (cur.isNotEmpty()) rows += Row(street, rows.size, cur, "", side)
            }
            out[street] = rows
        }
        return out
    }

    private fun median(l: List<Double>) = l.sorted()[l.size / 2]
}

/**
 * Street centre lines from the national road register (NWB), linked to BAG by street id.
 * Every home is projected onto its own street's line: how far along it is, and on which side.
 */
object StreetLines {
    private const val MX = 68000.0   // metres per degree longitude around 52°N
    private const val MY = 111300.0
    private fun d(a: DoubleArray, b: DoubleArray) = kotlin.math.hypot((a[0] - b[0]) * MX, (a[1] - b[1]) * MY)

    /** NWB features -> per street id, the line pieces joined into continuous chains. */
    fun chains(features: List<org.json.JSONObject>): Map<String, List<List<DoubleArray>>> {
        val pieces = HashMap<String, MutableList<List<DoubleArray>>>()
        for (f in features) {
            val orl = f.optJSONObject("properties")?.optString("bag_orl").orEmpty()
            val g = f.optJSONObject("geometry") ?: continue
            if (orl.isEmpty()) continue
            val parts = if (g.optString("type") == "MultiLineString") g.getJSONArray("coordinates") else org.json.JSONArray().put(g.getJSONArray("coordinates"))
            for (i in 0 until parts.length()) {
                val ln = parts.getJSONArray(i)
                pieces.getOrPut(orl) { ArrayList() } += (0 until ln.length()).map { doubleArrayOf(ln.getJSONArray(it).getDouble(0), ln.getJSONArray(it).getDouble(1)) }
            }
        }
        return pieces.mapValues { join(it.value) }
    }

    private fun join(input: List<List<DoubleArray>>): List<List<DoubleArray>> {
        val rest = input.toMutableList(); val out = ArrayList<List<DoubleArray>>()
        while (rest.isNotEmpty()) {
            var c = rest.removeAt(0)
            var grown = true
            while (grown) {
                grown = false
                for (i in rest.indices) {
                    val l = rest[i]
                    c = when {
                        d(c.last(), l.first()) < 2 -> c + l.drop(1)
                        d(c.last(), l.last()) < 2 -> c + l.reversed().drop(1)
                        d(c.first(), l.last()) < 2 -> l.dropLast(1) + c
                        d(c.first(), l.first()) < 2 -> l.reversed().dropLast(1) + c
                        else -> continue
                    }
                    rest.removeAt(i); grown = true; break
                }
            }
            out += c
        }
        return out
    }

    /** distance to the line, metres along it, side (+1 / -1) */
    fun project(c: List<DoubleArray>, lon: Double, lat: Double): Triple<Double, Double, Int> {
        var best = Triple(Double.MAX_VALUE, 0.0, 1); var acc = 0.0
        for (i in 0 until c.size - 1) {
            val a = c[i]; val b = c[i + 1]
            val bx = (b[0] - a[0]) * MX; val by = (b[1] - a[1]) * MY
            val qx = (lon - a[0]) * MX; val qy = (lat - a[1]) * MY
            val l2 = maxOf(bx * bx + by * by, 1e-9); val len = kotlin.math.sqrt(l2)
            val t = ((qx * bx + qy * by) / l2).coerceIn(0.0, 1.0)
            val dist = kotlin.math.hypot(qx - t * bx, qy - t * by)
            if (dist < best.first) best = Triple(dist, acc + t * len, if (bx * qy - by * qx > 0) 1 else -1)
            acc += len
        }
        return best
    }

    /** Sets sect / pos / sgn on every door whose street has a line. Fragments with few homes join the nearest real stretch. */
    fun place(doors: List<Door>, orlOf: Map<String, String>, chains: Map<String, List<List<DoubleArray>>>) {
        class P(val door: Door, val orl: String, var chain: Int)
        val placed = doors.mapNotNull { dr ->
            val orl = orlOf[dr.id] ?: return@mapNotNull null
            val cs = chains[orl] ?: return@mapNotNull null
            val best = cs.indices.minByOrNull { project(cs[it], dr.lon, dr.lat).first } ?: return@mapNotNull null
            P(dr, orl, best)
        }
        for ((orl, g) in placed.groupBy { it.orl }) {
            val cs = chains.getValue(orl)
            val real = g.groupingBy { it.chain }.eachCount().filter { it.value >= 4 }.keys
            for (p in g) {
                if (real.isNotEmpty() && p.chain !in real) p.chain = real.minBy { project(cs[it], p.door.lon, p.door.lat).first }
                val (_, pos, sgn) = project(cs[p.chain], p.door.lon, p.door.lat)
                p.door.sect = "$orl:${p.chain}"; p.door.pos = pos; p.door.sgn = sgn
            }
        }
    }
}

/**
 * Where to go when a row is done. The rule is what a soulwinner on foot would do:
 *  1. across the street, if that side still has open homes (and is in the same neighbourhood: a border is a main road);
 *  2. otherwise the nearest open row in the same neighbourhood, measured from where you finished;
 *     when you're working flats, the nearest open flat in the neighbourhood (if one is within 400 m);
 *  3. when the neighbourhood is done: nothing. Choosing a new area is a decision for the map, not a guess.
 * Promise (neighbourhood figures) deliberately plays no part here: it's for choosing an area, not the next street in it.
 */
class NextRow(val row: Row, val stop: Stop, val metres: Double)

object Next {
    /** The neighbourhood most of the row's homes are in (a long street can cross a border). */
    fun area(r: Row): String = r.stops.flatMap { it.doors }.groupingBy { it.territory }.eachCount().maxBy { it.value }.key

    fun choose(all: Collection<List<Row>>, cur: Row, end: Stop, taken: Set<String>): NextRow? {
        fun nearestOpen(r: Row) = r.stops.filter { s -> s.doors.any { it.isNew } }.minByOrNull { end.dist(it) }
        val home = area(cur)
        // neighbourhood borders run along main roads: the far side of one is not "across the street"
        val rows = all.flatten().filter { it.key != cur.key && area(it) == home }
        rows.filter { it.facing(cur) }.mapNotNull { r -> nearestOpen(r)?.let { NextRow(r, it, end.dist(it)) } }
            .minByOrNull { it.metres }?.let { return it }
        val cands = rows.filter { it.street == cur.street || it.street !in taken }
            .mapNotNull { r -> nearestOpen(r)?.let { NextRow(r, it, end.dist(it)) } }
        if (end.isBuilding) cands.filter { it.stop.isBuilding && it.metres < 400 }.minByOrNull { it.metres }?.let { return it }
        return cands.minByOrNull { it.metres }
    }
}
