package nl.barnosho.harvest

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import org.json.JSONObject

/**
 * The map: vector tiles (OpenFreeMap, OpenStreetMap data) drawn by MapLibre, sharp at any zoom like Google Maps.
 * Harvest's own layers (homes, route, numbers, flats, neighbourhoods) are defined in assets/map_layers.json
 * and fed with GeoJSON. Everything MapLibre-specific lives in this file.
 *
 * With live = false (screen tests on a machine without a graphics chip) it's an empty view that keeps the
 * camera as numbers, so all the logic around it still runs.
 */
class HMap(private val ctx: Context, private val live: Boolean, private val dark: Boolean, saved: Bundle?) {
    val view: View
    private var map: org.maplibre.android.maps.MapLibreMap? = null
    private var style: org.maplibre.android.maps.Style? = null
    private val pending = LinkedHashMap<String, String>()   // data set before the style finished loading
    private var areasVisible = false
    private var fakeLat = 52.2; private var fakeLon = 6.9; private var fakeZoom = 17.0

    var onReady: () -> Unit = {}
    var onTap: (x: Float, y: Float, lat: Double, lon: Double) -> Unit = { _, _, _, _ -> }
    var onIdle: () -> Unit = {}

    init {
        if (live) {
            org.maplibre.android.MapLibre.getInstance(ctx)
            // the default drawing surface (faster than TextureView); the map is never detached, so it doesn't need TextureView
            val mv = org.maplibre.android.maps.MapView(ctx)
            mv.onCreate(saved)
            mv.setMaximumFps(60)   // 120 Hz panning costs twice the GPU work for no visible gain on a map
            view = mv
            mv.getMapAsync { m ->
                map = m
                // the position asked for before the map existed
                m.moveCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(org.maplibre.android.geometry.LatLng(fakeLat, fakeLon), fakeZoom))
                m.uiSettings.isLogoEnabled = false
                m.prefetchZoomDelta = 2                           // prefetch two zoom levels up instead of four
                m.uiSettings.isRotateGesturesEnabled = false      // north stays up: streets keep their place
                m.uiSettings.isTiltGesturesEnabled = false
                m.uiSettings.attributionGravity = Gravity.TOP or Gravity.START
                m.uiSettings.setAttributionMargins(dp(8), dp(70), 0, 0)
                m.setStyle(org.maplibre.android.maps.Style.Builder().fromJson(styleJson())) { s ->
                    style = s
                    addBoxes(s)
                    for ((k, v) in pending) source(k)?.setGeoJson(v)
                    pending.clear()
                    setAreas(areasVisible)
                    baseDim?.let { d -> baseDim = null; setBaseDim(d) }
                    onReady()
                }
                m.addOnMapClickListener { ll ->
                    val p = m.projection.toScreenLocation(ll)
                    onTap(p.x, p.y, ll.latitude, ll.longitude); true
                }
                m.addOnCameraIdleListener { onIdle() }
            }
        } else view = View(ctx)
    }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    /** The base map (light, or the colour-keeping dark version) with Harvest's layers on top, in our colours. */
    private fun styleJson(): String {
        val base = JSONObject(ctx.assets.open(if (dark) "map_dark.json" else "map_light.json").bufferedReader().readText())
        var extraTxt = ctx.assets.open("map_layers.json").bufferedReader().readText()
        val pal = mapOf("INK" to C.INK, "MUTED" to C.MUTED, "PAPER" to C.PAPER, "PRIMARY" to C.PRIMARY, "FIELD" to C.FIELD, "WHEAT" to C.WHEAT)
        for ((k, v) in pal) extraTxt = extraTxt.replace("{$k}", hex(v))
        val extra = JSONObject(extraTxt)
        val src = base.getJSONObject("sources"); val es = extra.getJSONObject("sources")
        for (k in es.keys()) src.put(k, es.get(k))
        val layers = base.getJSONArray("layers"); val el = extra.getJSONArray("layers")
        for (i in 0 until el.length()) layers.put(el.get(i))
        return base.toString()
    }

    /** The rounded boxes behind flat labels: stretchable, so "8" and "112" both fit. */
    private fun addBoxes(s: org.maplibre.android.maps.Style) {
        val d = ctx.resources.displayMetrics.density
        fun box(fill: Int, stroke: Int): Bitmap {
            val w = (40 * d).toInt(); val h = (28 * d).toInt()
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(b); val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val r = RectF(2 * d, 2 * d, w - 2 * d, h - 2 * d)
            p.color = fill; c.drawRoundRect(r, 7 * d, 7 * d, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f * d; p.color = stroke; c.drawRoundRect(r, 7 * d, 7 * d, p)
            return b
        }
        val sx = listOf(org.maplibre.android.maps.ImageStretches(10 * d, 30 * d))
        val sy = listOf(org.maplibre.android.maps.ImageStretches(9 * d, 19 * d))
        val content = org.maplibre.android.maps.ImageContent(8 * d, 6 * d, 32 * d, 22 * d)
        s.addImage("h-box", box(C.CARD, C.PRIMARY), false, sx, sy, content)
        s.addImage("h-box-done", box(C.DONE, C.MUTED), false, sx, sy, content)
        s.addImage("h-box-care", box(C.DONE, C.MUTED), false, sx, sy, content)
    }

    private fun source(id: String) = style?.getSourceAs<org.maplibre.android.style.sources.GeoJsonSource>(id)

    /**
     * After destroy() MapLibre's style throws on every call ("Calling getSourceAs when a newer style is loading").
     * Work that finishes late (a reload, an import) must never reach it: every entry point below is a no-op then.
     */
    private var dead = false
    /** Calls that arrived after destroy() and were ignored: the tests check the activity makes none. */
    var lateCalls = 0; private set
    private fun gone(): Boolean { if (dead) lateCalls++; return dead }

    fun setData(id: String, geojson: String) {
        if (gone()) return
        if (!live) return
        val s = source(id)
        if (s == null) pending[id] = geojson else s.setGeoJson(geojson)
    }

    private var baseDim: Boolean? = null

    /** Fade every home outside the row in focus: one paint property, no data sent. */
    fun setBaseDim(dim: Boolean) {
        if (gone()) return
        if (baseDim == dim && style != null) return
        baseDim = dim
        style?.getLayer("h-homes")?.setProperties(
            org.maplibre.android.style.layers.PropertyFactory.circleOpacity(if (dim) 0.45f else 1f),
            org.maplibre.android.style.layers.PropertyFactory.circleStrokeOpacity(if (dim) 0.35f else 1f))
    }

    fun setAreas(on: Boolean) {
        if (gone()) return
        areasVisible = on
        val s = style ?: return
        for (id in listOf("h-areas-fill", "h-areas-line", "h-anames"))
            s.getLayer(id)?.setProperties(org.maplibre.android.style.layers.PropertyFactory.visibility(if (on) "visible" else "none"))
    }

    // ---------- camera ----------
    fun zoom(): Double = map?.cameraPosition?.zoom ?: fakeZoom
    fun center(): Pair<Double, Double> = map?.cameraPosition?.target?.let { it.latitude to it.longitude } ?: (fakeLat to fakeLon)

    /** south, west, north, east of what's on screen */
    fun bounds(): DoubleArray {
        val b = map?.projection?.visibleRegion?.latLngBounds
        if (b != null) return doubleArrayOf(b.latitudeSouth, b.longitudeWest, b.latitudeNorth, b.longitudeEast)
        val dLat = 0.004 * Math.pow(2.0, 17 - fakeZoom); val dLon = dLat * 1.6
        return doubleArrayOf(fakeLat - dLat, fakeLon - dLon, fakeLat + dLat, fakeLon + dLon)
    }

    fun contains(lat: Double, lon: Double): Boolean { val b = bounds(); return lat in b[0]..b[2] && lon in b[1]..b[3] }

    /** Centre on a point; bottomPad keeps it in the part of the map not covered by a panel. */
    fun moveTo(lat: Double, lon: Double, zoom: Double? = null, bottomPad: Int = 0, animate: Boolean = true) {
        if (gone()) return
        fakeLat = lat; fakeLon = lon; if (zoom != null) fakeZoom = zoom
        val m = map ?: return
        val cp = org.maplibre.android.camera.CameraPosition.Builder()
            .target(org.maplibre.android.geometry.LatLng(lat, lon))
            .zoom(zoom ?: m.cameraPosition.zoom)
            .padding(0.0, 0.0, 0.0, bottomPad.toDouble())
            .build()
        val u = org.maplibre.android.camera.CameraUpdateFactory.newCameraPosition(cp)
        if (animate) m.animateCamera(u, 450) else m.moveCamera(u)
    }

    /** Ids of Harvest features drawn near a screen point, nearest first. */
    fun featuresNear(x: Float, y: Float, radius: Float, vararg layers: String): List<String> {
        if (gone()) return emptyList()
        val m = map ?: return emptyList()
        val fs = m.queryRenderedFeatures(RectF(x - radius, y - radius, x + radius, y + radius), *layers)
        return fs.mapNotNull { f ->
            val id = f.getStringProperty("id") ?: return@mapNotNull null
            val pt = f.geometry() as? org.maplibre.geojson.Point
            val d = if (pt != null) m.projection.toScreenLocation(org.maplibre.android.geometry.LatLng(pt.latitude(), pt.longitude())).let { Math.hypot((it.x - x).toDouble(), (it.y - y).toDouble()) } else 0.0
            id to d
        }.sortedBy { it.second }.map { it.first }.distinct()
    }

    // ---------- lifecycle, forwarded from the activity ----------
    private val mv get() = view as? org.maplibre.android.maps.MapView
    private var started = false; private var resumed = false
    fun start() { if (live && !dead && !started) { started = true; mv?.onStart() } }
    fun resume() { if (live && !dead && !resumed) { resumed = true; mv?.onResume() } }
    fun pause() { if (live && resumed) { resumed = false; mv?.onPause() } }
    fun stop() { if (live && started) { started = false; mv?.onStop() } }
    fun destroy() { if (dead) return; dead = true; if (live) mv?.onDestroy(); style = null; map = null; pending.clear() }
    fun lowMemory() { if (live && !dead) mv?.onLowMemory() }
    fun save(b: Bundle) { if (live) mv?.onSaveInstanceState(b) }

    companion object {
        fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)
    }
}

/** Small GeoJSON writer: fast enough to redraw a few thousand homes on every tap. */
class Geo {
    private val sb = StringBuilder(1 shl 16).append("{\"type\":\"FeatureCollection\",\"features\":[")
    private var first = true

    private fun open(): StringBuilder { if (!first) sb.append(','); first = false; return sb.append("{\"type\":\"Feature\",") }

    fun point(lat: Double, lon: Double, vararg props: Pair<String, Any?>) {
        open().append("\"geometry\":{\"type\":\"Point\",\"coordinates\":[").append(lon).append(',').append(lat).append("]},")
        props(props); sb.append('}')
    }

    fun line(pts: List<Pair<Double, Double>>, vararg props: Pair<String, Any?>) {
        if (pts.size < 2) return
        open().append("\"geometry\":{\"type\":\"LineString\",\"coordinates\":[")
        pts.forEachIndexed { i, (la, lo) -> if (i > 0) sb.append(','); sb.append('[').append(lo).append(',').append(la).append(']') }
        sb.append("]},"); props(props); sb.append('}')
    }

    /** rings as [lon, lat, lon, lat, …] */
    fun polygons(rings: List<DoubleArray>, vararg props: Pair<String, Any?>) {
        open().append("\"geometry\":{\"type\":\"MultiPolygon\",\"coordinates\":[")
        rings.forEachIndexed { ri, r ->
            if (ri > 0) sb.append(','); sb.append("[[")
            var i = 0
            while (i < r.size) { if (i > 0) sb.append(','); sb.append('[').append(r[i]).append(',').append(r[i + 1]).append(']'); i += 2 }
            sb.append("]]")
        }
        sb.append("]},"); props(props); sb.append('}')
    }

    private fun props(p: Array<out Pair<String, Any?>>) {
        sb.append("\"properties\":{")
        p.forEachIndexed { i, (k, v) ->
            if (i > 0) sb.append(','); sb.append('"').append(k).append("\":")
            when (v) {
                null -> sb.append("null")
                is Boolean, is Number -> sb.append(v)
                else -> sb.append(JSONObject.quote(v.toString()))
            }
        }
        sb.append('}')
    }

    fun json(): String = sb.toString() + "]}"
}
