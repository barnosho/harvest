package nl.barnosho.harvest

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.util.UUID

/** Outcomes a door can get. Order = button order. */
enum class Outcome(val label: String, val color: Int) {
    NOT_HOME("Not home", 0xFF7F909C.toInt()),
    NOT_INTERESTED("Not interested", 0xFFB0564B.toInt()),
    PRESENTED("Gospel presented", 0xFF3E6C9E.toInt()),
    TALKED("Talked", 0xFF5E8F6B.toInt()),
    SAVED("Saved", 0xFFC79A1E.toInt()),
    RETURN("Return visit", 0xFF7556A3.toInt()),
    DO_NOT_KNOCK("Don't knock", 0xFF2E3230.toInt());

    companion object {
        fun of(s: String?) = values().firstOrNull { it.name == s }
    }
}

class Door(
    val id: String, val territory: String, val street: String, val num: String,
    val postcode: String, val lat: Double, val lon: Double,
    val building: String? = null,     // set when this home is one of several behind one entrance (a flat)
) {
    val label get() = "$street $num"
    var outcome: Outcome? = null      // latest outcome this round
    var ts: Long = 0                  // time of latest outcome this round
    var by: String = ""               // who recorded it
    var notHomeCount = 0              // not-home visits this round
    var dnk = false                   // marked "don't knock" (survives new rounds)
    var dist = Double.MAX_VALUE       // metres from current position
    var sect = ""                     // which piece of the street's centre line this home faces
    var pos = 0.0                     // metres along that line
    var sgn = 0                       // side of the line: +1 / -1, or 0 when there's no street line
    var built = 0                     // construction year of a flat's building (0: unknown or a house)
    var care = false                  // the building also has a care function (often homes for the elderly)
    val isNew get() = outcome == null && !dnk

    /** A knock just recorded on this phone: update the house in memory instead of reloading everything. */
    fun apply(o: Outcome, at: Long, who: String) {
        if (o == Outcome.DO_NOT_KNOCK) dnk = true
        outcome = o; ts = at; by = who
        if (o == Outcome.NOT_HOME) notHomeCount++
    }
    val isAgain get() = outcome == Outcome.NOT_HOME && !dnk
}

class Territory(val code: String, val name: String, val gemeente: String, val roundStart: Long, val imported: Boolean)

class Claim(val user: String, val street: String, val row: String, val ts: Long)

class Db(ctx: Context, name: String = "harvest.db") : SQLiteOpenHelper(ctx, name, null, 4) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
        db.execSQL("CREATE TABLE territory(code TEXT PRIMARY KEY, name TEXT, gemeente TEXT, round_start INTEGER, deleted INTEGER, imported INTEGER, updated INTEGER, dirty INTEGER)")
        db.execSQL("CREATE TABLE address(id TEXT PRIMARY KEY, territory TEXT, street TEXT, num TEXT, postcode TEXT, lat REAL, lon REAL, building TEXT, sect TEXT, pos REAL, sgn INTEGER, built INTEGER, care INTEGER)")
        db.execSQL("CREATE INDEX address_t ON address(territory)")
        db.execSQL("CREATE TABLE visit(id TEXT PRIMARY KEY, address_id TEXT, outcome TEXT, count INTEGER, ts INTEGER, lat REAL, lon REAL, user TEXT, session_id TEXT, note TEXT, voided INTEGER, updated INTEGER, dirty INTEGER)")
        db.execSQL("CREATE INDEX visit_ts ON visit(ts)")
        db.execSQL("CREATE TABLE session(id TEXT PRIMARY KEY, user TEXT, start INTEGER, last INTEGER, ended INTEGER, updated INTEGER, dirty INTEGER)")
        db.execSQL("CREATE TABLE followup(id TEXT PRIMARY KEY, address_id TEXT, label TEXT, name TEXT, note TEXT, due INTEGER, done INTEGER, user TEXT, updated INTEGER, dirty INTEGER)")
        createStats(db)
        createClaims(db)
    }

    private fun createClaims(db: SQLiteDatabase) =
        db.execSQL("CREATE TABLE IF NOT EXISTS claim(id TEXT PRIMARY KEY, user TEXT, street TEXT, row TEXT, ts INTEGER, updated INTEGER, dirty INTEGER)")

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) {
            // v2: homes only and flats grouped, so every neighbourhood is loaded again (visits are kept)
            for (c in listOf("building TEXT", "sect TEXT", "pos REAL", "sgn INTEGER")) db.execSQL("ALTER TABLE address ADD COLUMN $c")
            db.execSQL("UPDATE territory SET imported=0")
            createClaims(db)
        }
        if (o < 3) {
            // v3: building year and care function for flats, neighbourhood figures; neighbourhoods load again (visits are kept)
            for (c in listOf("built INTEGER", "care INTEGER")) db.execSQL("ALTER TABLE address ADD COLUMN $c")
            // reload only where you've knocked; everything else loads again when you look at it, so the first launch stays quick
            val worked = db.rawQuery("SELECT DISTINCT a.territory FROM visit v JOIN address a ON a.id=v.address_id", null).use { c ->
                buildList { while (c.moveToNext()) add(c.getString(0)) } }
            val keep = worked.joinToString(",") { "'" + it.replace("'", "") + "'" }.ifEmpty { "''" }
            db.execSQL("DELETE FROM address WHERE territory NOT IN ($keep)")
            db.execSQL("DELETE FROM territory WHERE code NOT IN ($keep)")
            db.execSQL("UPDATE territory SET imported=0")
        }
        if (o < 3) createStats(db)
        if (o < 4) {
            // v4: knocks looked up per house; neighbourhood figures findable by map area (a cache, so it simply starts over)
            db.execSQL("DROP TABLE IF EXISTS buurt_stat"); createStats(db)
            db.execSQL("CREATE INDEX IF NOT EXISTS visit_addr ON visit(address_id)")
        }
    }

    private fun createStats(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS buurt_stat(code TEXT PRIMARY KEY, json TEXT, updated INTEGER, lat REAL, lon REAL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS buurt_stat_pos ON buurt_stat(lat, lon)")
    }

    // ---------- neighbourhood figures (CBS), cached ----------
    fun saveStats(list: List<BuurtStat>) {
        val db = writableDatabase; val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            for (s in list) db.insertWithOnConflict("buurt_stat", null, ContentValues().apply {
                put("code", s.code); put("json", s.toJson().toString()); put("updated", now); put("lat", s.lat); put("lon", s.lon)
            }, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun parseStats(sql: String, args: Array<String>): Map<String, BuurtStat> = readableDatabase.rawQuery(sql, args).use { c ->
        buildMap { while (c.moveToNext()) try { BuurtStat.fromJson(JSONObject(c.getString(0))).let { put(it.code, it) } } catch (e: Exception) {} }
    }

    fun allStats(): Map<String, BuurtStat> = parseStats("SELECT json FROM buurt_stat", arrayOf())

    /** Only the neighbourhoods whose middle lies in (or near) a map area: what the explore map draws. */
    fun statsIn(south: Double, west: Double, north: Double, east: Double): Map<String, BuurtStat> {
        val pl = (north - south) * 0.3; val po = (east - west) * 0.3
        return parseStats("SELECT json FROM buurt_stat WHERE lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?",
            arrayOf("${south - pl}", "${north + pl}", "${west - po}", "${east + po}"))
    }

    /** Figures for just the neighbourhoods being knocked: all scoring needs while on the doors. */
    fun statsFor(codes: Collection<String>): Map<String, BuurtStat> =
        if (codes.isEmpty()) emptyMap() else parseStats("SELECT json FROM buurt_stat WHERE code IN (${codes.joinToString(",") { "?" }})", codes.toTypedArray())

    class Outing(val start: Long, val last: Long, val user: String, val doors: Int, val presented: Int, val saved: Int, val area: String)

    /** Every outing, newest first: when, where, how long, and what came of it. */
    fun outings(limit: Int = 20): List<Outing> {
        val out = ArrayList<Outing>()
        readableDatabase.rawQuery("SELECT id,user,start,last FROM session ORDER BY start DESC LIMIT $limit", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0)
                val (n, p, sv) = readableDatabase.rawQuery(
                    "SELECT COUNT(*), SUM(outcome IN ('PRESENTED','SAVED')), SUM(CASE WHEN outcome='SAVED' THEN MAX(count,1) ELSE 0 END) FROM visit WHERE session_id=? AND voided=0 AND outcome!='DO_NOT_KNOCK'", arrayOf(id)
                ).use { v -> v.moveToFirst(); Triple(v.getInt(0), v.getInt(1), v.getInt(2)) }
                if (n == 0) continue
                val area = readableDatabase.rawQuery(
                    "SELECT t.name, COUNT(*) k FROM visit v JOIN address a ON a.id=v.address_id JOIN territory t ON t.code=a.territory WHERE v.session_id=? AND v.voided=0 GROUP BY t.code ORDER BY k DESC LIMIT 1", arrayOf(id)
                ).use { a -> if (a.moveToFirst()) a.getString(0) else "" }
                out += Outing(c.getLong(2), c.getLong(3), c.getString(1) ?: "", n, p, sv, area)
            }
        }
        return out
    }

    /** Per loaded neighbourhood: homes, and homes knocked this round. A finished neighbourhood stops being recommended. */
    fun coverage(): Map<String, Pair<Int, Int>> = readableDatabase.rawQuery(
        "SELECT a.territory, COUNT(*), SUM(EXISTS(SELECT 1 FROM visit v WHERE v.address_id=a.id AND v.voided=0 AND v.ts>=t.round_start)) " +
        "FROM address a JOIN territory t ON t.code=a.territory GROUP BY a.territory", null
    ).use { c -> buildMap { while (c.moveToNext()) put(c.getString(0), c.getInt(1) to c.getInt(2)) } }

    /** Your team's own results per neighbourhood, from every recorded knock there. */
    fun observed(): Map<String, Observed> = readableDatabase.rawQuery(
        "SELECT a.territory, COUNT(*), SUM(v.outcome IN ('PRESENTED','SAVED')), SUM(CASE WHEN v.outcome='SAVED' THEN MAX(v.count,1) ELSE 0 END) " +
        "FROM visit v JOIN address a ON a.id=v.address_id WHERE v.voided=0 AND v.outcome!='DO_NOT_KNOCK' GROUP BY a.territory", null
    ).use { c -> buildMap { while (c.moveToNext()) put(c.getString(0), Observed(c.getInt(1), c.getInt(2), c.getInt(3))) } }

    // ---------- meta ----------
    fun get(k: String, def: String = ""): String =
        readableDatabase.rawQuery("SELECT v FROM meta WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else def }

    fun set(k: String, v: String) {
        writableDatabase.insertWithOnConflict("meta", null, ContentValues().apply { put("k", k); put("v", v) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    val user get() = get("user", "Me")

    // ---------- territories ----------
    fun territories(): List<Territory> = readableDatabase.rawQuery(
        "SELECT code,name,gemeente,round_start,imported FROM territory WHERE deleted=0 ORDER BY name", null
    ).use { c -> buildList { while (c.moveToNext()) add(Territory(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4) == 1)) } }

    /** share=false: loaded automatically because you were there or looked at it; teammates don't need it pushed. */
    fun putTerritory(code: String, name: String, gemeente: String, share: Boolean = true) {
        val now = System.currentTimeMillis()
        writableDatabase.insertWithOnConflict("territory", null, ContentValues().apply {
            put("code", code); put("name", name); put("gemeente", gemeente); put("round_start", 0L)
            put("deleted", 0); put("imported", 0); put("updated", now); put("dirty", if (share) 1 else 0)
        }, SQLiteDatabase.CONFLICT_IGNORE)
        writableDatabase.execSQL("UPDATE territory SET deleted=0 WHERE code=? AND deleted=1", arrayOf(code))
    }

    fun knockCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM visit WHERE voided=0", null).use { it.moveToFirst(); it.getInt(0) }

    /** Wipes test knocks: every recorded visit is voided (so teammates' phones drop them too), sessions and follow-ups go. */
    fun eraseKnocks() {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE visit SET voided=1, updated=?, dirty=1 WHERE voided=0", arrayOf(now))
        writableDatabase.execSQL("DELETE FROM session")
        writableDatabase.execSQL("UPDATE followup SET done=1, updated=?, dirty=1 WHERE done=0", arrayOf(now))
    }

    fun newRound(code: String) {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE territory SET round_start=?, updated=?, dirty=1 WHERE code=?", arrayOf(now, now, code))
    }

    fun removeTerritory(code: String) {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE territory SET deleted=1, updated=?, dirty=1 WHERE code=?", arrayOf(now, code))
    }

    fun saveAddresses(code: String, list: List<Door>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("address", "territory=?", arrayOf(code))
            for (d in list) db.insertWithOnConflict("address", null, ContentValues().apply {
                put("id", d.id); put("territory", code); put("street", d.street); put("num", d.num)
                put("postcode", d.postcode); put("lat", d.lat); put("lon", d.lon); put("building", d.building)
                put("sect", d.sect); put("pos", d.pos); put("sgn", d.sgn); put("built", d.built); put("care", if (d.care) 1 else 0)
            }, SQLiteDatabase.CONFLICT_REPLACE)
            db.execSQL("UPDATE territory SET imported=1 WHERE code=?", arrayOf(code))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** All doors of active territories, with their status folded from the visit log. */
    /** The homes of the given neighbourhoods (the ones being knocked), with each home's state folded from its knocks. */
    fun doors(codes: Collection<String>): List<Door> {
        if (codes.isEmpty()) return emptyList()
        val terr = territories().associateBy { it.code }
        val doors = LinkedHashMap<String, Door>()
        val inList = codes.joinToString(",") { "?" }
        val args = codes.toTypedArray()
        readableDatabase.rawQuery(
            "SELECT a.id,a.territory,a.street,a.num,a.postcode,a.lat,a.lon,a.building,a.sect,a.pos,a.sgn,a.built,a.care FROM address a JOIN territory t ON t.code=a.territory AND t.deleted=0 WHERE a.territory IN ($inList)", args
        ).use { c -> while (c.moveToNext()) doors[c.getString(0)] = Door(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getDouble(5), c.getDouble(6), c.getString(7)).apply {
            sect = c.getString(8) ?: ""; pos = c.getDouble(9); sgn = c.getInt(10); built = c.getInt(11); care = c.getInt(12) == 1
        } }
        readableDatabase.rawQuery("SELECT v.address_id,v.outcome,v.ts,v.user FROM visit v JOIN address a ON a.id=v.address_id " +
            "WHERE v.voided=0 AND a.territory IN ($inList) ORDER BY v.ts", args).use { c ->
            while (c.moveToNext()) {
                val d = doors[c.getString(0)] ?: continue
                val o = Outcome.of(c.getString(1)) ?: continue
                val ts = c.getLong(2)
                if (o == Outcome.DO_NOT_KNOCK) d.dnk = true
                if (ts < (terr[d.territory]?.roundStart ?: 0)) continue
                d.outcome = o; d.ts = ts; d.by = c.getString(3) ?: ""
                if (o == Outcome.NOT_HOME) d.notHomeCount++
            }
        }
        return doors.values.toList()
    }

    /** Re-read one house's state, after a knock on it was replaced or undone. */
    fun refreshDoor(d: Door) {
        val roundStart = readableDatabase.rawQuery("SELECT round_start FROM territory WHERE code=?", arrayOf(d.territory)).use { if (it.moveToFirst()) it.getLong(0) else 0L }
        d.outcome = null; d.ts = 0; d.by = ""; d.notHomeCount = 0; d.dnk = false
        readableDatabase.rawQuery("SELECT outcome,ts,user FROM visit WHERE address_id=? AND voided=0 ORDER BY ts", arrayOf(d.id)).use { c ->
            while (c.moveToNext()) {
                val o = Outcome.of(c.getString(0)) ?: continue
                if (o == Outcome.DO_NOT_KNOCK) d.dnk = true
                if (c.getLong(1) < roundStart) continue
                d.outcome = o; d.ts = c.getLong(1); d.by = c.getString(2) ?: ""
                if (o == Outcome.NOT_HOME) d.notHomeCount++
            }
        }
    }

    // ---------- visits & sessions ----------
    private val sessionGap = 60 * 60 * 1000L

    /** Returns the open session id, starting a new one if the last one went quiet for an hour. */
    private fun sessionFor(now: Long): String {
        val me = user
        readableDatabase.rawQuery("SELECT id,last FROM session WHERE user=? AND ended=0 ORDER BY start DESC LIMIT 1", arrayOf(me)).use { c ->
            if (c.moveToFirst()) {
                val id = c.getString(0)
                if (now - c.getLong(1) < sessionGap) {
                    writableDatabase.execSQL("UPDATE session SET last=?, updated=?, dirty=1 WHERE id=?", arrayOf(now, now, id))
                    return id
                }
                writableDatabase.execSQL("UPDATE session SET ended=1, updated=?, dirty=1 WHERE id=?", arrayOf(now, id))
            }
        }
        val id = UUID.randomUUID().toString()
        writableDatabase.insert("session", null, ContentValues().apply {
            put("id", id); put("user", me); put("start", now); put("last", now); put("ended", 0); put("updated", now); put("dirty", 1)
        })
        return id
    }

    fun openSession(): Pair<Long, Long>? {
        readableDatabase.rawQuery("SELECT start,last FROM session WHERE user=? AND ended=0 ORDER BY start DESC LIMIT 1", arrayOf(user)).use { c ->
            if (!c.moveToFirst()) return null
            val start = c.getLong(0); val last = c.getLong(1)
            return if (System.currentTimeMillis() - last < sessionGap) start to last else null
        }
    }

    fun endSession() {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE session SET ended=1, updated=?, dirty=1 WHERE user=? AND ended=0", arrayOf(now, user))
    }

    fun record(door: Door, o: Outcome, count: Int, lat: Double?, lon: Double?, note: String = ""): String {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val sid = sessionFor(now)
        writableDatabase.insert("visit", null, ContentValues().apply {
            put("id", id); put("address_id", door.id); put("outcome", o.name); put("count", count); put("ts", now)
            if (lat != null) put("lat", lat); if (lon != null) put("lon", lon)
            put("user", user); put("session_id", sid); put("note", note); put("voided", 0); put("updated", now); put("dirty", 1)
        })
        return id
    }

    fun lastVisitId(addressId: String): String? = readableDatabase.rawQuery(
        "SELECT id FROM visit WHERE address_id=? AND voided=0 ORDER BY ts DESC LIMIT 1", arrayOf(addressId)
    ).use { if (it.moveToFirst()) it.getString(0) else null }

    fun void(visitId: String) {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE visit SET voided=1, updated=?, dirty=1 WHERE id=?", arrayOf(now, visitId))
    }

    // ---------- follow-ups ----------
    class FollowUp(val id: String, val addressId: String, val label: String, val name: String, val note: String, val due: Long, val user: String)

    fun addFollowUp(door: Door, name: String, note: String, due: Long): String {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        writableDatabase.insert("followup", null, ContentValues().apply {
            put("id", id); put("address_id", door.id); put("label", "${door.label}, ${door.postcode}")
            put("name", name); put("note", note); put("due", due); put("done", 0); put("user", user); put("updated", now); put("dirty", 1)
        })
        return id
    }

    fun followUps(): List<FollowUp> = readableDatabase.rawQuery(
        "SELECT id,address_id,label,name,note,due,user FROM followup WHERE done=0 ORDER BY due", null
    ).use { c -> buildList { while (c.moveToNext()) add(FollowUp(c.getString(0), c.getString(1), c.getString(2), c.getString(3) ?: "", c.getString(4) ?: "", c.getLong(5), c.getString(6) ?: "")) } }

    fun doneFollowUp(id: String) {
        val now = System.currentTimeMillis()
        writableDatabase.execSQL("UPDATE followup SET done=1, updated=?, dirty=1 WHERE id=?", arrayOf(now, id))
    }

    // ---------- stats ----------
    class Stats(var doors: Int = 0, var answered: Int = 0, var presented: Int = 0, var saved: Int = 0, var returns: Int = 0, var minutes: Long = 0)

    fun stats(from: Long, onlyMe: Boolean): Stats {
        val s = Stats()
        val who = if (onlyMe) " AND user=?" else ""
        val args = if (onlyMe) arrayOf(from.toString(), user) else arrayOf(from.toString())
        readableDatabase.rawQuery("SELECT outcome,count FROM visit WHERE voided=0 AND ts>=?$who", args).use { c ->
            while (c.moveToNext()) {
                val o = Outcome.of(c.getString(0)) ?: continue
                if (o == Outcome.DO_NOT_KNOCK) continue
                s.doors++
                if (o != Outcome.NOT_HOME) s.answered++
                if (o == Outcome.PRESENTED || o == Outcome.SAVED) s.presented++
                if (o == Outcome.SAVED) s.saved += maxOf(1, c.getInt(1))
                if (o == Outcome.RETURN) s.returns++
            }
        }
        readableDatabase.rawQuery("SELECT start,last FROM session WHERE last>=?$who", args).use { c ->
            // a session with one door still counts a few minutes
            while (c.moveToNext()) s.minutes += maxOf(5L, (c.getLong(1) - maxOf(c.getLong(0), from)) / 60000 + 5)
        }
        return s
    }

    /** Knocks and answers per hour of the day, whole team, all time. */
    fun byHour(): Array<IntArray> {
        val out = Array(24) { IntArray(2) }
        val cal = java.util.Calendar.getInstance()
        readableDatabase.rawQuery("SELECT outcome,ts FROM visit WHERE voided=0 AND outcome!='DO_NOT_KNOCK'", null).use { c ->
            while (c.moveToNext()) {
                cal.timeInMillis = c.getLong(1)
                val h = cal.get(java.util.Calendar.HOUR_OF_DAY)
                out[h][0]++
                if (c.getString(0) != "NOT_HOME") out[h][1]++
            }
        }
        return out
    }

    // ---------- claims: which street each pair is working on ----------
    fun setClaim(street: String, row: String) {
        val now = System.currentTimeMillis()
        writableDatabase.insertWithOnConflict("claim", null, ContentValues().apply {
            put("id", user); put("user", user); put("street", street); put("row", row); put("ts", now); put("updated", now); put("dirty", 1)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    /** Other pairs' current streets, from the last 3 hours. */
    fun otherClaims(): List<Claim> = readableDatabase.rawQuery(
        "SELECT user,street,row,ts FROM claim WHERE user!=? AND street!='' AND ts>?", arrayOf(user, (System.currentTimeMillis() - 3 * 3_600_000L).toString())
    ).use { c -> buildList { while (c.moveToNext()) add(Claim(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getLong(3))) } }

    // ---------- sync plumbing ----------
    private val tables = mapOf(
        "territory" to "code", "visit" to "id", "session" to "id", "followup" to "id", "claim" to "id"
    )
    private val localOnly = setOf("dirty", "imported")

    /** Dirty rows as sync events. */
    fun dirtyEvents(): List<JSONObject> = buildList {
        for ((t, key) in tables) readableDatabase.rawQuery("SELECT * FROM $t WHERE dirty=1", null).use { c ->
            while (c.moveToNext()) {
                val body = JSONObject()
                for (i in 0 until c.columnCount) {
                    val col = c.getColumnName(i)
                    if (col in localOnly) continue
                    when (c.getType(i)) {
                        android.database.Cursor.FIELD_TYPE_INTEGER -> body.put(col, c.getLong(i))
                        android.database.Cursor.FIELD_TYPE_FLOAT -> body.put(col, c.getDouble(i))
                        android.database.Cursor.FIELD_TYPE_STRING -> body.put(col, c.getString(i))
                    }
                }
                add(JSONObject().put("kind", t).put("id", body.getString(key)).put("updated", body.getLong("updated")).put("body", body))
            }
        }
    }

    /**
     * Moves the pull position forward, only if the team is still the one the sync started with.
     * Returns false (and changes nothing) when the team changed in the meantime: those events belong to the old team.
     */
    @Synchronized fun commitPull(team: String, seq: Long): Boolean {
        if (get("team") != team) return false
        set("since", seq.toString()); set("lastSync", System.currentTimeMillis().toString())
        return true
    }

    /** Joining or leaving a team: same lock as commitPull, so a sync finishing at that moment can't slip in between. */
    @Synchronized fun setTeam(server: String?, team: String) {
        if (server != null) set("server", server)
        set("team", team); set("since", "0")
    }

    fun markSent(events: List<JSONObject>) {
        for (e in events) {
            val t = e.getString("kind"); val key = tables[t] ?: continue
            writableDatabase.execSQL("UPDATE $t SET dirty=0 WHERE $key=? AND updated=?", arrayOf(e.getString("id"), e.getLong("updated")))
        }
    }

    /** Applies remote events; newer `updated` wins. Returns how many rows actually changed. */
    fun applyRemote(events: List<JSONObject>): Int {
        var changed = 0
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (e in events) {
                val t = e.getString("kind"); val key = tables[t] ?: continue
                val body = e.getJSONObject("body"); val id = e.getString("id")
                val localUpdated = db.rawQuery("SELECT updated FROM $t WHERE $key=?", arrayOf(id)).use { if (it.moveToFirst()) it.getLong(0) else -1L }
                if (localUpdated >= body.getLong("updated")) continue
                changed++
                val cv = ContentValues()
                for (k in body.keys()) when (val v = body.get(k)) {
                    is Int -> cv.put(k, v.toLong()); is Long -> cv.put(k, v); is Double -> cv.put(k, v)
                    is String -> cv.put(k, v)
                }
                cv.put("dirty", 0)
                if (t == "territory") {
                    val imported = db.rawQuery("SELECT imported FROM territory WHERE code=?", arrayOf(id)).use { if (it.moveToFirst()) it.getInt(0) else 0 }
                    cv.put("imported", imported)
                }
                db.insertWithOnConflict(t, null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return changed
    }

    // ---------- export / import: everything in one file, merged on import ----------

    /** areaCodes: every neighbourhood the file had homes for, so the app can show them without going online. */
    class ImportResult(val changed: Int, val homes: Int, val areas: Int, val areaCodes: Set<String>)

    /**
     * Writes everything to one JSON file: neighbourhoods with their homes, every knock (voided ones too, so an
     * undo travels along), outings, follow-ups, street claims, the neighbourhood figures, and your name.
     * Not the team code: importing a file on a test phone must never make it sync into the real team.
     */
    fun exportTo(out: java.io.OutputStream) {
        val w = android.util.JsonWriter(java.io.OutputStreamWriter(out, Charsets.UTF_8))
        w.beginObject()
        w.name("app").value("harvest"); w.name("format").value(1)
        w.name("exported").value(System.currentTimeMillis()); w.name("user").value(user)
        w.name("tables").beginObject()
        for (t in tables.keys + listOf("address", "buurt_stat")) {
            w.name(t).beginArray()
            readableDatabase.rawQuery("SELECT * FROM $t", null).use { c ->
                while (c.moveToNext()) {
                    w.beginObject()
                    for (i in 0 until c.columnCount) {
                        val col = c.getColumnName(i)
                        if (col in localOnly) continue
                        when (c.getType(i)) {
                            android.database.Cursor.FIELD_TYPE_INTEGER -> w.name(col).value(c.getLong(i))
                            android.database.Cursor.FIELD_TYPE_FLOAT -> w.name(col).value(c.getDouble(i))
                            android.database.Cursor.FIELD_TYPE_STRING -> w.name(col).value(c.getString(i))
                        }
                    }
                    w.endObject()
                }
            }
            w.endArray()
        }
        w.endObject(); w.endObject(); w.flush()
    }

    /**
     * Merges an export into this phone, like a sync does: for every knock, outing, follow-up, claim and
     * neighbourhood the newest change wins, whichever side it's on. Importing the same file twice changes nothing.
     * Homes are copied for neighbourhoods this phone hasn't loaded yet, so it works offline right away.
     * Rows that came in are marked to sync, so they reach your team if this phone has one.
     */
    fun importFrom(input: java.io.InputStream): ImportResult {
        val root = try { JSONObject(input.bufferedReader(Charsets.UTF_8).readText()) } catch (e: Exception) { throw Exception("This isn't a Harvest export file.") }
        if (root.optString("app") != "harvest") throw Exception("This isn't a Harvest export file.")
        if (root.optInt("format") > 1) throw Exception("This file comes from a newer version of Harvest. Update the app first.")
        val tbl = root.getJSONObject("tables")
        fun rows(t: String) = tbl.optJSONArray(t)?.let { a -> (0 until a.length()).map { a.getJSONObject(it) } } ?: emptyList()
        fun cv(o: JSONObject, cols: Set<String>) = ContentValues().apply {
            for (k in o.keys()) { if (k !in cols) continue; when (val v = o.get(k)) { is Int -> put(k, v.toLong()); is Long -> put(k, v); is Double -> put(k, v); is String -> put(k, v) } }
        }
        val db = writableDatabase
        fun columns(t: String) = db.rawQuery("SELECT * FROM $t LIMIT 0", null).use { it.columnNames.toSet() }
        var changed = 0; var homes = 0; var areas = 0; val inFile = HashSet<String>()
        db.beginTransaction()
        try {
            for ((t, key) in tables) {
                val cols = columns(t)
                for (o in rows(t)) {
                    val id = o.optString(key); if (id.isEmpty()) continue
                    val local = db.rawQuery("SELECT updated FROM $t WHERE $key=?", arrayOf(id)).use { if (it.moveToFirst()) it.getLong(0) else -1L }
                    if (local >= o.optLong("updated")) continue
                    val v = cv(o, cols); v.put("dirty", 1)
                    if (t == "territory") v.put("imported", db.rawQuery("SELECT imported FROM territory WHERE code=?", arrayOf(id)).use { if (it.moveToFirst()) it.getInt(0) else 0 })
                    db.insertWithOnConflict(t, null, v, SQLiteDatabase.CONFLICT_REPLACE); changed++
                }
            }
            // homes: only for neighbourhoods this phone hasn't loaded; a loaded one keeps its own (it may be newer)
            val loaded = db.rawQuery("SELECT code FROM territory WHERE imported=1", null).use { c -> buildSet { while (c.moveToNext()) add(c.getString(0)) } }
            val aCols = columns("address"); val filled = HashSet<String>()
            for (o in rows("address")) {
                val t = o.optString("territory"); if (t.isEmpty()) continue
                inFile += t
                if (t in loaded) continue
                if (filled.add(t)) db.delete("address", "territory=?", arrayOf(t))
                db.insertWithOnConflict("address", null, cv(o, aCols), SQLiteDatabase.CONFLICT_REPLACE); homes++
            }
            for (t in filled) db.execSQL("UPDATE territory SET imported=1 WHERE code=?", arrayOf(t))
            areas = filled.size
            // neighbourhood figures are a cache: fill in what's missing
            val sCols = columns("buurt_stat")
            for (o in rows("buurt_stat")) db.insertWithOnConflict("buurt_stat", null, cv(o, sCols), SQLiteDatabase.CONFLICT_IGNORE)
            // your name, if this phone doesn't have one yet
            val name = root.optString("user")
            if (name.isNotBlank() && get("user", "").let { it.isEmpty() || it == "Me" }) set("user", name)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return ImportResult(changed, homes, areas, inFile)
    }
}
