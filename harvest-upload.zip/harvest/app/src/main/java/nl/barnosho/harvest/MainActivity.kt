package nl.barnosho.harvest

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Point
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import java.security.SecureRandom
import java.util.concurrent.Executors
import kotlin.math.cos
import kotlin.math.sqrt

class MainActivity : Activity(), LocationListener {
    companion object {
        var autoLoad = true    // screen tests switch these off: fixed data, and no graphics chip for the map
        var useMap = true
        /** Where a neighbourhood's homes come from. Tests swap in a fake that fails or blocks. */
        var addressSource: (String) -> List<Door> = { Pdok.addresses(it) }
        /** How a sync runs. Tests swap in a fake so they don't need a server. */
        var syncRunner: (Db) -> Sync.Result = { Sync.run(it) }
        /** A walk left untouched this long is over: you went home without tapping Finish. */
        const val STALE_WALK = 8 * 3_600_000L
    }

    private lateinit var db: Db
    private val main = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()        // network lookups and neighbourhood imports (slow)
    private val syncEx = Executors.newSingleThreadExecutor()    // team sync only: never queued behind an import
    /** Set in onDestroy. Background work that finishes later must not touch this activity or its map any more. */
    private var gone = false

    private var doors: List<Door> = emptyList()
    private var lat: Double? = null
    private var lon: Double? = null
    private var tab = 0
    private var againMode = false
    private var selectedId: String? = null
    private var syncState = ""
    private val importing = HashSet<String>()

    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private var hmap: HMap? = null
    private lateinit var navLine: View

    // ================= lifecycle =================

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        C.init((resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)
        db = Db(this)

        val root = vbox()
        root.fitsSystemWindows = true
        content = FrameLayout(this)
        root.add(content, weight = 1f)
        navLine = divider()
        root.add(navLine, h = 1)
        nav = hbox()
        root.add(nav, h = 60)
        setContentView(root)

        target = db.get("target").ifEmpty { null }?.takeIf { (db.get("targetAt").toLongOrNull() ?: 0) > System.currentTimeMillis() - 12 * 3600_000L }
        work = db.get("work").split(',').filter { it.isNotBlank() }.toSet() + listOfNotNull(target)
        reload()
        rowKey = db.get("row").ifEmpty { null }
        insideId = db.get("inside").ifEmpty { null }
        knocking = db.get("knocking") == "true"
        db.get("again").toLongOrNull()?.let { againMode = true; againSince = it }
        rowAnchor = db.get("anchor").ifEmpty { null }
        if (knocking && android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        asc = db.get("asc", "true") == "true"
        lastId = db.get("last").ifEmpty { null }
        // where you were in the row: a dark-mode switch at sunset recreates the activity, and Android may close it in your pocket
        selectedId = db.get("sel").ifEmpty { null }; savedSel = selectedId
        db.get("skipped").split(',').filter { it.isNotBlank() }.let { skipped += it; savedSkipped = it.joinToString(",") }
        if (knocking && db.get("walkAt").isEmpty()) db.set("walkAt", "${System.currentTimeMillis()}")
        show(0)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        else startLocation()
        importMissing()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.any { it == PackageManager.PERMISSION_GRANTED }) startLocation()
    }

    private val syncLoop = object : Runnable {
        override fun run() { sync(quiet = true); main.postDelayed(this, 30_000) }
    }

    override fun onResume() {
        super.onResume(); lifecycleResumed = true; hmap?.resume()
        main.post(syncLoop)
    }

    override fun onPause() {
        super.onPause(); lifecycleResumed = false; hmap?.pause()
        main.removeCallbacks(syncLoop)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            knocking && tab == 0 -> confirmFinish()
            tab != 0 -> show(0)
            else -> super.onBackPressed()
        }
    }

    // ================= location =================

    @Suppress("MissingPermission")
    private fun startLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        // GPS every 3 s is plenty to place you at a house; Wi-Fi/cell positioning only as a slow indoor fallback
        for ((p, every, metres) in listOf(Triple(LocationManager.GPS_PROVIDER, 3000L, 3f), Triple(LocationManager.NETWORK_PROVIDER, 20_000L, 20f))) {
            if (!lm.allProviders.contains(p)) continue
            lm.getLastKnownLocation(p)?.let { if (lat == null) onLocationChanged(it) }
            lm.requestLocationUpdates(p, every, metres, this)
        }
    }

    /** No GPS while the app isn't on screen: in your pocket, between doors, after you leave it. */
    private fun stopLocation() = (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this)

    private var lastSortLat = 0.0
    private var lastSortLon = 0.0

    override fun onLocationChanged(l: Location) {
        lat = l.latitude; lon = l.longitude
        if (distance(l.latitude, l.longitude, lastSortLat, lastSortLon) > 8) {
            lastSortLat = l.latitude; lastSortLon = l.longitude
            measure()
            // the knock screen never moves because of GPS; the home card may update its suggestion
            // update the suggestion in place; never rebuild or move the map you might be looking around on
            if (tab == 0 && !knocking && !userPicked && mapCard != null) suggestedRow()?.let { k -> if (k != pickKey) { setPick(k); fillMapCard(); bringPickIntoView() } }
        }
        gpsHint(if (l.hasAccuracy()) l.accuracy else 99f)
        updateMe()
        // only on foot: driving to another town must not load every neighbourhood along the way
        if (!(l.hasSpeed() && l.speed > 3f)) settleThenUpdate(l.latitude, l.longitude)
    }

    // ---------- the working set: only where you are is in memory ----------
    // The neighbourhoods within ~600 m of you (so a border crossing never leaves an empty map), plus a destination
    // you picked in "Where to knock". Everything else stays on disk until you're there again.
    private var work: Set<String> = emptySet()
    private var target: String? = null
    private var workLat = Double.NaN
    private var workLon = Double.NaN

    private var candLat = Double.NaN; private var candLon = Double.NaN; private var candAt = 0L

    /** Update the working set once you've stayed within ~150 m for half a minute (or straight away the first time). */
    private fun settleThenUpdate(la: Double, lo: Double) {
        if (workLat.isNaN()) { updateWorkingSet(la, lo); return }
        if (distance(la, lo, workLat, workLon) < 300) { candLat = Double.NaN; return }
        val now = System.currentTimeMillis()
        if (candLat.isNaN() || distance(la, lo, candLat, candLon) > 150) { candLat = la; candLon = lo; candAt = now; return }
        if (now - candAt >= 30_000) { candLat = Double.NaN; updateWorkingSet(la, lo) }
    }

    private fun updateWorkingSet(la: Double, lo: Double) {
        if (!autoLoad || gone) return
        if (!workLat.isNaN() && distance(la, lo, workLat, workLon) < 300) return
        workLat = la; workLon = lo
        bg.execute {
            val near = try { Pdok.buurtenIn(la - 0.0055, lo - 0.009, la + 0.0055, lo + 0.009) } catch (e: Exception) { null }
            main.post { if (gone) return@post; if (near != null && near.isNotEmpty()) setWork(near) else workLat = Double.NaN }   // retry on the next fix
        }
    }

    private fun setWork(near: List<Pdok.Buurt>) {
        for (b in near) db.putTerritory(b.code, b.name, b.gemeente, share = false)
        val codes = near.map { it.code }.toSet() + listOfNotNull(target)
        if (codes == work) return
        work = codes
        db.set("work", codes.joinToString(","))
        importMissing()
        reloadAsync()
    }

    /** Choose a destination in "Where to knock": it joins the working set and the map goes there. */
    private fun chooseTarget(st: BuurtStat) {
        target = st.code
        db.set("target", st.code); db.set("targetAt", "${System.currentTimeMillis()}")
        db.putTerritory(st.code, st.name, st.gemeente, share = false)
        work = work + st.code; db.set("work", work.joinToString(","))
        centerOnce = Triple(st.lat, st.lon, 16.0); userPicked = false; setPick(null); areaPick = null
        importMissing(); reloadAsync()
        show(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}

    private fun distance(a: Double, b: Double, c: Double, d: Double): Double {
        val x = (d - b) * cos(Math.toRadians((a + c) / 2)) * 111320
        val y = (c - a) * 110540
        return sqrt(x * x + y * y)
    }

    private fun measure() {
        val la = lat; val lo = lon
        for (d in doors) d.dist = if (la == null || lo == null) Double.MAX_VALUE else distance(la, lo, d.lat, d.lon)
    }

    private val io = Executors.newSingleThreadExecutor()   // reading (imports run on `bg`, so a long import never delays the map)
    private var reloadGen = 0

    /** Startup only: the working set is small, so this is quick. Everything later uses reloadAsync. */
    private fun reload() { coverage = db.coverage(); applyData(db.doors(work), db.observed(), db.statsFor(work)) }
    private var coverage: Map<String, Pair<Int, Int>> = emptyMap()

    /**
     * Counts knocks recorded on this phone. A reload reads the database on another thread; if you tap while it
     * reads, its result is from before your tap and would put that house back to "open" (and send you back to it).
     */
    private var writeSeq = 0

    /** Everything a reload reads, and which knocks it already includes. */
    internal class Snapshot(val gen: Int, val seq: Int, val doors: List<Door>, val seen: Map<String, Observed>,
                            val stats: Map<String, BuurtStat>, val cov: Map<String, Pair<Int, Int>>, val rows: Map<String, List<Row>>)

    private fun readSnapshot(codes: List<String>, gen: Int, seq: Int): Snapshot {
        val d = db.doors(codes)
        return Snapshot(gen, seq, d, db.observed(), db.statsFor(codes), db.coverage(), Walks.rows(d))
    }

    private fun reloadAsync() {
        if (gone) return
        val codes = work.toList(); val gen = ++reloadGen; val seq = writeSeq
        try { io.execute { val snap = readSnapshot(codes, gen, seq); main.post { deliver(snap) } } }
        catch (e: java.util.concurrent.RejectedExecutionException) {}   // shutting down
    }

    private fun deliver(snap: Snapshot) {
        if (gone || snap.gen != reloadGen) return
        if (snap.seq != writeSeq) { reloadAsync(); return }   // you tapped while it read: read again
        coverage = snap.cov; applyData(snap.doors, snap.seen, snap.stats, snap.rows); refreshAfterData()
    }

    private fun applyData(d: List<Door>, o: Map<String, Observed>, st: Map<String, BuurtStat>, r: Map<String, List<Row>> = Walks.rows(d)) {
        doors = d; rows = r; indexRows(); measure(); seen = o; bstats = st; scoreCache.clear()
        refreshBase()
        // row keys are positions in a street's list, which shift when a neighbouring area adds homes to the street
        (selectedId?.let { rowOfDoor[it] } ?: rowAnchor?.let { rowOfDoor[it] })?.let { rowKey = it }
        pickDoor?.let { rowOfDoor[it] }?.let { pickKey = it }
    }
    private var rowAnchor: String? = null   // a door in the row you're on

    /** New data arrived (moved into a new area, an import finished, a teammate's knocks): update what's on screen in place. */
    private fun refreshAfterData() {
        when {
            tab == 0 && mapHost?.parent == content -> {
                if (knocking) { if (currentStop() == null || walkStops().isEmpty()) renderOverlay() else { refreshMap(); updateChip() } }
                else { if (!userPicked || rowOf(pickKey) == null) setPick(suggestedRow()); fillMapCard(); refreshMap(); updateChip() }
            }
            tab == 0 -> show(0)          // first homes arrived: from the empty screen to the map
            tab == 3 -> show(3)
        }
    }

    // ---------- where people are likely to be receptive ----------
    private var bstats: Map<String, BuurtStat> = emptyMap()
    private var seen: Map<String, Observed> = emptyMap()
    private fun areaScore(code: String) = Receptivity.buurt(bstats[code], seen[code])
    private val scoreCache = HashMap<String, Int>()
    private fun stopScore(s: Stop) = scoreCache.getOrPut(s.id) { Receptivity.stop(s, areaScore(s.first.territory)) }
    private fun rowScore(r: Row) = r.stops.filter { st -> st.doors.any { it.isNew } }.maxOfOrNull { stopScore(it) } ?: 0

    /** Distances for suggestions: from you, or from the middle of the map when you're planning somewhere else. */
    private fun refPoint(): Pair<Double, Double>? {
        val c = hmap?.center()
        val la = lat; val lo = lon
        if (la != null && lo != null && (c == null || distance(la, lo, c.first, c.second) < 1500)) return la to lo
        return c ?: (if (la != null && lo != null) la to lo else null)
    }

    private var pickDoor: String? = null    // a door in the row picked on the map

    // ================= navigation =================

    // Follow-ups are rare: no tab. Home links to them when one is due.
    private val tabs = listOf(0 to "Map", 3 to "Stats", 4 to "Setup")

    private fun buildNav() {
        nav.removeAllViews()
        for ((i, name) in tabs) {
            val on = i == tab
            // the active tab: its name in green with a short bar above it
            val cell = vbox().apply { gravity = Gravity.CENTER_HORIZONTAL; setOnClickListener { show(i) } }
            cell.add(View(this).apply { background = rounded(if (on) C.FIELD else 0x00000000, dp(2).toFloat()) }, w = 28, h = 3)
            cell.add(text(name, 14f, if (on) C.FIELD else C.MUTED, bold = on).apply { gravity = Gravity.CENTER }, w = -2, top = 12)
            nav.add(cell, weight = 1f, h = -1)
        }
    }

    private fun show(i: Int) {
        tab = if (i == 1) 0 else i
        buildNav()
        nav.visibility = if (knocking && tab == 0) View.GONE else View.VISIBLE   // knocking: nothing but the map and the door
        navLine.visibility = nav.visibility
        if (tab == 0 && doors.isNotEmpty()) {
            // the map is made once and never detached; only what lies on top of it changes
            if (mapHost == null) { content.addView(mapHostView(), 0); if (lifecycleStarted) hmap?.start(); if (lifecycleResumed) hmap?.resume() }
            cover?.let { content.removeView(it) }; cover = null
            if (mapDirty) refreshMap()
            meLat = Double.NaN; updateMe()
            renderOverlay()
            return
        }
        // Stats, Setup: laid over the map, which stays attached (its drawing surface survives) and isn't asked to draw
        val v = when (tab) { 0 -> emptyHome(); 2 -> followUpsScreen(); 3 -> statsScreen(); else -> setupScreen() }
        v.setBackgroundColor(C.PAPER); v.isClickable = true
        cover?.let { content.removeView(it) }
        cover = v; content.addView(v)
    }
    private var cover: View? = null
    private var lifecycleStarted = false
    private var lifecycleResumed = false

    override fun onStart() {
        super.onStart(); lifecycleStarted = true
        // you went home without tapping Finish: don't greet you with yesterday's street over the lock screen
        if (knocking && walkStale()) { endWalk(Lock.NOW); show(0) }
        hmap?.start(); startLocation()
    }
    override fun onStop() {
        super.onStop(); lifecycleStarted = false; stopLocation(); hmap?.stop()
        if (!knocking && android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(false)
    }
    override fun onDestroy() {
        // A dark-mode switch at sunset recreates the activity; anything still running for this one is dropped
        gone = true
        main.removeCallbacksAndMessages(null)
        bg.shutdown(); io.shutdown(); syncEx.shutdown()   // threads finish what they're doing, then end
        hmap?.destroy()
        super.onDestroy()
    }
    override fun onLowMemory() { super.onLowMemory(); hmap?.lowMemory() }

    private fun refreshIfPassive() {
        when {
            tab == 0 && knocking -> refreshMap()          // teammates' knocks appear as dots; the panel stays as it is
            tab == 0 -> { fillMapCard(); refreshMap() }
            tab in 2..3 -> show(tab)
        }
    }

    // ================= HOME (planning) and KNOCK (focus mode) =================
    // Planning happens at home or in the car. Knocking is one full-screen loop:
    // see the door, knock, record on the walk to the next one. One phone per pair records.

    private var knocking = false
    private var rows: Map<String, List<Row>> = emptyMap()
    private var rowKey: String? = null      // "street|index"
    private var asc = true
    private var insideId: String? = null    // the flat we're inside, if any
    private var flash = ""                  // one-line confirmation of the last tap
    private var hintId: String? = null      // GPS thinks we're at this stop
    private var statusView: android.widget.TextView? = null

    private var againSince = 0L             // second try started; a door tried since then is done for this pass
    private fun pending(d: Door) = if (againMode) d.isAgain && d.ts < againSince else d.isNew
    private fun beginAgain() { againMode = true; againSince = System.currentTimeMillis() }
    private fun open(s: Stop) = s.doors.any { pending(it) }
    private fun rowOf(key: String?) = key?.let { k -> rows[k.substringBeforeLast('|')]?.getOrNull(k.substringAfterLast('|').toIntOrNull() ?: -1) }
    private fun curRow() = rowOf(rowKey)
    private fun stopOf(door: Door): Pair<Row, Stop>? =
        rows[door.street]?.firstNotNullOfOrNull { r -> r.stops.firstOrNull { s -> s.doors.any { it.id == door.id } }?.let { r to it } }
    private fun insideStop() = insideId?.let { id -> curRow()?.stops?.firstOrNull { it.id == id } }

    /** What you walk right now, in order: the row (in your direction) or the homes inside a flat. */
    private fun walkStops(): List<Stop> {
        insideStop()?.let { b -> return b.doors.map { Stop(listOf(it)) } }
        val r = curRow() ?: return emptyList()
        return if (asc) r.stops else r.stops.reversed()
    }

    private fun saveWalk() {
        db.set("row", rowKey ?: ""); db.set("asc", "$asc"); db.set("inside", insideId ?: ""); db.set("knocking", "$knocking")
        db.set("again", if (againMode) "$againSince" else ""); db.set("anchor", rowAnchor ?: ""); db.set("last", lastId ?: "")
        db.set("walkAt", "${System.currentTimeMillis()}")
        val r = curRow()
        db.setClaim(if (knocking && r != null) r.street else "", r?.range ?: "")
        scheduleSync()
    }

    /** Begin a row at a stop, walking towards the longer stretch of open stops. */
    private fun enterRow(r: Row, at: Stop?) {
        rowKey = r.key; insideId = null; rowAnchor = r.stops.first().id; skipped.clear(); focusedId = null; lastId = null
        val i = if (at == null) -1 else r.stops.indexOf(at)
        if (at != null && i >= 0) {
            val after = r.stops.drop(i + 1).count { open(it) }; val before = r.stops.take(i).count { open(it) }
            asc = after >= before
        }
        selectedId = at?.id ?: (if (asc) r.stops else r.stops.reversed()).firstOrNull { open(it) }?.id
        saveWalk()
    }

    private fun startAt(d: Door) {
        // a second try is one pass: switching rows keeps it, so homes already tried again don't come back
        if (d.isAgain && !d.isNew) { if (!againMode) beginAgain() } else againMode = false
        val (r, s) = stopOf(d) ?: return
        enterRow(r, s)
    }

    /** The stop you recorded last in this row (a flat counts as one stop). Your direction runs from it. */
    private var lastId: String? = null

    /**
     * Where to go after a stop: the next open one the way you're walking. When nothing is left ahead, the nearest
     * open one behind you, and from there you walk back that way. Never a jump to the far start of the row.
     * Stops skipped for now come last. Inside a flat: simply the next home that's still open.
     */
    private fun advanceFrom(id: String?): Stop? {
        val (s, behind) = findNext(id) ?: return null
        if (behind && insideStop() == null) { asc = !asc; db.set("asc", "$asc") }
        return s
    }

    /** The next stop after `id` and whether it lies behind you. Changes nothing, so drawing code can use it too. */
    private fun findNext(id: String?): Pair<Stop, Boolean>? {
        val l = walkStops()
        val i = l.indexOfFirst { it.id == id }
        fun nearest(ok: (Stop) -> Boolean): Pair<Stop, Boolean>? {
            l.drop(i + 1).firstOrNull(ok)?.let { return it to false }
            return l.take(maxOf(i, 0)).asReversed().firstOrNull(ok)?.let { it to true }
        }
        return nearest { open(it) && it.id !in skipped } ?: nearest { open(it) }
    }

    /**
     * You went to another house of the row (tapped it on the map, or took the GPS hint). If it's still open, that's
     * where you are now, and the direction follows you: away from the house you recorded last, or, at the start of
     * a row, towards the longer stretch of open houses (start at 20 in 10–20 and you walk 18, 16, ...).
     * Going back to a house you already recorded is a correction and changes nothing about the direction.
     */
    private fun jumpTo(s: Stop) {
        selectedId = s.id
        if (insideStop() != null || !open(s)) return
        val nat = curRow()?.stops ?: return
        val j = nat.indexOfFirst { it.id == s.id }; if (j < 0) return
        val k = lastId?.let { id -> nat.indexOfFirst { it.id == id } } ?: -1
        asc = if (k >= 0 && k != j) j > k else nat.drop(j + 1).count { open(it) } >= nat.take(j).count { open(it) }
        db.set("asc", "$asc")
    }

    private var claimsAt = 0L
    private var claimsCache: Map<String, String> = emptyMap()
    private fun claimedByOthers(): Map<String, String> {
        val now = System.currentTimeMillis()
        if (now - claimsAt > 20_000) { claimsCache = db.otherClaims().associate { it.street to it.user }; claimsAt = now }
        return claimsCache
    }

    /** Nearest open home in a street nobody else is on (or anywhere, if every open street is taken). */
    private fun nearestOpen(): Door? {
        val taken = claimedByOthers().keys
        val c = doors.filter { it.isNew }
        val free = c.filter { it.street !in taken }.ifEmpty { c }
        return if (lat != null) free.minByOrNull { it.dist } else free.sortedWith(compareBy<Door>({ it.street }).then(numOrder)).firstOrNull()
    }

    /**
     * Where to go when a row is done: the nearest open home in another row, measured from where you stand.
     * The other side of the same street counts double-close, because crossing is what you'd naturally do.
     */
    /** Across the street, else the nearest open row in this neighbourhood; null when the neighbourhood is done. See Next. */
    private fun nextRow(): Pair<Row, Stop>? {
        val cur = curRow() ?: return null
        val end = walkStops().lastOrNull() ?: return null
        val n = Next.choose(rows.values, cur, end, claimedByOthers().keys) ?: return null
        nextMetres = n.metres
        return n.row to n.stop
    }
    private var nextMetres = 0.0

    private fun rowTitle(r: Row) = "${r.street} ${r.range}"

    private fun nextLabel(r: Row): String {
        val cur = curRow()
        return when {
            cur != null && r.facing(cur) -> "Across the street: ${r.range}"
            cur != null && r.street == cur.street -> "Continue: ${r.range}"
            else -> "Next: ${rowTitle(r)}, ${fmtDist(nextMetres)}"
        }
    }

    private fun startKnocking(d: Door?) {
        if (d != null) startAt(d)
        knocking = true; focusedId = null; saveWalk()
        if (android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        show(0)
    }

    private fun finishKnocking() {
        endWalk(Lock.UNLOCK)
        show(0)
    }

    /** What happens to "show over the lock screen" when a walk ends. */
    private enum class Lock {
        UNLOCK,  // you tapped Finish: ask to unlock, and keep showing until you have (or the screen goes off)
        LATER,   // the walk ended by itself while you're looking: keep showing until the screen goes off
        NOW      // a walk left over from earlier: never show it over the lock screen again
    }

    /**
     * The only way out of knocking. Ends the outing, the street claim, the second try and the lock-screen view
     * together, so no path leaves one of them behind.
     */
    private fun endWalk(lock: Lock) {
        db.endSession()
        knocking = false; againMode = false; insideId = null; userPicked = false; pickKey = null; pickDoor = null
        lastId = null; skipped.clear(); switchOffer = null
        saveWalk()
        when (lock) {
            Lock.UNLOCK -> leaveLockScreen()
            Lock.LATER -> {}   // onStop drops it
            Lock.NOW -> if (android.os.Build.VERSION.SDK_INT >= 27) setShowWhenLocked(false)
        }
    }

    private fun walkStale() = System.currentTimeMillis() - (db.get("walkAt").toLongOrNull() ?: System.currentTimeMillis()) > STALE_WALK

    /**
     * While knocking, Harvest shows over the lock screen, so the phone is usually still locked when you tap Finish.
     * Simply switching that off hides the app behind the lock screen, which looks like the app closing. Instead,
     * ask the phone to unlock (fingerprint or face) and only then stop showing over the lock screen.
     */
    private fun leaveLockScreen() {
        if (android.os.Build.VERSION.SDK_INT < 27) return
        val km = getSystemService(android.app.KeyguardManager::class.java)
        if (km == null || !km.isKeyguardLocked) { setShowWhenLocked(false); return }
        km.requestDismissKeyguard(this, object : android.app.KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { if (!knocking) setShowWhenLocked(false) }
            // cancelled or replaced by another request: don't hide the app you're looking at; onStop drops it
        })
    }

    // ---------- home ----------

    private fun todayStart() = java.util.Calendar.getInstance().apply {
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
    }.timeInMillis

    // ---------- knock mode: a panel over the map ----------
    // The map is one persistent layer for the whole app. Planning puts a card over it; knocking puts the
    // door panel over it and keeps the map on the house you're at, with the row's numbers drawn on it.

    private val skipped = HashSet<String>()       // stops skipped "for now": they wait until the end of the row
    private var switchOffer: Door? = null         // a house tapped in another row, offered as a switch
    private var knockPanel: View? = null
    private var focusedId: String? = null

    private fun currentStop(): Stop? {
        val l = walkStops()
        l.firstOrNull { it.id == selectedId }?.let { return it }
        // nothing chosen yet: carry on from the house you recorded last, the way you were walking
        if (insideStop() == null) lastId?.let { id -> findNext(id)?.first }?.let { return it }
        return l.firstOrNull { open(it) && it.id !in skipped } ?: l.firstOrNull { open(it) }
    }

    private var savedSel: String? = null
    private var savedSkipped = ""
    /** Written whenever the knock panel is drawn, which is after every change of the current house. */
    private fun persistPosition() {
        if (selectedId != savedSel) { savedSel = selectedId; db.set("sel", selectedId ?: "") }
        val sk = skipped.joinToString(",")
        if (sk != savedSkipped) { savedSkipped = sk; db.set("skipped", sk) }
    }

    private fun stepTo(delta: Int) {
        val l = walkStops(); val i = l.indexOfFirst { it.id == selectedId }
        val to = l.getOrNull(if (i < 0) 0 else i + delta) ?: return
        selectedId = to.id; flash = ""; hintId = null; switchOffer = null; renderOverlay()
    }

    private fun buildKnockOverlay(layer: FrameLayout) {
        if (curRow() == null) { nearestOpen()?.let { startAt(it) } }
        val row = curRow()
        if (row == null) { endWalk(Lock.LATER); buildPlanOverlay(layer); return }
        val building = insideStop()
        val l = walkStops()
        val cur = currentStop()
        selectedId = cur?.id
        persistPosition()
        val left = l.count { open(it) }

        // top: only what changes how you work right now, as quiet pills; the layer switch on the right
        val info = vbox()
        claimedByOthers()[row.street]?.let { info.add(pill("$it is also on this street", square(Outcome.NOT_INTERESTED.color)), w = -2, top = 0) }
        if (againMode) info.add(pill("Second try: only homes that weren't home", square(Outcome.RETURN.color)), w = -2, top = if (info.childCount > 0) 8 else 0)
        topBar(layer, info)

        val bottom = vbox()
        val center = pill(if (cur != null) "Back to ${cur.label}" else "Back to the row") { focusedId = null; focusCurrent() }
        bottom.add(center, w = -2); (center.layoutParams as LinearLayout.LayoutParams).apply { gravity = Gravity.END; rightMargin = dp(12); bottomMargin = dp(12) }

        // the panel rises from the bottom edge: full width, rounded top, a soft shadow over the map
        val panel = vbox().apply { background = sheetSurface(C.PAPER); setPadding(dp(20), dp(16), dp(20), dp(12)); lift(8) }
        knockPanel = panel
        val head = hbox()
        val title = if (building != null) "${row.street} ${building.label}, inside" else rowTitle(row)
        head.add(text(title, 15f, C.MUTED, bold = true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }, weight = 1f)
        head.add(text(if (left == 0) "done" else "$left left", 15f, C.MUTED), w = -2, side = 8)
        panel.add(head)
        // how far along the row you are
        val total = l.size.coerceAtLeast(1)
        panel.add(progressLine((total - left).toFloat() / total), h = 3, top = 10)

        if (cur != null) {
            // the house you're at, with a step back and forward; any other house: tap it on the map
            val nr = hbox()
            val i = l.indexOf(cur)
            fun arrow(s: String, d: Int, enabled: Boolean) = text(s, 30f, if (enabled) C.INK else C.LINE).apply {
                gravity = Gravity.CENTER; setPadding(dp(18), dp(4), dp(18), dp(4)); minHeight = dp(56); minWidth = dp(56)
                if (enabled) setOnClickListener { stepTo(d) }
            }
            nr.add(arrow("‹", -1, i > 0), w = -2)
            val mid = vbox().apply { gravity = Gravity.CENTER }
            mid.add(text(cur.label, if (cur.isBuilding) 32f else 50f, serif = true).apply { gravity = Gravity.CENTER; maxLines = 1; includeFontPadding = false })
            if (cur.isBuilding) mid.add(text("flat, ${cur.doors.size} homes", 13f, C.MUTED).apply { gravity = Gravity.CENTER })
            nr.add(mid, weight = 1f)
            nr.add(arrow("›", 1, i < l.size - 1), w = -2)
            panel.add(nr, top = 10)
        }
        // it doubles as a button (Switch to…, You seem to be at…, change): a full 48 dp target
        val sv = text("", 15f, C.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(6)); minHeight = dp(48) }
        statusView = sv
        panel.add(sv)
        updateStatus(cur)

        when {
            cur == null -> panel.add(endOfRow())
            cur.isBuilding -> {
                val b = cur
                panel.add(button("Go inside: ${b.doors.count { pending(it) }} homes", C.PRIMARY, C.ON_PRIMARY, height = 84) {
                    insideId = b.id; selectedId = null; saveWalk(); renderOverlay()
                }.apply { textSize = 21f })
                panel.add(button("Skip this flat", C.CARD, C.INK, 56) { skip(b) }, top = 8)
            }
            else -> {
                val door = cur.first
                panel.add(button("Not home", C.PRIMARY, C.ON_PRIMARY, height = 84) { v -> record(door, Outcome.NOT_HOME, v) }.apply { textSize = 23f })
                val rowB = hbox()
                rowB.add(button("Not interested", C.CARD, C.INK, 64) { v -> record(door, Outcome.NOT_INTERESTED, v) }, weight = 1f)
                rowB.add(button("We talked", C.CARD, C.INK, 64) { v -> v.performHapticFeedback(HapticFeedbackConstants.CONFIRM); talkedSheet(door) }, weight = 1f, side = 10)
                panel.add(rowB, top = 8)
            }
        }
        val foot = hbox()
        foot.add(text("More", 16f, C.MUTED).apply { setPadding(0, dp(6), dp(32), 0); minHeight = dp(48); gravity = Gravity.CENTER_VERTICAL; setOnClickListener { moreSheet(cur) } }, w = -2)
        foot.add(View(this), weight = 1f, h = 1)
        foot.add(text("Finish", 16f, C.MUTED).apply { setPadding(dp(32), dp(6), 0, 0); minHeight = dp(48); gravity = Gravity.CENTER_VERTICAL; setOnClickListener { confirmFinish() } }, w = -2)
        panel.add(foot)
        bottom.add(panel)
        layer.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        flash = ""
        layer.post { focusCurrent() }
    }

    private fun skip(s: Stop) {
        skipped += s.id
        selectedId = advanceFrom(s.id)?.id
        flash = "${s.label} skipped for now"; flashStop = null
        renderOverlay()
    }

    /** Keep the map on the house you're at, centred in the part of the map the panel doesn't cover. */
    private fun focusCurrent() {
        val m = hmap ?: return
        val t = currentStop()?.first ?: nextRow()?.second?.first ?: return   // end of the row: show where to go next
        val key = "${t.lat},${t.lon}"
        if (key == focusedId) return
        focusedId = key
        val panelH = knockPanel?.height ?: 0
        m.moveTo(t.lat, t.lon, if (m.zoom() < 17.8) 18.6 else null, bottomPad = panelH)
    }

    private fun updateStatus(cur: Stop?) {
        val sv = statusView ?: return
        val hint = hintId?.let { id -> walkStops().firstOrNull { it.id == id } }
        sv.setOnClickListener(null)
        sv.setTextColor(C.MUTED)
        val d = cur?.first
        val offer = switchOffer
        sv.text = when {
            offer != null -> {
                sv.setTextColor(C.FIELD)
                sv.setOnClickListener { switchOffer = null; startAt(offer); focusedId = null; renderOverlay() }
                "Switch to ${stopOf(offer)?.first?.let { rowTitle(it) } ?: offer.label}  ›"
            }
            flash.isNotEmpty() -> {
                sv.setTextColor(C.INK)
                // the house you just recorded, one tap away: ‹ doesn't always lead back to it (after a turn, or a jump)
                val back = flashStop?.let { id -> walkStops().firstOrNull { it.id == id } }
                if (back != null && back.id != cur?.id) {
                    sv.setOnClickListener { selectedId = back.id; flash = ""; flashStop = null; focusedId = null; renderOverlay() }
                    android.text.SpannableStringBuilder(flash).apply {
                        append("  ·  ")
                        val st = length; append("change")
                        setSpan(android.text.style.ForegroundColorSpan(C.FIELD), st, length, 0)
                    }
                } else flash
            }
            hint != null && hint.id != cur?.id -> {
                sv.setTextColor(C.FIELD)
                sv.setOnClickListener { jumpTo(hint); hintId = null; renderOverlay() }
                "You seem to be at ${hint.label}. Tap to go there."
            }
            cur == null -> ""
            cur.isBuilding -> ""
            d!!.dnk -> "Marked don't knock"
            d.outcome != null && !pending(d) -> "${d.outcome!!.label}, ${fmtAgo(d.ts)}. Tap a button to change it."
            d.outcome == Outcome.NOT_HOME -> "Not home before" + if (d.notHomeCount > 1) " (${d.notHomeCount} times)" else ""
            // homes inside a flat aren't on the map one by one
            insideId != null -> "Not this home? Use ‹ ›."
            else -> "Not this house? Tap it on the map."
        }
    }

    /** Called on each GPS fix while knocking. Never moves anything; only offers a hint. */
    private fun gpsHint(acc: Float) {
        if (!knocking || tab != 0 || insideId != null || acc > 20f) return
        val la = lat ?: return; val lo = lon ?: return
        val l = walkStops(); val cur = l.firstOrNull { it.id == selectedId } ?: return
        val near = l.minByOrNull { metres(la, lo, it.first.lat, it.first.lon) } ?: return
        val dCur = metres(la, lo, cur.first.lat, cur.first.lon); val dNear = metres(la, lo, near.first.lat, near.first.lon)
        val newHint = if (near.id != cur.id && dCur > 35 && dNear < 15) near.id else null
        if (newHint != hintId) { hintId = newHint; if (flash.isEmpty()) updateStatus(cur) }
    }

    private fun endOfRow(): View {
        val box = vbox()
        val building = insideStop()
        if (building != null) {
            box.add(text(if (againMode) "No one left to try again here" else "Everyone in this flat is done", 22f, serif = true).apply { gravity = Gravity.CENTER })
            box.add(button("Back to the street", C.PRIMARY, C.ON_PRIMARY, height = 84) {
                val b = building.id; insideId = null; lastId = b; selectedId = advanceFrom(b)?.id; saveWalk(); renderOverlay()
            }.apply { textSize = 20f }, top = 16)
            return box
        }
        val nh = doors.count { it.street == curRow()?.street && it.isAgain }
        val next = nextRow()
        val areaName = curRow()?.let { r -> db.territories().firstOrNull { it.code == Next.area(r) }?.name }
        val areaDone = next == null && !againMode
        box.add(text(when {
            againMode -> "No more not-home homes here"
            areaDone -> "${areaName ?: "This neighbourhood"} is done"
            else -> "This row is done"
        }, 22f, serif = true).apply { gravity = Gravity.CENTER })
        if (areaDone) box.add(button("Choose where next", C.PRIMARY, C.ON_PRIMARY, height = 72) {
            // the neighbourhood is finished: picking a new area is a decision for the map, not a guess
            finishKnocking(); if (!areasOn) setAreasOn(true)
            hmap?.let { m -> val c = m.center(); m.moveTo(c.first, c.second, 13.5) }
        }.apply { textSize = 19f }, top = 12)
        if (next != null && !againMode) box.add(button(nextLabel(next.first), C.PRIMARY, C.ON_PRIMARY, height = 84) {
            enterRow(next.first, next.second); skipped.clear(); renderOverlay()
        }.apply { textSize = 20f; maxLines = 2 }, top = 12)
        if (nh > 0 && !againMode) box.add(button("Try the $nh not-home homes again", C.CARD, C.INK, 56) {
            beginAgain()
            // start at the not-home house nearest to you, not wherever the list happens to begin
            doors.filter { it.street == curRow()?.street && it.isAgain }.minByOrNull { it.dist }?.let { d -> stopOf(d)?.let { (r, s) -> enterRow(r, s) } }
            renderOverlay()
        }, top = 8)
        if (againMode) box.add(button("Back to new homes", C.CARD, C.INK, 56) { againMode = false; selectedId = null; saveWalk(); renderOverlay() }, top = 8)
        if (!areaDone) box.add(text("Or tap any house on the map.", 14f, C.MUTED).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        return box
    }

    private fun confirmFinish() {
        val open = db.openSession()
        val st = if (open != null) db.stats(open.first, onlyMe = true) else null
        val msg = if (st != null && st.doors > 0) "${st.doors} doors this time, ${st.presented} presented, ${st.saved} saved." else "Stop knocking?"
        AlertDialog.Builder(this).setTitle("Finish").setMessage(msg)
            .setPositiveButton("Finish") { _, _ -> finishKnocking() }
            .setNegativeButton("Keep knocking", null).show()
    }

    // ---------- recording ----------

    private fun record(door: Door, o: Outcome, v: View?, count: Int = 1, note: String = "", followUp: Pair<String, Long>? = null) {
        v?.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
        // going back to a home you already recorded and tapping again replaces that record
        val replacing = !pending(door) && door.outcome != null
        if (replacing) db.lastVisitId(door.id)?.let { db.void(it) }
        db.record(door, o, count, lat, lon, note)
        writeSeq++   // a reload that started before this tap must not overwrite it
        db.set("walkAt", "${System.currentTimeMillis()}")
        if (followUp != null) db.addFollowUp(door, followUp.first, note, followUp.second)
        val prevId = selectedId
        // only this house changes: update it in memory (no reload of the area)
        if (replacing) db.refreshDoor(door) else door.apply(o, System.currentTimeMillis(), db.user)
        if (!replacing) coverage[door.territory]?.let { (t, d) -> coverage = coverage + (door.territory to (t to minOf(t, d + 1))) }
        changed += door.id
        if (o != Outcome.DO_NOT_KNOCK && !replacing) {
            val p = seen[door.territory]
            val hit = o == Outcome.PRESENTED || o == Outcome.SAVED
            seen = seen + (door.territory to Observed((p?.doors ?: 0) + 1, (p?.presented ?: 0) + (if (hit) 1 else 0), (p?.saved ?: 0) + (if (o == Outcome.SAVED) count else 0)))
        }
        flash = "${door.num}: ${o.label}" + if (o == Outcome.SAVED && count > 1) " ($count)" else ""
        flashStop = prevId
        hintId = null; switchOffer = null
        // a correction of an earlier house leaves your position and direction as they were
        if (!replacing && insideId == null) { lastId = prevId; db.set("last", prevId ?: "") }
        selectedId = advanceFrom(prevId)?.id
        renderOverlay()
        scheduleSync()
    }

    /** A bottom sheet: big, thumb-reachable choices. */
    private fun sheet(build: (LinearLayout, () -> Unit) -> Unit) {
        val d = android.app.Dialog(this)
        // the same surface as the panels: full width from the bottom edge, rounded top, with a grab handle
        val box = vbox().apply { background = sheetSurface(C.PAPER); setPadding(dp(20), dp(10), dp(20), dp(24)) }
        val h = handle()
        box.add(h, w = 36, h = 4); (h.layoutParams as LinearLayout.LayoutParams).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(14) }
        build(box) { d.dismiss() }
        d.setContentView(box)
        d.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
            setGravity(Gravity.BOTTOM)
            setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    /** The view last tapped in a sheet: the outcome it records buzzes like the panel's buttons do. */
    private var sheetTap: View? = null
    /** The stop the flash line is about, so tapping it takes you back there to change it. */
    private var flashStop: String? = null
    private fun sheetButton(label: String, bg: Int = C.CARD, fg: Int = C.INK, onClick: () -> Unit) =
        button(label, bg, fg, 64) { v -> sheetTap = v; onClick() }.apply { textSize = 17f }

    private fun talkedSheet(door: Door) = sheet { box, close ->
        box.add(text("At ${door.num}", 20f, serif = true))
        val g1 = hbox(); val g2 = hbox()
        g1.add(sheetButton("Gospel presented") { close(); record(door, Outcome.PRESENTED, sheetTap) }, weight = 1f)
        g1.add(sheetButton("Saved", Outcome.SAVED.color, 0xFFFFFFFF.toInt()) { close(); savedSheet(door) }, weight = 1f, side = 4)
        g2.add(sheetButton("Come back later") { close(); laterSheet(door) }, weight = 1f)
        g2.add(sheetButton("Just talked") { close(); record(door, Outcome.TALKED, sheetTap) }, weight = 1f, side = 4)
        box.add(g1, top = 10); box.add(g2, top = 8)
    }

    private fun savedSheet(door: Door) = sheet { box, close ->
        box.add(text("How many were saved?", 20f, serif = true))
        val r = hbox()
        for (n in 1..5) r.add(sheetButton(if (n == 5) "5+" else "$n", Outcome.SAVED.color, 0xFFFFFFFF.toInt()) {
            close(); record(door, Outcome.SAVED, sheetTap, count = n)
        }, weight = 1f, side = 2)
        box.add(r, top = 12)
    }

    private fun laterSheet(door: Door) = sheet { box, close ->
        box.add(text("Come back to ${door.num}", 20f, serif = true))
        val name = input("Name, if they gave it")
        box.add(name, top = 10)
        val opts = listOf("Tomorrow" to 1, "In 3 days" to 3, "Next week" to 7, "In 2 weeks" to 14)
        for (pair in opts.chunked(2)) {
            val r = hbox()
            pair.forEachIndexed { i, (label, days) -> r.add(sheetButton(label) {
                close(); record(door, Outcome.RETURN, sheetTap, followUp = name.text.toString().trim() to System.currentTimeMillis() + days * 86_400_000L)
            }, weight = 1f, side = if (i == 1) 4 else 0) }
            box.add(r, top = 8)
        }
    }

    private fun moreSheet(cur: Stop?) = sheet { box, close ->
        if (cur != null && !cur.isBuilding) {
            val d = cur.first
            box.add(sheetButton("Skip ${d.num} for now") { close(); skip(cur) })
        }
        val first = box.childCount <= 1   // only the grab handle so far
        if (insideId != null) box.add(sheetButton("Back to the street") { close(); val b = insideId; insideId = null; selectedId = b; lastId = b; saveWalk(); renderOverlay() }, top = if (first) 0 else 8)
        else box.add(sheetButton("Walk the other way") { close(); asc = !asc; saveWalk(); renderOverlay() }, top = if (first) 0 else 8)
        // last, apart from the rest: it stays with the house in every later round
        if (cur != null && !cur.isBuilding) box.add(sheetButton("Don't knock at ${cur.first.num}") { close(); record(cur.first, Outcome.DO_NOT_KNOCK, sheetTap) }, top = 20)
    }

    // ================= THE MAP: one layer under everything =================
    // Vector map (MapLibre) with Harvest's layers. Homes: only the working set. Neighbourhoods: a toggle;
    // when on, only the ones in view are loaded, and switching it off releases them.

    private fun doorColor(d: Door): Int = C.dot(d.outcome, d.dnk) ?: C.NEW
    private var pickKey: String? = null           // planning: the row highlighted on the map
    private var rowOfDoor: Map<String, String> = emptyMap()
    private var doorById: Map<String, Door> = emptyMap()
    private var mapCard: LinearLayout? = null
    private var mapChip: android.widget.TextView? = null
    private var centerOnce: Triple<Double, Double, Double>? = null    // lat, lon, zoom: where the map should go next
    private var mapHost: FrameLayout? = null
    private var overlay: FrameLayout? = null

    // neighbourhood layer
    private var areasOn = false
    private var areaStats: Map<String, BuurtStat> = emptyMap()
    private var areaPick: String? = null
    private val checkedStatViews = HashSet<String>()
    private var areaGen = 0

    /** One line about loading: which neighbourhoods around you are being loaded. */
    private fun updateChip() {
        val chip = mapChip ?: return
        val loadingNames = if (importing.isEmpty()) emptyList() else db.territories().filter { it.code in importing }.map { it.name }
        chip.text = if (loadingNames.isNotEmpty()) "Loading ${loadingNames.take(2).joinToString(", ")}" + (if (loadingNames.size > 2) " and ${loadingNames.size - 2} more" else "") + "…" else ""
        chip.visibility = if (chip.text.isEmpty()) View.GONE else View.VISIBLE
        (chip.parent as? ViewGroup)?.let { box -> box.visibility = if (box.childCount == 1) chip.visibility else View.VISIBLE }
    }

    private fun indexRows() {
        rowOfDoor = rows.values.flatten().flatMap { r -> r.stops.flatMap { s -> s.doors.map { it.id to r.key } } }.toMap()
        doorById = doors.associateBy { it.id }
    }

    /** The row the map suggests before you tap anything. */
    private fun suggestedRow(): String? {
        val saved = curRow()
        if (saved != null && saved.stops.any { open(it) } && (lat == null || saved.stops.minOf { s -> s.doors.minOf { it.dist } } < 400)) return saved.key
        return bestOpen()?.let { rowOfDoor[it.id] }
    }

    /**
     * The best place to start: promise weighed against distance. One point of promise is worth about 25 m of walking,
     * so a promising social-rent flat 800 m away beats an unpromising house next door, but not one across town.
     */
    private fun bestOpen(): Door? {
        val ref = refPoint() ?: return nearestOpen()
        val taken = claimedByOthers().keys
        var best: Door? = null; var bestCost = Double.MAX_VALUE
        for (r in rows.values.flatten()) {
            if (r.street in taken) continue
            for (st in r.stops) {
                if (st.doors.none { it.isNew }) continue
                val d = st.first
                val cost = distance(ref.first, ref.second, d.lat, d.lon) + (100 - stopScore(st)) * 25.0
                if (cost < bestCost) { bestCost = cost; best = st.doors.firstOrNull { it.isNew } }
            }
        }
        return best ?: nearestOpen()
    }

    private var userPicked = false
    private fun setPick(k: String?) { pickKey = k; pickDoor = rowOf(k)?.stops?.first()?.id }

    /** A tap on a house. Planning: pick its row. Knocking: go to it in your row, or offer to switch rows. */
    internal fun pick(tapped: Door) {
        val d = doorById[tapped.id] ?: tapped   // always the live house, with its current state
        if (knocking) {
            val inWalk = walkStops().firstOrNull { s -> s.doors.any { it.id == d.id } }
            if (inWalk != null) { jumpTo(inWalk); switchOffer = null; flash = ""; hintId = null }
            else switchOffer = d
            renderOverlay(); return
        }
        pickKey = rowOfDoor[d.id]; pickDoor = d.id; userPicked = true; areaPick = null
        bringPickIntoView(); fillMapCard(); refreshMap()
    }

    private fun handleTap(x: Float, y: Float) {
        val m = hmap ?: return
        val id = m.featuresNear(x, y, dp(22).toFloat(), "h-homes", "h-flats").firstOrNull()
        val d = id?.let { doorById[it] }
        if (d != null) { pick(d); return }
        if (areasOn && !knocking) {
            areaPick = m.featuresNear(x, y, 1f, "h-areas-fill").firstOrNull()
            refreshAreas(); fillMapCard()
        }
    }

    private fun bringPickIntoView() {
        val r = rowOf(pickKey) ?: return
        val la = r.stops.map { it.first.lat }.average(); val lo = r.stops.map { it.first.lon }.average()
        if (hmap?.contains(la, lo) == false) hmap?.moveTo(la, lo)
    }

    private val changed = HashSet<String>()   // homes knocked since the base layer was last sent
    private var mapDirty = false

    /** All homes of the area: sent to the map engine only when the area's data is reloaded. */
    private fun refreshBase() {
        val m = hmap ?: return
        changed.clear()
        val homes = Geo()
        for (d in doors) if (d.building == null) homes.point(d.lat, d.lon, "id" to d.id, "color" to HMap.hex(doorColor(d)))
        m.setData("h-homes", homes.json())
        refreshMap()
    }

    private fun blend(c: Int, over: Int, a: Float): Int {
        fun ch(sh: Int) = (((c shr sh) and 255) * a + ((over shr sh) and 255) * (1 - a)).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /**
     * What a tap changes, and nothing more: the row in focus with its numbers and route, homes knocked since the last
     * reload, flats, the current house. A few dozen points instead of every home in the area.
     */
    private fun refreshMap() {
        val m = hmap ?: return
        if (tab != 0) { mapDirty = true; return }   // the map is covered: catch up when it's shown again
        mapDirty = false
        val focus = if (knocking) curRow() else rowOf(pickKey)
        val cur = if (knocking) currentStop() else null
        val dim = focus != null
        m.setBaseDim(dim)
        val hi = Geo()
        val inFocus = HashSet<String>()
        focus?.stops?.forEach { s -> s.doors.forEach { d -> if (d.building == null) { inFocus += d.id
            hi.point(d.lat, d.lon, "id" to d.id, "color" to HMap.hex(doorColor(d)), "stroke" to HMap.hex(C.PRIMARY), "focus" to true) } } }
        for (id in changed) {
            if (id in inFocus) continue
            val d = doorById[id] ?: continue
            // pre-blended with the background so it looks dimmed like its neighbours, yet fully covers the old dot
            val col = if (dim) blend(doorColor(d), C.PAPER, 0.45f) else doorColor(d)
            val st = if (dim) blend(C.FIELD, C.PAPER, 0.35f) else C.FIELD
            hi.point(d.lat, d.lon, "id" to d.id, "color" to HMap.hex(col), "stroke" to HMap.hex(st), "focus" to false)
        }
        m.setData("h-hi", hi.json())
        val flats = Geo()
        for (r in rows.values.flatten()) for (s in r.stops) if (s.isBuilding) {
            val f = s.first
            flats.point(f.lat, f.lon, "id" to f.id, "label" to (if (f.care) "care" else "${s.doors.size}"), "care" to f.care, "done" to s.doors.none { it.isNew })
        }
        m.setData("h-flats", flats.json())
        val route = Geo(); val nums = Geo()
        if (focus != null) {
            route.line(focus.stops.map { it.first.lat to it.first.lon }, "next" to false)
            for (s in focus.stops) nums.point(s.first.lat, s.first.lon, "num" to s.label, "cur" to (s.id == cur?.id))
        }
        if (knocking && cur == null && insideId == null) nextRow()?.let { (r, _) -> route.line(r.stops.map { it.first.lat to it.first.lon }, "next" to true) }
        m.setData("h-route", route.json()); m.setData("h-nums", nums.json())
        val c = Geo(); cur?.first?.let { c.point(it.lat, it.lon) }
        m.setData("h-cur", c.json())
    }

    private var meLat = Double.NaN; private var meLon = Double.NaN

    /** The blue dot. Each update redraws the map, so only when you've moved a few metres and the map is on screen. */
    private fun updateMe() {
        val la = lat ?: return; val lo = lon ?: return
        if (tab != 0 || hmap == null) return
        if (!meLat.isNaN() && distance(la, lo, meLat, meLon) < 2.5) return
        meLat = la; meLon = lo
        hmap?.setData("h-me", Geo().apply { point(la, lo) }.json())
    }

    // ---------- the neighbourhood layer ----------
    private fun setAreasOn(on: Boolean) {
        areasOn = on; db.set("areas", if (on) "1" else "")
        hmap?.setAreas(on)
        if (on) areasMoved()
        else { areaStats = emptyMap(); areaPick = null; checkedStatViews.clear(); areaGen++; lastAreaKey = ""; refreshAreas() }   // released
        if (!knocking) fillMapCard()
        renderOverlay()
    }

    /** Figures for the neighbourhoods in view: from the disk cache, fetched once per area when missing. */
    private fun areasMoved() {
        if (!areasOn) return
        val m = hmap ?: return
        if (m.zoom() < 11.0) { areaStats = emptyMap(); refreshAreas(); if (!knocking) fillMapCard(); return }
        val b = m.bounds(); val gen = areaGen
        val key = "${Math.round(b[0] * 20)}:${Math.round(b[1] * 14)}:${Math.round(b[2] * 20)}:${Math.round(b[3] * 14)}"
        // the camera settles after every tap while knocking: only look again when the view reaches another area
        if (key == lastAreaKey && areaStats.isNotEmpty()) return
        lastAreaKey = key
        val fetch = autoLoad && checkedStatViews.add(key)
        io.execute {
            if (fetch) try { db.saveStats(Pdok.stats(b[0], b[1], b[2], b[3])) } catch (e: Exception) {}
            val st = db.statsIn(b[0], b[1], b[2], b[3])
            main.post { if (!gone && gen == areaGen && areasOn) { areaStats = st; refreshAreas(); if (!knocking) fillMapCard() } }
        }
    }

    private var lastAreaKey = ""
    private var lastAreasJson = ""

    private fun areaScoreOf(code: String) = Receptivity.buurt(areaStats[code] ?: bstats[code], seen[code])

    private fun refreshAreas() {
        val m = hmap ?: return
        val polys = Geo(); val names = Geo()
        for (st in areaStats.values) {
            val score = areaScoreOf(st.code)
            val color = Receptivity.color(score)
            polys.polygons(st.rings, "id" to st.code, "color" to (if (color == 0) "rgba(0,0,0,0)" else HMap.hex(color)), "picked" to (st.code == areaPick))
            names.point(st.lat, st.lon, "name" to st.name, "score" to (score ?: 0))
        }
        val pj = polys.json()
        if (pj == lastAreasJson) return   // unchanged: don't make the map engine redo the outlines
        lastAreasJson = pj
        m.setData("h-areas", pj); m.setData("h-anames", names.json())
    }

    /** Rank: promise, lowered by how much of it you've already knocked this round. */
    private fun areaRank(code: String): Double {
        val s = areaScoreOf(code) ?: return -1.0
        val cov = coverage[code]?.let { if (it.first > 0) it.second.toDouble() / it.first else 0.0 } ?: 0.0
        return s * (1 - 0.8 * cov)
    }

    /** The map is made once and kept: switching between planning and knocking only swaps what lies on top. */
    private fun mapHostView(): FrameLayout {
        mapHost?.let { return it }
        val host = FrameLayout(this)
        val m = HMap(this, useMap, C.dark, null)
        m.onReady = { refreshBase(); meLat = Double.NaN; updateMe(); lastAreasJson = ""; refreshAreas() }
        m.onTap = { x, y, _, _ -> handleTap(x, y) }
        m.onIdle = { areasMoved() }
        if (rowOf(pickKey) == null) setPick(suggestedRow())
        val start = (if (knocking) currentStop()?.first?.let { it.lat to it.lon } else rowOf(pickKey)?.let { r ->
            r.stops.map { it.first.lat }.average() to r.stops.map { it.first.lon }.average() })
            ?: (lat?.let { la -> lon?.let { lo -> la to lo } }) ?: (doors.map { it.lat }.average() to doors.map { it.lon }.average())
        m.moveTo(start.first, start.second, if (knocking) 18.6 else 17.5, animate = false)
        areasOn = db.get("areas") == "1"
        m.setAreas(areasOn)
        host.addView(m.view)
        val layer = FrameLayout(this)
        host.addView(layer)
        hmap = m; mapHost = host; overlay = layer
        return host
    }

    /** Rebuild only what lies over the map. */
    private fun renderOverlay() {
        val layer = overlay ?: return
        layer.removeAllViews(); mapCard = null; mapChip = null; statusView = null; knockPanel = null
        centerOnce?.let { (la, lo, z) -> hmap?.moveTo(la, lo, z); centerOnce = null }
        if (knocking) buildKnockOverlay(layer) else buildPlanOverlay(layer)
        refreshMap()
        updateChip()
    }

    /** Top right: the neighbourhood layer on or off, and (when on, while planning) a search for another town. */
    /**
     * The top of the map: information on the left (what's loading, who else is here, today's numbers), the
     * neighbourhood layer on the right. One row, so the two never collide on a narrow screen.
     */
    private fun topBar(layer: FrameLayout, info: LinearLayout) {
        val bar = hbox().apply { gravity = Gravity.TOP; setPadding(dp(12), dp(12), dp(12), 0) }
        val left = vbox()
        val chip = text("", 14f, C.FIELD, bold = true)
        mapChip = chip
        val loading = pill("").apply { removeAllViews(); add(chip, w = -2) }
        left.add(loading, w = -2); (loading.layoutParams as LinearLayout.LayoutParams).bottomMargin = dp(8)   // hidden when nothing loads
        var first = true
        while (info.childCount > 0) { val v = info.getChildAt(0); info.removeViewAt(0); left.add(v, w = -2, top = if (first) 0 else 8); first = false }
        bar.add(left, weight = 1f)
        val right = vbox().apply { gravity = Gravity.END }
        // on: a square in the neighbourhood colour; off: an empty outline
        val sw = if (areasOn) square(Receptivity.color(60)) else square(0x00000000, C.MUTED)
        right.add(pill("Neighbourhoods", sw) { setAreasOn(!areasOn) }, w = -2)
        if (areasOn && !knocking) right.add(pill("Search a town") { searchSheet() }, w = -2, top = 8)
        bar.add(right, w = -2, side = 0)
        (right.layoutParams as LinearLayout.LayoutParams).leftMargin = dp(8)
        layer.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
    }

    private fun searchSheet() = sheet { box, close ->
        box.add(text("Go to a town or neighbourhood", 18f, serif = true))
        val q = input("e.g. Deventer, or Keizerslanden")
        box.add(q, top = 10)
        fun go() {
            val text = q.text.toString().trim(); if (text.isEmpty()) return
            close()
            bg.execute {
                val p = try { Pdok.place(text) } catch (e: Exception) { null }
                main.post { if (gone) return@post; if (p == null) toast("Nothing found for \"$text\"") else { areaPick = null; hmap?.moveTo(p.first, p.second, p.third - 0.5) } }
            }
        }
        q.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        q.setOnEditorActionListener { _, _, _ -> go(); true }
        box.add(sheetButton("Go", C.PRIMARY, C.ON_PRIMARY) { go() }, top = 10)
        q.requestFocus()
    }

    private fun buildPlanOverlay(layer: FrameLayout) {
        if (rowOf(pickKey) == null) setPick(suggestedRow())
        val t = db.stats(todayStart(), onlyMe = false)
        val info = vbox()
        info.add(pill(if (t.doors > 0) "Today: ${t.doors} doors, ${t.presented} presented, ${t.saved} saved" else "Tap a house to start there"), w = -2)
        val due = db.followUps().count { it.due < System.currentTimeMillis() + 86_400_000L }
        if (due > 0) info.add(pill("$due follow-up${if (due == 1) "" else "s"} due", square(Outcome.RETURN.color)) { show(2) }, w = -2, top = 8)
        topBar(layer, info)

        val bottom = vbox()
        val me = pill("My location") {
            val a = lat; val b = lon; if (a != null && b != null) hmap?.moveTo(a, b, maxOf(hmap?.zoom() ?: 17.0, 16.5))
        }
        bottom.add(me, w = -2)
        (me.layoutParams as LinearLayout.LayoutParams).apply { gravity = Gravity.END; rightMargin = dp(12); bottomMargin = dp(12) }
        val card = vbox().apply { background = sheetSurface(C.CARD); setPadding(dp(20), dp(20), dp(20), dp(18)); lift(8) }
        mapCard = card
        bottom.add(card)
        layer.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        fillMapCard()
    }

    private fun fillMapCard() {
        val card = mapCard ?: return
        card.removeAllViews()
        if (areasOn && (areaPick != null || (hmap?.zoom() ?: 17.0) < 14.5)) { fillAreaCard(card); return }
        val r = rowOf(pickKey)
        if (r == null) {
            card.add(text("Every home here is knocked", 22f, serif = true))
            card.add(text("Turn on Neighbourhoods to see where else is promising.", 15f, C.MUTED), top = 4)
            return
        }
        val homes = r.stops.flatMap { it.doors }
        val openN = homes.count { it.isNew }; val nh = homes.count { it.isAgain }
        val dist = homes.minOf { it.dist }
        card.add(text("${r.street} ${r.range}", 24f, serif = true))
        val sub = (if (openN > 0) "$openN of ${homes.size} not knocked" else "Every home here is knocked") +
            (if (nh > 0) ", $nh not home" else "") + (if (dist != Double.MAX_VALUE) ", ${fmtDist(dist)} away" else "")
        card.add(text(sub, 15f, C.MUTED), top = 2)
        val flat = r.stops.firstOrNull { it.isBuilding }
        if (flat != null) {
            val f = flat.first
            card.add(text(when {
                f.care -> "Care building: probably homes for the elderly"
                f.built > 0 -> "Flat, ${flat.doors.size} homes, built ${f.built}"
                else -> "Flat, ${flat.doors.size} homes"
            }, 14f, if (f.care) C.MUTED else C.INK), top = 6)
        }
        reasonLine(homes.first().territory)?.let { card.add(it, top = 2) }
        claimedByOthers()[r.street]?.let { card.add(text("$it is on this street", 15f, Outcome.NOT_INTERESTED.color, bold = true), top = 4) }
        when {
            openN > 0 -> card.add(button(tappedStart(r, false)?.let { "Start at ${it.label}" } ?: "Start knocking", C.PRIMARY, C.ON_PRIMARY, height = 64) { knockRow(r, again = false) }, top = 14)
            nh > 0 -> card.add(button("Try the $nh not-home homes again", C.PRIMARY, C.ON_PRIMARY, height = 64) { knockRow(r, again = true) }, top = 14)
        }
    }

    /** "Very promising: 62% social rent, 68% flats", plus how far this round is and your own results there. */
    private fun reasonLine(code: String): View? {
        val st = areaStats[code] ?: bstats[code]; val o = seen[code]
        val score = areaScoreOf(code)
        val parts = ArrayList<String>()
        st?.let { parts += it.reasons().take(3) }
        coverage[code]?.let { (total, done) -> if (total > 0 && done > 0) parts += "${done * 100 / total}% done this round" }
        if (o != null && o.doors >= 10) parts += "you: ${o.presented} presented, ${o.saved} saved"
        if (parts.isEmpty() && score == null) return null
        val box = hbox()
        box.add(View(this).apply { background = rounded(Receptivity.color(score).let { if (it == 0) C.LINE else it }, dp(5).toFloat()) }, w = 10, h = 10)
        box.add(text(Receptivity.label(score) + (if (parts.isNotEmpty()) ": " + parts.joinToString(", ") else ""), 14f, C.INK), weight = 1f, side = 8)
        return box
    }

    /** The neighbourhood you tapped, or the most promising ones in view. "Knock here" makes it your destination. */
    private fun fillAreaCard(card: LinearLayout) {
        val tapped = areaPick?.let { areaStats[it] }
        if (tapped != null) {
            card.add(text(tapped.name, 24f, serif = true))
            card.add(text("${tapped.gemeente}, ${tapped.households} households", 15f, C.MUTED), top = 2)
            reasonLine(tapped.code)?.let { card.add(it, top = 6) }
            val row = hbox()
            row.add(button("Knock here", C.PRIMARY, C.ON_PRIMARY, height = 56) { chooseTarget(tapped) }, weight = 1f)
            row.add(button("Close", C.CARD, C.INK, 56) { areaPick = null; refreshAreas(); fillMapCard() }, w = -2, side = 6)
            card.add(row, top = 12)
            return
        }
        val b = hmap?.bounds()
        val inView = areaStats.values.filter { b == null || (it.lat in b[0]..b[2] && it.lon in b[1]..b[3]) }
            .filter { areaScoreOf(it.code) != null }.sortedByDescending { areaRank(it.code) }
        if (inView.isEmpty()) {
            card.add(text("Where to knock", 22f, serif = true))
            card.add(text(if ((hmap?.zoom() ?: 17.0) < 11.0) "Zoom in on a town, or search for one." else "Loading neighbourhood figures…", 15f, C.MUTED), top = 4)
            return
        }
        card.add(text("Most promising here", 20f, serif = true))
        for (st in inView.take(3)) {
            val row = hbox().apply { setPadding(0, dp(10), 0, dp(4)) }
            val l = vbox()
            l.add(text(st.name, 17f, bold = true))
            val cov = coverage[st.code]?.let { (t, d) -> if (t > 0 && d > 0) ", ${d * 100 / t}% done" else "" } ?: ""
            l.add(text(st.reasons().take(2).joinToString(", ") + cov, 13f, C.MUTED))
            row.add(View(this).apply { background = rounded(Receptivity.color(areaScoreOf(st.code)), dp(6).toFloat()) }, w = 12, h = 12)
            row.add(l, weight = 1f, side = 10)
            row.setOnClickListener { areaPick = st.code; refreshAreas(); fillMapCard() }
            row.add(button("Knock here", C.PRIMARY, C.ON_PRIMARY, height = 40) { chooseTarget(st) }.apply { textSize = 14f }, w = -2)
            card.add(row)
        }
        card.add(text("Tap a neighbourhood for its figures.", 13f, C.MUTED), top = 8)
    }

    /** Start (or switch to) a row: at the house you tapped on the map, else at the open home nearest to you. */
    private fun knockRow(r: Row, again: Boolean) {
        val pool = r.stops.flatMap { it.doors }.filter { if (again) it.isAgain else it.isNew }
        val d = tappedStart(r, again)?.first ?: pool.minByOrNull { it.dist } ?: return
        if (again) beginAgain() else againMode = false
        stopOf(d)?.let { (row, s) -> enterRow(row, s) }
        startKnocking(null)
    }

    /** The stop you tapped while planning, if it's in this row and still has someone to knock. */
    private fun tappedStart(r: Row, again: Boolean): Stop? {
        if (!userPicked) return null
        val d = pickDoor?.let { doorById[it] } ?: return null
        val s = r.stops.firstOrNull { st -> st.doors.any { it.id == d.id } } ?: return null
        return s.takeIf { st -> st.doors.any { if (again) it.isAgain else it.isNew } }
    }

    private fun emptyHome(): View {
        val page = vbox(16)
        page.add(text("Harvest", 30f, serif = true))
        page.add(text(if (importing.isNotEmpty()) "Loading the homes around you…" else "The homes around you load as soon as your location is known.", 16f, C.MUTED), top = 10)
        return page
    }

    // for the screen tests
    internal fun testCity(la: Double, lo: Double, z: Double) { if (!areasOn) setAreasOn(true); hmap?.moveTo(la, lo, z, animate = false); areasMoved(); fillMapCard() }
    internal fun testTapArea(code: String) { areaPick = code; refreshAreas(); fillMapCard() }
    internal fun testAreasOff() = setAreasOn(false)
    internal fun testAreasHeld() = areaStats.size
    internal fun testWorkSize() = doors.size
    internal fun testCurrent() = currentStop()?.label
    internal fun testSnapshot(): Snapshot = readSnapshot(work.toList(), reloadGen, writeSeq)
    internal fun testDeliver(s: Snapshot) = deliver(s)
    internal fun testDoor(id: String) = doors.firstOrNull { it.id == id }
    internal fun testPending(id: String) = doors.firstOrNull { it.id == id }?.let { pending(it) } ?: false
    internal fun testKnocking() = knocking
    internal fun testMapLateCalls() = hmap?.lateCalls ?: 0
    internal fun testSyncNow() = sync(quiet = true)
    internal fun testShow(i: Int) = show(i)
    internal fun testPickKey() = pickKey
    internal fun testRow() = curRow()

    // ================= FOLLOW-UPS =================

    private fun followUpsScreen(): View {
        val list = vbox(12)
        list.add(text("Follow-ups", 26f, serif = true))
        val items = db.followUps()
        if (items.isEmpty()) list.add(text("Nothing to follow up. Return visits and new converts show up here.", 15f, C.MUTED), top = 8)
        val day = 86_400_000L
        for (f in items) {
            val card = vbox(14).apply { background = rounded(C.CARD, dp(14).toFloat(), dp(1), C.LINE) }
            card.add(text(f.label, 19f, serif = true))
            if (f.name.isNotEmpty()) card.add(text(f.name, 16f, bold = true), top = 4)
            if (f.note.isNotEmpty()) card.add(text(f.note, 15f), top = 2)
            val days = Math.floorDiv(f.due - System.currentTimeMillis(), day)
            val dueText = when { days < 0 -> "Overdue by ${-days} days"; days == 0L -> "Due today"; days == 1L -> "Due tomorrow"; else -> "Due in $days days" }
            card.add(text("$dueText. Added by ${f.user}.", 14f, if (days < 0) Outcome.NOT_INTERESTED.color else C.MUTED), top = 6)
            val row = hbox()
            val d = doors.firstOrNull { it.id == f.addressId }
            if (d != null) {
                row.add(button("Directions", C.CARD, C.INK, 42) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${d.lat},${d.lon}(${Uri.encode(d.label)})")))
                }, weight = 1f)
                row.add(button("Map", C.CARD, C.INK, 42) { pickKey = rowOfDoor[d.id]; pickDoor = d.id; userPicked = true; show(0) }, weight = 1f, side = 6)
            }
            row.add(button("Done", C.FIELD, height = 42) { db.doneFollowUp(f.id); scheduleSync(); show(2) }, weight = 1f)
            card.add(row, top = 10)
            list.add(card, top = 10)
        }
        return ScrollView(this).apply { addView(list) }
    }

    // ================= STATS =================

    private var statsMe = true

    private fun statsScreen(): View {
        val page = vbox(12)
        val head = hbox()
        head.add(text("Stats", 26f, serif = true), weight = 1f)
        head.add(button("Me", if (statsMe) C.FIELD else C.CARD, if (statsMe) C.ON_INK else C.INK, 38) { statsMe = true; show(3) }, w = -2)
        head.add(button("Team", if (!statsMe) C.FIELD else C.CARD, if (!statsMe) C.ON_INK else C.INK, 38) { statsMe = false; show(3) }, w = -2, side = 4)
        page.add(head)
        val wk = vbox(16).apply { background = rounded(C.CARD, dp(14).toFloat(), dp(1), C.LINE) }
        wk.add(text("Where to knock", 20f, serif = true))
        wk.add(text("Neighbourhoods coloured by how promising they are: social rent, flats, home values, and your own results.", 14f, C.MUTED), top = 2)
        wk.add(button("Show on the map", C.PRIMARY, C.ON_PRIMARY, height = 52) {
            val c = (lat?.let { la -> lon?.let { lo -> la to lo } }) ?: hmap?.center()
            if (c != null) centerOnce = Triple(c.first, c.second, 12.8)
            if (!areasOn) { areasOn = true; db.set("areas", "1"); hmap?.setAreas(true) }
            show(0)
        }, top = 10)
        page.add(wk, top = 12)
        page.add(text("Team, neighbourhoods and your name are in Setup.", 13f, C.FIELD).apply {
            setPadding(0, dp(6), 0, dp(6)); setOnClickListener { show(4) }
        })

        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        val today = cal.timeInMillis
        cal.firstDayOfWeek = java.util.Calendar.MONDAY
        cal.set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
        val week = minOf(cal.timeInMillis, today)
        cal.timeInMillis = today; cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val month = cal.timeInMillis

        // Today, large
        val t = db.stats(today, statsMe)
        val card = vbox(16).apply { background = rounded(C.CARD, dp(14).toFloat(), dp(1), C.LINE) }
        val top = hbox()
        top.add(text("Today", 17f, bold = true), weight = 1f)
        if (t.minutes > 0) top.add(text(fmtDuration(t.minutes), 14f, C.MUTED), w = -2)
        card.add(top)
        val nums = hbox()
        fun num(v: Int, l: String, color: Int = C.INK) {
            val b = vbox(); b.add(text("$v", 30f, color, serif = true)); b.add(text(l, 13f, C.MUTED)); nums.add(b, weight = 1f)
        }
        num(t.doors, "doors"); num(t.answered, "answered"); num(t.presented, "presented"); num(t.saved, "saved", Outcome.SAVED.color)
        card.add(nums, top = 8)
        page.add(card, top = 12)

        // Longer periods, one compact table
        val table = vbox(14).apply { background = rounded(C.CARD, dp(14).toFloat(), dp(1), C.LINE) }
        val hdr = hbox()
        hdr.add(text("", 13f), weight = 1.6f)
        for (h in listOf("doors", "presented", "saved")) hdr.add(text(h, 13f, C.MUTED).apply { gravity = Gravity.END }, weight = 1f)
        table.add(hdr)
        for ((label, from) in listOf("This week" to week, "This month" to month, "All time" to 0L)) {
            val st = db.stats(from, statsMe)
            val r = hbox()
            r.add(text(label, 16f), weight = 1.6f)
            for ((v, c) in listOf(st.doors to C.INK, st.presented to C.INK, st.saved to Outcome.SAVED.color))
                r.add(text("$v", 18f, c, serif = true).apply { gravity = Gravity.END }, weight = 1f)
            table.add(r, top = 10)
        }
        page.add(table, top = 10)

        // every outing, so nothing has to be remembered or written down
        val outs = db.outings()
        if (outs.isNotEmpty()) {
            page.add(text("Outings", 19f, serif = true), top = 18)
            val fmt = java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault())
            for (o in outs) {
                val card = vbox(12).apply { background = rounded(C.CARD, dp(12).toFloat(), dp(1), C.LINE) }
                val top = hbox()
                top.add(text(fmt.format(java.util.Date(o.start)) + (if (o.area.isNotEmpty()) ", ${o.area}" else ""), 16f, bold = true), weight = 1f)
                top.add(text(fmtDuration((o.last - o.start) / 60000 + 5), 14f, C.MUTED), w = -2)
                card.add(top)
                card.add(text("${o.doors} doors, ${o.presented} presented, ${o.saved} saved" + (if (!statsMe) ". ${o.user}" else ""), 14f, C.MUTED), top = 2)
                page.add(card, top = 8)
            }
        }

        // neighbourhoods you've actually worked, with how far along the round is and what came of it
        val worked = db.territories().filter { (seen[it.code]?.doors ?: 0) > 0 }
        if (worked.isNotEmpty()) page.add(text("Neighbourhoods", 19f, serif = true), top = 18)
        for (t in worked) {
            val ds = doors.filter { it.territory == t.code }
            if (ds.isEmpty()) continue
            val knocked = ds.count { it.outcome != null || it.dnk }
            val nh = ds.count { it.isAgain }
            val o = seen[t.code]
            page.add(text(t.name, 16f, bold = true), top = 10)
            page.add(bar(knocked.toFloat() / ds.size), h = 10, top = 4)
            page.add(text("$knocked of ${ds.size} homes this round, $nh not home." +
                (if (o != null) " ${o.presented} presented, ${o.saved} saved." else ""), 13f, C.MUTED), top = 2)
        }

        val hours = db.byHour()
        val useful = (0..23).filter { hours[it][0] >= 15 }
        if (useful.isNotEmpty()) {
            page.add(text("When doors open", 19f, serif = true), top = 18)
            page.add(text("Share of doors answered by hour, whole team.", 13f, C.MUTED), top = 2)
            for (h in useful) {
                val r = hbox()
                r.add(text(String.format("%02d:00", h), 13f, C.MUTED), w = 52)
                val frac = hours[h][1].toFloat() / hours[h][0]
                r.add(bar(frac), weight = 1f, h = 10)
                r.add(text("${(frac * 100).toInt()}%", 13f), w = 44, side = 6)
                page.add(r, top = 6)
            }
        }
        return ScrollView(this).apply { addView(page) }
    }

    private fun bar(frac: Float): View {
        val outer = LinearLayout(this).apply { background = rounded(C.LINE, dp(5).toFloat()); weightSum = 1f }
        outer.addView(View(this).apply { background = rounded(C.FIELD, dp(5).toFloat()) },
            LinearLayout.LayoutParams(0, -1, frac.coerceIn(0.001f, 1f)))
        return outer
    }

    // ================= SETUP =================

    private fun setupScreen(): View {
        val page = vbox(12)
        page.add(text("Setup", 26f, serif = true))

        page.add(text("Your name", 14f, C.MUTED), top = 14)
        val name = input("Name", db.user)
        name.setOnFocusChangeListener { _, f -> if (!f && name.text.isNotBlank()) db.set("user", name.text.toString().trim()) }
        page.add(name, top = 4)
        fun saveName() { if (name.text.isNotBlank()) db.set("user", name.text.toString().trim()) }
        /** Your name is who you are to the team: claims and "my" stats key on it. Two phones both called "Me" merge. */
        fun nameOk(): Boolean {
            val n = name.text.toString().trim()
            if (n.isEmpty() || n.equals("Me", ignoreCase = true)) { toast("Enter your own name first, so the team can tell your knocks apart."); name.requestFocus(); return false }
            return true
        }

        page.add(text("Team", 19f, serif = true), top = 20)
        val team = db.get("team")
        if (team.isEmpty()) {
            page.add(text("Paste the invite a teammate shared with you.", 14f, C.MUTED), top = 4)
            val inv = input("Invite")
            page.add(inv, top = 6)
            page.add(button("Join team", C.FIELD) {
                if (!nameOk()) return@button
                saveName()
                val raw = inv.text.toString().trim().substringAfter("harvest:").trim()
                val i = raw.lastIndexOf('#')
                if (i <= 0 || !raw.startsWith("https://")) { toast("That invite isn't complete. It looks like harvest:https://…#code"); return@button }
                db.setTeam(raw.substring(0, i), raw.substring(i + 1))
                sync(quiet = false); show(4)
            }, top = 6)
            page.add(text("Or start a new team on your own server.", 14f, C.MUTED), top = 16)
            val server = input("https://harvest.yourname.workers.dev")
            page.add(server, top = 6)
            page.add(button("Create team", C.CARD, C.INK) {
                if (!nameOk()) return@button
                saveName()
                val url = server.text.toString().trim().trimEnd('/')
                if (!url.startsWith("https://")) { toast("Enter your server address, starting with https://"); return@button }
                val abc = "abcdefghjkmnpqrstuvwxyz23456789"; val rnd = SecureRandom()
                db.setTeam(url, (1..24).map { abc[rnd.nextInt(abc.length)] }.joinToString(""))
                sync(quiet = false); show(4)
            }, top = 6)
        } else {
            val invite = "harvest:${db.get("server")}#$team"
            val last = db.get("lastSync", "0").toLong()
            page.add(text(if (syncState.isNotEmpty()) syncState else if (last > 0) "Synced ${fmtAgo(last)}." else "Not synced yet.", 14f, C.MUTED), top = 4)
            val row = hbox()
            row.add(button("Invite teammate", C.FIELD) {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, "Join our soulwinning team in Harvest. Open Setup and paste this invite:\n\n$invite")
                }, "Invite teammate"))
            }, weight = 1f)
            row.add(button("Sync now", C.CARD, C.INK) { saveName(); sync(quiet = false) }, weight = 1f, side = 6)
            page.add(row, top = 8)
            page.add(button("Leave team", C.PAPER, Outcome.NOT_INTERESTED.color, 42) {
                AlertDialog.Builder(this).setMessage("Leave this team? Your knocks stay on this phone, but you stop seeing the team's.")
                    .setPositiveButton("Leave") { _, _ -> db.setTeam(null, ""); show(4) }
                    .setNegativeButton("Stay", null).show()
            }, top = 6)
        }

        page.add(text("Neighbourhoods", 19f, serif = true), top = 20)
        page.add(text("Starting a new round makes every home in it new again, for the whole team.", 14f, C.MUTED), top = 4)
        for (t in db.territories().filter { it.code in work || (seen[it.code]?.doors ?: 0) > 0 }) {
            val ds = doors.filter { it.territory == t.code }
            val card = vbox(12).apply { background = rounded(C.CARD, dp(12).toFloat(), dp(1), C.LINE) }
            card.add(text(t.name, 17f, bold = true))
            val status = when {
                t.code in importing -> "Loading addresses…"
                t.code !in work -> "${t.gemeente}. Loads again when you're there."
                !t.imported -> "Waiting to load addresses"
                else -> "${t.gemeente}. ${ds.size} doors, ${ds.count { it.isNew }} still new." +
                    (if (t.roundStart > 0) " Round started ${fmtAgo(t.roundStart)}." else "")
            }
            card.add(text(status, 14f, C.MUTED), top = 2)
            val row = hbox()
            row.add(button("New round", C.CARD, C.INK, 40) {
                AlertDialog.Builder(this).setMessage("Start a new round in ${t.name} for the whole team? Every door becomes new again, except don't-knock doors. History stays in the stats.")
                    .setPositiveButton("New round") { _, _ -> db.newRound(t.code); reloadAsync(); scheduleSync(); show(4) }
                    .setNegativeButton("Cancel", null).show()
            }, w = -2)
            card.add(row, top = 8)
            page.add(card, top = 8)
        }

        page.add(text("Only the neighbourhoods around you are loaded while you knock. To choose somewhere else, use Stats, Where to knock.", 14f, C.MUTED), top = 10)
        // a copy of everything, for a new install or another phone, without going online
        page.add(text("Your data", 19f, serif = true), top = 20)
        page.add(text("Save everything to one file, or merge a file into this phone. Nothing is overwritten: for each knock the newest change wins.", 14f, C.MUTED), top = 4)
        val io2 = hbox()
        io2.add(button("Export data", C.CARD, C.INK) { exportData() }, weight = 1f)
        io2.add(button("Import data", C.CARD, C.INK) { importData() }, weight = 1f, side = 6)
        page.add(io2, top = 8)

        // test knocks shouldn't follow you into real use
        val n = db.knockCount()
        if (n > 0) page.add(button("Erase recorded knocks ($n)", C.PAPER, Outcome.NOT_INTERESTED.color, 44) {
            AlertDialog.Builder(this).setMessage("Erase all $n recorded knocks? Every home becomes new again and today's stats reset. Use this to clear test knocks before you go out for real.")
                .setPositiveButton("Erase") { _, _ -> db.eraseKnocks(); reloadAsync(); scheduleSync(); show(4) }
                .setNegativeButton("Keep them", null).show()
        }, top = 24)
        page.add(text("Addresses come from the Dutch address register (BAG) via PDOK. Map © OpenStreetMap contributors.", 12f, C.MUTED), top = 24)
        return ScrollView(this).apply { addView(page) }
    }

    private fun addBuurt(b: Pdok.Buurt) {
        if (db.territories().any { it.code == b.code }) { toast("${b.name} is already added."); return }
        db.putTerritory(b.code, b.name, b.gemeente)
        scheduleSync()
        importMissing()
        show(tab)
    }

    /** Loads addresses for every neighbourhood that doesn't have them yet, including ones a teammate added. */
    private val failedOnce = HashSet<String>()

    /**
     * After a failed import, try again by itself: 20 s, then doubling up to 5 minutes. Before, nothing retried it while
     * you stayed in the same area (the working set doesn't change), so that neighbourhood stayed empty until a restart.
     */
    private var importRetryMs = 20_000L
    private val importRetry = Runnable { importMissing() }

    private fun importMissing() {
        if (gone) return
        main.post { if (!gone) updateChip() }
        // only the working set: neighbourhoods elsewhere load when you're there
        for (t in db.territories().filter { it.code in work && !it.imported && it.code !in importing }) {
            importing += t.code
            bg.execute {
                val err = try { db.saveAddresses(t.code, addressSource(t.code)); null } catch (e: Exception) { e.message ?: "error" }
                main.post {
                    if (gone) return@post
                    importing -= t.code
                    if (err != null) {
                        // no connection: say so once, not on every attempt, and try again in a while
                        if (failedOnce.add(t.code)) toast("Couldn't load ${t.name} yet. It will try again by itself.")
                        main.removeCallbacks(importRetry); main.postDelayed(importRetry, importRetryMs)
                        importRetryMs = minOf(importRetryMs * 2, 300_000L)
                    } else {
                        failedOnce -= t.code; importRetryMs = 20_000L
                        if (t.code in work) reloadAsync()
                    }
                    updateChip()
                }
            }
        }
    }

    // ================= sync =================

    private val syncRunnable = Runnable { sync(quiet = true) }
    private fun scheduleSync() { main.removeCallbacks(syncRunnable); main.postDelayed(syncRunnable, 5000) }

    private var syncing = false
    private fun sync(quiet: Boolean) {
        if (gone || db.get("team").isEmpty() || syncing) return
        syncing = true
        if (!quiet) { syncState = "Syncing…"; if (tab == 4) show(4) }
        syncEx.execute {
            val res: Any = try { syncRunner(db) } catch (e: Exception) { e }
            main.post {
                if (gone) return@post
                syncing = false
                if (res is Exception) {
                    syncState = "Sync failed: ${res.message}. Your knocks are safe on this phone and sync later."
                    if (!quiet) { toast("Sync failed"); if (tab == 4) show(4) }
                } else {
                    syncState = ""
                    val r = res as Sync.Result
                    if (r.received > 0) { importMissing(); reloadAsync() }
                    if (!quiet && tab == 4) show(4)
                }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ================= export / import =================
    // Android's own file picker: no storage permission, and you choose where the file goes (Downloads, Drive, …)

    private val EXPORT = 41; private val IMPORT = 42

    private fun exportData() {
        val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.ROOT).format(java.util.Date())
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("application/json").putExtra(Intent.EXTRA_TITLE, "harvest-$day.json"), EXPORT)
    }

    private fun importData() {
        // any type: file managers don't always call a .json file JSON
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), IMPORT)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            EXPORT -> runFile(uri, "Exporting…") {
                contentResolver.openOutputStream(uri, "wt")!!.use { db.exportTo(it) }
                "Exported ${db.knockCount()} knocks and ${db.territories().size} neighbourhoods."
            }
            IMPORT -> runFile(uri, "Importing…") {
                val r = contentResolver.openInputStream(uri)!!.use { db.importFrom(it) }
                main.post {
                    if (gone) return@post
                    // offline there's no lookup of the neighbourhoods around you: show the file's ones straight away
                    work = work + r.areaCodes; db.set("work", work.joinToString(","))
                    importMissing(); reloadAsync(); scheduleSync()
                }
                if (r.changed == 0 && r.homes == 0) "Nothing new in that file: this phone already has all of it."
                else "Imported ${r.changed} new or newer records" + (if (r.areas > 0) ", and the homes of ${r.areas} neighbourhoods" else "") + "."
            }
        }
    }

    /** File work off the main thread; the result (or what went wrong) as a toast. */
    private fun runFile(uri: Uri, busy: String, work: () -> String) {
        toast(busy)
        // the sync thread: quick, never stuck behind a neighbourhood import, and never at the same time as a sync
        syncEx.execute {
            val msg = try { work() } catch (e: Exception) { e.message ?: "That didn't work." }
            main.post { if (!gone) { toast(msg); if (tab == 4) show(4) } }
        }
    }
}
