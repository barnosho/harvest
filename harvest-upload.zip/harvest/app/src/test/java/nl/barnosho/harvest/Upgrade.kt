package nl.barnosho.harvest

import android.app.Application
import android.database.sqlite.SQLiteDatabase
import androidx.test.core.app.ApplicationProvider
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** The phone has a 1.6 database (version 2). Opening it with 1.7 must keep every knock and not crash. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class Upgrade {
    @Test fun fromVersion2() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val f = app.getDatabasePath("harvest.db"); f.parentFile?.mkdirs(); f.delete()
        SQLiteDatabase.openOrCreateDatabase(f, null).use { db ->
            db.execSQL("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
            db.execSQL("CREATE TABLE territory(code TEXT PRIMARY KEY, name TEXT, gemeente TEXT, round_start INTEGER, deleted INTEGER, imported INTEGER, updated INTEGER, dirty INTEGER)")
            db.execSQL("CREATE TABLE address(id TEXT PRIMARY KEY, territory TEXT, street TEXT, num TEXT, postcode TEXT, lat REAL, lon REAL, building TEXT, sect TEXT, pos REAL, sgn INTEGER)")
            db.execSQL("CREATE TABLE visit(id TEXT PRIMARY KEY, address_id TEXT, outcome TEXT, count INTEGER, ts INTEGER, lat REAL, lon REAL, user TEXT, session_id TEXT, note TEXT, voided INTEGER, updated INTEGER, dirty INTEGER)")
            db.execSQL("CREATE TABLE session(id TEXT PRIMARY KEY, user TEXT, start INTEGER, last INTEGER, ended INTEGER, updated INTEGER, dirty INTEGER)")
            db.execSQL("CREATE TABLE followup(id TEXT PRIMARY KEY, address_id TEXT, label TEXT, name TEXT, note TEXT, due INTEGER, done INTEGER, user TEXT, updated INTEGER, dirty INTEGER)")
            db.execSQL("CREATE TABLE claim(id TEXT PRIMARY KEY, user TEXT, street TEXT, row TEXT, ts INTEGER, updated INTEGER, dirty INTEGER)")
            db.execSQL("INSERT INTO territory VALUES('WORKED','Eekmaat West','Enschede',0,0,1,1,0)")
            db.execSQL("INSERT INTO territory VALUES('LOOKED','Glanerveld','Enschede',0,0,1,1,0)")
            db.execSQL("INSERT INTO address VALUES('a1','WORKED','Hoornbladlaan','10','7534KP',52.2,6.9,NULL,'s',1.0,1)")
            db.execSQL("INSERT INTO address VALUES('a2','LOOKED','Elsweg','1','7534AA',52.2,6.9,NULL,'s',1.0,1)")
            db.execSQL("INSERT INTO visit VALUES('v1','a1','SAVED',2,1000,52.2,6.9,'Aryo','s1','',0,1000,0)")
            db.execSQL("INSERT INTO session VALUES('s1','Aryo',900,1000,1,1000,0)")
            db.version = 2
        }
        val db = Db(app)
        val terr = db.territories().map { it.code }
        check(terr == listOf("WORKED")) { "expected only the worked neighbourhood to stay, got $terr" }
        check(db.territories().none { it.imported }) { "worked neighbourhood should reload" }
        check(db.knockCount() == 1) { "the knock must survive" }
        check(db.outings().single().saved == 2)
        db.saveStats(emptyList()); check(db.allStats().isEmpty())
        check(db.observed()["WORKED"]?.saved == 2)
        // v4: figures searchable by area, homes loaded per working set
        db.saveStats(listOf(BuurtStat("X", "Test", "Town", 60, 70, 200, 10, 5.0, 100, 52.2, 6.9, listOf(doubleArrayOf(6.89, 52.19, 6.91, 52.19, 6.91, 52.21)))))
        check(db.statsIn(52.19, 6.88, 52.21, 6.92).keys == setOf("X"))
        check(db.statsFor(listOf("X")).size == 1)
        check(db.doors(listOf("WORKED")).size == 1 && db.doors(emptyList()).isEmpty())
    }
}
