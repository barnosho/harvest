package nl.barnosho.harvest

import android.Manifest
import android.app.Application
import android.location.Location
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowLooper

/** The walk follows the direction you go, from the house you start at, and Finish never hides the app. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w411dp-h891dp-xxhdpi")
class WalkDirection {
    private fun json(name: String) = JSONArray(javaClass.classLoader!!.getResource(name).readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }

    private fun seed(): List<Door> {
        val app = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
        val db = Db(app)
        db.set("user", "Aryo"); db.putTerritory("BU01530808", "Eekmaat West", "Enschede")
        val doors = Pdok.buildDoors("BU01530808", json("addr.json"), json("vbo.json"), json("nwb.json"))
        db.saveAddresses("BU01530808", doors); db.set("work", "BU01530808"); db.close()
        return doors
    }

    private fun find(v: View, label: String): View? {
        if (v is TextView && v.text.toString().startsWith(label) && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) find(v.getChildAt(i), label)?.let { return it }
        return null
    }

    /** The dialog's own Finish button (its title says "Finish" too). */
    private fun confirm() {
        (ShadowDialog.getLatestDialog() as android.app.AlertDialog).getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick()
        ShadowLooper.idleMainLooper()
    }

    private fun tap(a: android.app.Activity, label: String) {
        val dlg = ShadowDialog.getLatestDialog()
        val v = (if (dlg != null && dlg.isShowing) find(dlg.window!!.decorView, label) else null) ?: find(a.window.decorView, label)
            ?: error("No button '$label'")
        var t: View = v
        while (!t.isClickable && t.parent is View) t = t.parent as View
        t.performClick(); ShadowLooper.idleMainLooper()
    }

    private fun at(a: MainActivity, d: Door) {
        a.onLocationChanged(Location("gps").apply { latitude = d.lat; longitude = d.lon; accuracy = 6f }); ShadowLooper.idleMainLooper()
    }

    /** Rows of single houses, at least n long, one per street. */
    private fun plainRows(doors: List<Door>, n: Int) = Walks.rows(doors).values.flatten()
        .filter { r -> r.stops.size >= n && r.stops.none { it.isBuilding } }.distinctBy { it.street }

    private fun start(): Pair<MainActivity, List<Door>> {
        MainActivity.autoLoad = false; MainActivity.useMap = false
        val doors = seed()
        val a = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        return a to doors
    }

    @Test fun tappingTheFarEndWalksBack() {
        val (a, doors) = start()
        val r = plainRows(doors, 5).first()
        val lo = r.stops.first(); val hi = r.stops.last()
        at(a, lo.first)
        a.pick(lo.first); tap(a, "Start at"); assertEquals(lo.label, a.testCurrent())
        // you walk to the other end and start there: the walk turns round with you
        a.pick(hi.first); assertEquals(hi.label, a.testCurrent())
        tap(a, "Not home"); assertEquals(r.stops[r.stops.size - 2].label, a.testCurrent())
        tap(a, "Not interested"); assertEquals(r.stops[r.stops.size - 3].label, a.testCurrent())
        println("row ${r.street} ${r.range}: started ${lo.label}, tapped ${hi.label}, then ${r.stops[r.stops.size - 2].label}, ${r.stops[r.stops.size - 3].label}")
    }

    @Test fun theHouseTappedWhilePlanningIsWhereYouStart() {
        val (a, doors) = start()
        val r = plainRows(doors, 5)[1]
        val hi = r.stops.last()
        at(a, r.stops.first().first)            // GPS says you're at the low end...
        a.pick(hi.first)                        // ...but you tap the high end on the map
        check(find(a.window.decorView, "Start at ${hi.label}") != null) { "the button should say where you'll start" }
        tap(a, "Start at"); assertEquals(hi.label, a.testCurrent())
        tap(a, "Not home"); assertEquals(r.stops[r.stops.size - 2].label, a.testCurrent())
    }

    @Test fun startingMidRowFollowsYourNextHouseAndNeverJumpsToTheStart() {
        val (a, doors) = start()
        val r = plainRows(doors, 6)[2]
        val s = r.stops; val j = s.size / 2
        at(a, s[j].first)
        a.pick(s[j].first); tap(a, "Start at"); assertEquals(s[j].label, a.testCurrent())
        tap(a, "Not home")
        // you went to the other neighbour instead: from now on the walk goes that way
        val other = if (a.testCurrent() == s[j + 1].label) j - 1 else j + 1
        val step = other - j
        a.pick(s[other].first); tap(a, "Not home")
        var k = other + step
        while (k in s.indices) { assertEquals(s[k].label, a.testCurrent()); tap(a, "Not home"); k += step }
        // that end is done: the nearest open house back the other way, not the far end of the row
        assertEquals(s[j - step].label, a.testCurrent())
    }

    @Test fun finishWhileLockedAsksToUnlockInsteadOfHiding() {
        val (a, doors) = start()
        val r = plainRows(doors, 5).first()
        at(a, r.stops.first().first); a.pick(r.stops.first().first); tap(a, "Start at")
        tap(a, "Not home")
        val km = a.getSystemService(android.app.KeyguardManager::class.java)
        shadowOf(km).setKeyguardLocked(true)
        tap(a, "Finish"); confirm()
        // the app stays on screen over the lock screen until the phone is unlocked
        check(shadowOf(a).getShowWhenLocked()) { "Finish hid the app behind the lock screen" }
        check(find(a.window.decorView, "Not home") == null && find(a.window.decorView, "Finish") == null) { "should be back on the map, not knocking" }
        shadowOf(km).setKeyguardLocked(false)   // you unlock: the waiting request succeeds
        ShadowLooper.idleMainLooper()
        check(!shadowOf(a).getShowWhenLocked()) { "after unlocking, Harvest should stop showing over the lock screen" }
    }
}
