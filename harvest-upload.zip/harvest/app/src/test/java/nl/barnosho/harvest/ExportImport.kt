package nl.barnosho.harvest

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** Export to a file, import it on another phone (or the same one after a reinstall), and the two merge. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w411dp-h891dp-xxhdpi")
class ExportImport {
    private val app get() = ApplicationProvider.getApplicationContext<Application>()
    private fun json(name: String) = JSONArray(javaClass.classLoader!!.getResource(name).readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }
    private val code = "BU01530808"

    /** A phone that has knocked: homes loaded, a few knocks, one of them corrected. */
    private fun phoneA(): Db {
        val a = Db(app, "a.db"); a.set("user", "Aryo"); a.putTerritory(code, "Eekmaat West", "Enschede")
        a.saveAddresses(code, Pdok.buildDoors(code, json("addr.json"), json("vbo.json"), json("nwb.json")))
        val d = a.doors(listOf(code))
        a.record(d[0], Outcome.NOT_HOME, 1, null, null)
        a.record(d[1], Outcome.PRESENTED, 1, null, null)
        a.lastVisitId(d[2].id)                      // nothing yet
        val wrong = a.record(d[2], Outcome.NOT_INTERESTED, 1, null, null); a.void(wrong)
        a.record(d[2], Outcome.SAVED, 2, null, null)
        return a
    }
    private fun export(db: Db) = ByteArrayOutputStream().also { db.exportTo(it) }.toByteArray()
    private fun state(db: Db) = db.doors(listOf(code)).filter { it.outcome != null }.associate { it.id to it.outcome }

    @Test fun anEmptyPhoneGetsEverythingAndWorksOffline() {
        val a = phoneA(); val file = export(a)
        val b = Db(app, "b.db")
        val r = b.importFrom(ByteArrayInputStream(file))
        assertEquals("homes should come along, so it works without going online", a.doors(listOf(code)).size, b.doors(listOf(code)).size)
        check(b.territories().single().imported) { "the neighbourhood should count as loaded" }
        assertEquals(state(a), state(b))
        assertEquals("Aryo", b.user)
        assertEquals("the voided knock must stay voided", a.knockCount(), b.knockCount())
        assertEquals(a.stats(0, onlyMe = false).saved, b.stats(0, onlyMe = false).saved)
        check(r.changed > 0 && r.areas == 1)
        assertEquals("the team code must not travel along", "", b.get("team"))
    }

    @Test fun twoPhonesMergeAndTheNewestChangeWins() {
        val a = phoneA()
        val b = Db(app, "b.db"); b.importFrom(ByteArrayInputStream(export(a)))
        Thread.sleep(5)
        // later, on phone B: a correction of a house A knocked, and a new knock
        val bd = b.doors(listOf(code))
        val corrected = bd[0]; b.void(b.lastVisitId(corrected.id)!!); b.record(corrected, Outcome.TALKED, 1, null, null)
        b.record(bd[5], Outcome.NOT_HOME, 1, null, null)
        // meanwhile on phone A, a knock of its own
        a.record(a.doors(listOf(code))[6], Outcome.NOT_INTERESTED, 1, null, null)
        // swap files both ways
        val fa = export(a); val fb = export(b)
        a.importFrom(ByteArrayInputStream(fb)); b.importFrom(ByteArrayInputStream(fa))
        assertEquals("after swapping files, both phones should agree", state(a), state(b))
        assertEquals(Outcome.TALKED, state(a)[corrected.id])
        // importing the same file again changes nothing
        assertEquals(0, a.importFrom(ByteArrayInputStream(fb)).changed)
    }

    @Test fun anOlderFileDoesNotUndoNewerWorkOrBringBackErasedKnocks() {
        val a = phoneA(); val old = export(a)
        Thread.sleep(5)
        a.eraseKnocks()
        a.importFrom(ByteArrayInputStream(old))
        assertEquals("an old file brought erased test knocks back", 0, a.knockCount())
    }

    @Test fun anythingElseIsRefusedAndNothingChanges() {
        val b = Db(app, "b.db"); b.set("user", "Aryo")
        for (bad in listOf("hello", "{\"app\":\"other\"}", "{\"app\":\"harvest\",\"format\":9,\"tables\":{}}")) {
            val e = runCatching { b.importFrom(ByteArrayInputStream(bad.toByteArray())) }.exceptionOrNull()
            check(e != null) { "accepted: $bad" }
        }
        assertEquals(0, b.territories().size)
    }

    @Test fun setupExportsAndImportsThroughTheFilePicker() {
        MainActivity.autoLoad = false; MainActivity.useMap = false
        val a = phoneA(); val file = java.io.File(app.cacheDir, "in.json").apply { writeBytes(export(a)) }
        val act = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        act.testShow(4); ShadowLooper.idleMainLooper()
        fun press(label: String) {
            fun find(v: android.view.View): android.view.View? {
                if (v is android.widget.TextView && v.text.toString() == label) return v
                if (v is android.view.ViewGroup) for (i in 0 until v.childCount) find(v.getChildAt(i))?.let { return it }
                return null
            }
            find(act.window.decorView)!!.performClick(); ShadowLooper.idleMainLooper()
        }
        // import: the picker opens, you choose the file, the homes and knocks appear
        press("Import data")
        val pick = shadowOf(act).nextStartedActivityForResult
        assertEquals(Intent.ACTION_OPEN_DOCUMENT, pick.intent.action)
        shadowOf(act).receiveResult(pick.intent, Activity.RESULT_OK, Intent().setData(Uri.fromFile(file)))
        val end = System.currentTimeMillis() + 5000
        while (act.testWorkSize() == 0 && System.currentTimeMillis() < end) { ShadowLooper.idleMainLooper(); Thread.sleep(25) }
        check(act.testWorkSize() > 0) { "after importing, the homes didn't appear" }
        // export: the picker asks where to save, the file is written
        val out = java.io.File(app.cacheDir, "out.json")
        act.testShow(4); ShadowLooper.idleMainLooper()
        press("Export data")
        val save = shadowOf(act).nextStartedActivityForResult
        assertEquals(Intent.ACTION_CREATE_DOCUMENT, save.intent.action)
        shadowOf(act).receiveResult(save.intent, Activity.RESULT_OK, Intent().setData(Uri.fromFile(out)))
        val end2 = System.currentTimeMillis() + 5000
        fun done() = org.robolectric.shadows.ShadowToast.getTextOfLatestToast()?.startsWith("Exported") == true
        while (!done() && System.currentTimeMillis() < end2) { ShadowLooper.idleMainLooper(); Thread.sleep(25) }
        check(done()) { "the export never finished: ${org.robolectric.shadows.ShadowToast.getTextOfLatestToast()}" }
        val back = Db(app, "c.db").also { it.importFrom(out.inputStream()) }
        assertEquals(state(a), state(back))
    }
}
