package nl.barnosho.harvest

import android.Manifest
import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.location.Location
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowLooper
import java.io.File

/** Renders the real screens with real Eekmaat West data, so they can be checked without a phone. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w411dp-h891dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class Screens {
    private val out = File("build/screens").apply { mkdirs() }

    private fun json(name: String) = JSONArray(javaClass.classLoader!!.getResource(name).readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }

    private fun seed(): List<Door> {
        val app = ApplicationProvider.getApplicationContext<Application>()
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
        val db = Db(app)
        db.set("user", "Aryo")
        db.putTerritory("BU01530808", "Eekmaat West", "Enschede")
        val doors = Pdok.buildDoors("BU01530808", json("addr.json"), json("vbo.json"), json("nwb.json"))
        db.saveAddresses("BU01530808", doors)
        db.set("work", "BU01530808")   // the working set: where you are
        db.close()
        return doors
    }

    private fun shoot(a: android.app.Activity, name: String) {
        ShadowLooper.idleMainLooper()
        val dlg = ShadowDialog.getLatestDialog()
        val root = if (dlg != null && dlg.isShowing) dlg.window!!.decorView else a.window.decorView
        val w = a.window.decorView.width; val h = a.window.decorView.height
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        a.window.decorView.draw(c)
        if (root !== a.window.decorView) {
            c.drawColor(0x66000000)
            c.save(); c.translate(0f, (h - root.height).toFloat()); root.draw(c); c.restore()
        }
        File(out, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private fun find(v: View, label: String): View? = findExact(v, label) ?: findPrefix(v, label)

    private fun findExact(v: View, label: String): View? {
        if (v is TextView && v.text.toString() == label && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findExact(v.getChildAt(i), label)?.let { return it }
        return null
    }

    private fun findPrefix(v: View, label: String): View? {
        if (v is TextView && v.text.toString().startsWith(label) && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findPrefix(v.getChildAt(i), label)?.let { return it }
        return null
    }

    /** The dialog's own Finish button (its title says "Finish" too). */
    private fun confirm() {
        (ShadowDialog.getLatestDialog() as android.app.AlertDialog).getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick()
        ShadowLooper.idleMainLooper()
    }

    private fun tap(a: android.app.Activity, label: String) {
        val dlg = ShadowDialog.getLatestDialog()
        val v = (if (dlg != null && dlg.isShowing) find(dlg.window!!.decorView, label) else null) ?: find(a.window.decorView, label)
            ?: error("No button '$label'")
        var t: View = v
        while (!t.isClickable && t.parent is View) t = t.parent as View
        t.performClick(); ShadowLooper.idleMainLooper()
    }

    private fun at(a: MainActivity, lat: Double, lon: Double) {
        a.onLocationChanged(Location("gps").apply { latitude = lat; longitude = lon; accuracy = 6f })
        ShadowLooper.idleMainLooper()
    }

    private fun run(mode: String) {
        MainActivity.autoLoad = false; MainActivity.useMap = false
        val doors = seed()
        // neighbourhood figures for Enschede, as the app would fetch them for a city view
        Db(ApplicationProvider.getApplicationContext<Application>()).saveStats(json("cbs.json").mapNotNull { BuurtStat.fromFeature(it) })
        if (mode == "light") File(out, "rows.txt").writeText(Walks.rows(doors).entries.sortedBy { it.key }.joinToString("\n") { (st, rows) ->
            "$st\n" + rows.joinToString("\n") { r -> "   [${r.range}] side ${r.side} sect ${r.sect.substringAfter(':')}: " + r.stops.joinToString(" ") { it.label } }
        } + "\n\nplaced on a street line: ${doors.count { it.sgn != 0 }} of ${doors.size}")
        val a = Robolectric.buildActivity(MainActivity::class.java).setup().get()
        val h10 = doors.first { it.street == "Hoornbladlaan" && it.num == "10" }
        at(a, h10.lat, h10.lon)
        shoot(a, "$mode-1-home")
        // city scale: where to knock
        a.testCity(52.215, 6.92, 13.2); Thread.sleep(1500); ShadowLooper.idleMainLooper(); shoot(a, "$mode-0a-city")
        check(a.testAreasHeld() > 0) { "neighbourhood figures should load for the view" }
        a.testTapArea("BU01530808"); shoot(a, "$mode-0b-city-tapped")
        a.testAreasOff(); ShadowLooper.idleMainLooper()
        check(a.testAreasHeld() == 0) { "switching neighbourhoods off must release them" }
        // choose another street on the map, then back to the suggestion
        a.pick(doors.first { it.street == "Wederiklaan" && it.num == "72" }); shoot(a, "$mode-1b-map-picked")
        a.pick(h10)
        tap(a, "Start at 10"); shoot(a, "$mode-2-knock")
        // tapping a house of the same row on the map makes it the current house
        a.pick(doors.first { it.street == "Hoornbladlaan" && it.num == "14" }); shoot(a, "$mode-2b-tapped-14")
        check(find(a.window.decorView, "14") != null) { "tapping 14 on the map didn't select it" }
        a.pick(h10)
        tap(a, "Not home"); tap(a, "Not home"); tap(a, "Not interested"); shoot(a, "$mode-3-after-taps")
        tap(a, "We talked"); shoot(a, "$mode-4-talked")
        tap(a, "Saved"); shoot(a, "$mode-5-saved-count")
        tap(a, "2"); shoot(a, "$mode-6-after-saved")
        // walk to the end of the row
        repeat(40) { if (find(a.window.decorView, "Not home") != null) tap(a, "Not home") }
        shoot(a, "$mode-7-row-done")
        // second try must walk through the not-home homes once and end, not loop
        tap(a, "Try the")
        var taps = 0
        while (find(a.window.decorView, "No more not-home homes") == null && taps < 40) { tap(a, "Not home"); taps++ }
        shoot(a, "$mode-7b-second-try-done")
        check(find(a.window.decorView, "No more not-home homes") != null) { "second try never ended" }
        File(out, "$mode-second-try.txt").writeText("second try ended after $taps taps")
        tap(a, "Back to new homes")
        // a flat on Esmarkelaan
        val flat = doors.first { it.street == "Esmarkelaan" && it.building != null }
        at(a, flat.lat, flat.lon)
        a.pick(flat); shoot(a, "$mode-8a-switch-offer"); tap(a, "Switch to")
        shoot(a, "$mode-8-esmarkelaan")
        if (find(a.window.decorView, "Go inside") == null) {
            repeat(30) { if (find(a.window.decorView, "Go inside") == null && find(a.window.decorView, "Not home") != null) tap(a, "Not home") }
        }
        shoot(a, "$mode-9-flat")
        tap(a, "Go inside"); shoot(a, "$mode-10-inside")
        // streets numbered consecutively along one side
        for (st in listOf("Lisdoddelaan", "Pitruslaan")) {
            val d = doors.filter { it.street == st }.minBy { it.pos }
            at(a, d.lat, d.lon)
            a.pick(d); tap(a, "Switch to")
            shoot(a, "$mode-11-$st")
        }
        tap(a, "Finish"); confirm(); shoot(a, "$mode-12-home-after")
    }

    @Test fun light() = run("light")
    @Test @Config(qualifiers = "+night") fun dark() = run("dark")
}
