package nl.barnosho.harvest

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/**
 * Live reproduction of "it always sends me to Gronausestraat": Eekmaat West plus the neighbourhoods the app loads
 * around it, the old next-row formula against the new rule, for every row in Eekmaat West.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class NextRowCheck {
    @Test fun nextRowStaysCoherent() {
        val la = 52.2135; val lo = 6.9489   // Hoornbladlaan
        val near = Pdok.buurtenIn(la - 0.0055, lo - 0.009, la + 0.0055, lo + 0.009)
        val doors = near.flatMap { Pdok.addresses(it.code) }
        val stats = Pdok.stats(la - 0.02, lo - 0.03, la + 0.02, lo + 0.03).associateBy { it.code }
        val rows = Walks.rows(doors)
        val names = near.associate { it.code to it.name }
        fun stopScore(s: Stop) = Receptivity.stop(s, Receptivity.buurt(stats[s.first.territory], null))
        fun rowScore(r: Row) = r.stops.filter { st -> st.doors.any { it.isNew } }.maxOfOrNull { stopScore(it) } ?: 0
        fun oldNext(cur: Row, end: Stop): Row? {
            var best: Row? = null; var bestD = Double.MAX_VALUE
            for (r in rows.values.flatten()) {
                if (r.key == cur.key) continue
                val s = r.stops.filter { st -> st.doors.any { it.isNew } }.minByOrNull { end.dist(it) } ?: continue
                val d = end.dist(s) * (if (r.street == cur.street) 0.5 else 1.0) + (100 - rowScore(r)) * 10.0
                if (d < bestD) { bestD = d; best = r }
            }
            return best
        }
        val lines = ArrayList<String>()
        lines += "loaded: " + near.joinToString { "${it.name} (${doors.count { d -> d.territory == it.code }} homes)" }
        val mine = rows.values.flatten().filter { Next.area(it) == "BU01530808" && it.stops.size >= 2 }
        var oldOut = 0; var oldGronau = 0; var newOut = 0; var newFar = 0; var across = 0
        val oldTargets = HashMap<String, Int>()
        for (cur in mine) {
            val end = cur.stops.last()
            val o = oldNext(cur, end)
            if (o != null) {
                if (Next.area(o) != "BU01530808") oldOut++
                if (o.street == "Gronausestraat") oldGronau++
                oldTargets.merge("${o.street} ${o.range} [${names[Next.area(o)]}]", 1, Int::plus)
            }
            val n = Next.choose(rows.values, cur, end, emptySet())
            if (n != null) {
                if (Next.area(n.row) != "BU01530808") newOut++
                if (n.row.facing(cur)) across++
                if (n.metres > 250) newFar++
            }
        }
        lines += "rows in Eekmaat West: ${mine.size}"
        lines += "OLD: next row outside Eekmaat West for $oldOut rows, Gronausestraat for $oldGronau"
        lines += "OLD most chosen: " + oldTargets.entries.sortedByDescending { it.value }.take(4).joinToString { "${it.key} x${it.value}" }
        lines += "NEW: outside the neighbourhood $newOut, across the street $across, further than 250 m $newFar"
        // a few concrete cases
        for (cur in mine.filter { it.street in listOf("Hoornbladlaan", "Wederiklaan", "Lisdoddelaan") }.take(5)) {
            val n = Next.choose(rows.values, cur, cur.stops.last(), emptySet())
            lines += "  after ${cur.street} ${cur.range}: " + (n?.let { "${it.row.street} ${it.row.range}, ${it.metres.toInt()} m" + if (it.row.facing(cur)) " (across)" else "" } ?: "neighbourhood done")
        }
        File("build/screens").mkdirs(); File("build/screens/nextrow.txt").writeText(lines.joinToString("\n"))
        check(newOut == 0) { "the next row must stay in the neighbourhood" }
    }
}
