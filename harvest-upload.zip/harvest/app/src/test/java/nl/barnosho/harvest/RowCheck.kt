package nl.barnosho.harvest

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/** Live: how the app forms rows on the Deventer streets where 159–165 and 144–148 meet. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class RowCheck {
    @Test fun deventerRows() {
        val buurten = listOf("BU01500602", "BU01500302", "BU01500406", "BU01500304")   // Tuindorp, Zwolseweg, Rielerweg-Oost, Zandweerd-Zuid
        val streets = setOf("Nilantstraat", "Hoge Hondstraat", "Zwolseweg", "Rielerweg", "Johannes van Vlotenlaan")
        val lines = ArrayList<String>()
        val doors = buurten.flatMap { Pdok.addresses(it) }
        File("build/screens").mkdirs()
        File("build/screens/deventer_doors.tsv").writeText(doors.joinToString("\n") { "${it.street}\t${it.num}\t${it.lat}\t${it.lon}\t${it.sect}\t${it.pos}\t${it.sgn}\t${it.building ?: ""}\t${it.territory}" })
        val rows = Walks.rows(doors)
        for (st in streets) {
            val rs = rows[st] ?: continue
            lines += st
            for (r in rs) {
                val nums = r.stops.map { it.label }
                if (nums.none { s -> s.takeWhile(Char::isDigit).toIntOrNull()?.let { it in 130..175 } == true }) continue
                lines += "   [${r.range}] sect ${r.sect.substringAfter(':')} side ${r.side}: " + r.stops.joinToString(" ") { s -> "${s.label}@${s.first.pos.toInt()}" }
            }
        }
        // the reported case: 159 belongs with 161–165; 144–148 don't
        val nil = rows.getValue("Nilantstraat")
        val r161 = nil.first { r -> r.stops.any { it.label == "161" } }
        lines += "Nilantstraat 161 is in [${r161.range}], 159 there: ${r161.stops.any { it.label == "159" }}, 144 there: ${r161.stops.any { it.label == "144" }}"
        // across all four neighbourhoods: rows of one house, and rows mixing odd and even on a two-sided street
        val all = rows.values.flatten()
        lines += "all rows: ${all.size}, single-home rows: ${all.count { it.stops.size == 1 }}, mixed odd/even rows: ${all.count { r -> r.side != "c" && r.stops.map { numOf(it.first) % 2 }.toSet().size > 1 }}"
        File("build/screens/rowcheck.txt").writeText(lines.joinToString("\n"))
        check(r161.stops.any { it.label == "159" } && r161.stops.none { it.label == "144" }) { "Nilantstraat: 159 must join 161, 144 must not" }
    }
}
