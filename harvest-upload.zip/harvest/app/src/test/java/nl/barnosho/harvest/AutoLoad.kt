package nl.barnosho.harvest

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

/** Live check against PDOK: the map's view finds its neighbourhoods, and those neighbourhoods load homes. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class AutoLoad {
    @Test fun neighbourhoodsInViewLoad() {
        // the area in the screen recording: Eekmaat West and the streets north of the Gronausestraat
        val found = Pdok.buurtenIn(52.208, 6.935, 52.222, 6.962)
        val lines = ArrayList<String>()
        lines += "in view: " + found.joinToString { "${it.name} (${it.code})" }
        check(found.any { it.code == "BU01530808" }) { "Eekmaat West not found" }
        for (b in found.filter { it.code != "BU01530808" }.take(3)) {
            val doors = Pdok.addresses(b.code)
            lines += "${b.name}: ${doors.size} homes, ${doors.count { it.sgn != 0 }} on a street line, ${doors.mapNotNull { it.building }.toSet().size} flats"
            check(doors.isNotEmpty()) { "${b.name} loaded no homes" }
        }
        // receptivity: Deventer's neighbourhoods ranked from the live CBS figures, through the app's own model
        val dev = Pdok.stats(52.22, 6.10, 52.29, 6.25).filter { it.gemeente == "Deventer" }
        val ranked = dev.filter { it.score != null }.sortedByDescending { it.score }
        lines += "Deventer: ${dev.size} neighbourhoods, ${ranked.size} scored, outline points kept: ${dev.sumOf { s -> s.rings.sumOf { it.size / 2 } }}"
        lines += "  top: " + ranked.take(6).joinToString { "${it.name} ${it.score}" }
        lines += "  bottom: " + ranked.takeLast(4).joinToString { "${it.name} ${it.score}" }
        lines += "  unknown: " + dev.filter { it.score == null }.joinToString { it.name }
        check(ranked.first().score!! > 55 && ranked.last().score!! < 15)
        // flats in a promising Deventer neighbourhood: building years and care buildings come through
        val ok = ranked.first()
        val flatDoors = Pdok.addresses(ok.code).filter { it.building != null }
        val bySite = flatDoors.groupBy { it.building }
        lines += "${ok.name}: ${bySite.size} flat buildings; years " + bySite.values.map { it.first().built }.sorted().joinToString(",") +
            "; care: ${bySite.values.count { it.first().care }}"
        val here = Pdok.buurtAt(52.2135, 6.9489)
        lines += "standing at Hoornbladlaan: ${here?.name}"
        File("build/screens").mkdirs(); File("build/screens/autoload.txt").writeText(lines.joinToString("\n"))
    }
}
