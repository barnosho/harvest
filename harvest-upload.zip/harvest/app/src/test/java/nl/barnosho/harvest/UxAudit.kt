package nl.barnosho.harvest

import android.Manifest
import android.app.Application
import android.location.Location
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowLooper

/** The interface audit in docs/UX_AUDIT.md: one test per change (U1–U6). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w411dp-h891dp-xxhdpi")
class UxAudit {
    private val app get() = ApplicationProvider.getApplicationContext<Application>()
    private fun json(name: String) = JSONArray(javaClass.classLoader!!.getResource(name).readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }

    private fun seed(): List<Door> {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
        val db = Db(app)
        db.set("user", "Aryo"); db.putTerritory("BU01530808", "Eekmaat West", "Enschede")
        val doors = Pdok.buildDoors("BU01530808", json("addr.json"), json("vbo.json"), json("nwb.json"))
        db.saveAddresses("BU01530808", doors); db.set("work", "BU01530808"); db.close()
        return doors
    }
    private fun launch(): MainActivity {
        MainActivity.autoLoad = false; MainActivity.useMap = false
        return Robolectric.buildActivity(MainActivity::class.java).setup().get()
    }
    private fun findBy(v: View, ok: (String) -> Boolean): View? {
        if (v is TextView && v !is EditText && ok(v.text.toString()) && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findBy(v.getChildAt(i), ok)?.let { return it }
        return null
    }
    private fun find(v: View, label: String) = findBy(v) { it == label } ?: findBy(v) { it.startsWith(label) }
    private fun root(a: android.app.Activity): View {
        val dlg = ShadowDialog.getLatestDialog()
        return if (dlg != null && dlg.isShowing) dlg.window!!.decorView else a.window.decorView
    }
    private fun tap(a: android.app.Activity, label: String): View {
        val v = find(root(a), label) ?: find(a.window.decorView, label) ?: error("No button '$label'")
        var t: View = v
        while (!t.isClickable && t.parent is View) t = t.parent as View
        t.performClick(); ShadowLooper.idleMainLooper()
        return t
    }
    private fun at(a: MainActivity, d: Door) {
        a.onLocationChanged(Location("gps").apply { latitude = d.lat; longitude = d.lon; accuracy = 6f }); ShadowLooper.idleMainLooper()
    }
    private fun startAt(a: MainActivity, d: Door) { at(a, d); a.pick(d); tap(a, "Start at") }
    private fun plainRow(doors: List<Door>) = Walks.rows(doors).values.flatten().first { r -> r.stops.size >= 5 && r.stops.none { it.isBuilding } }

    @Test fun u1_everyOutcomeConfirmsByTouch() {
        val doors = seed(); val a = launch()
        val r = plainRow(doors)
        startAt(a, r.stops[0].first)
        tap(a, "We talked")
        val presented = tap(a, "Gospel presented")
        assertEquals("Gospel presented gave no buzz", HapticFeedbackConstants.CONFIRM, shadowOf(presented).lastHapticFeedbackPerformed())
        tap(a, "We talked"); tap(a, "Saved")
        val one = tap(a, "1")
        assertEquals("Saved gave no buzz", HapticFeedbackConstants.CONFIRM, shadowOf(one).lastHapticFeedbackPerformed())
    }

    @Test fun u2_everyControlOnTheKnockPanelIsAFullThumbTarget() {
        val doors = seed(); val a = launch()
        val r = plainRow(doors)
        startAt(a, r.stops[0].first)
        tap(a, "Not interested")                    // so the status line is a "change" link too
        val density = a.resources.displayMetrics.density
        val small = ArrayList<String>()
        fun walk(v: View) {
            if (!v.isShown) return
            if (v.hasOnClickListeners() && v.isClickable) {
                val dp = v.height / density
                val label = (v as? TextView)?.text?.toString() ?: v.javaClass.simpleName
                println("target %-40s %5.1f dp".format(label.take(40), dp))
                if (dp < 47.5f) small += "$label (${dp.toInt()} dp)"
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(a.window.decorView)
        check(small.isEmpty()) { "tap targets under 48 dp: $small" }
    }

    @Test fun u3_insideAFlatTheHintDoesNotSendYouToTheMap() {
        val doors = seed(); val a = launch()
        val flat = Walks.rows(doors).values.flatten().flatMap { it.stops }.first { it.isBuilding }
        startAt(a, flat.first)
        tap(a, "Go inside")
        check(find(a.window.decorView, "Not this house? Tap it on the map") == null) { "inside a flat it still says to tap the map" }
        check(find(a.window.decorView, "Not this home? Use") != null)
    }

    @Test fun u4_theMoreSheetPutsSkipFirstAndDontKnockLast() {
        val doors = seed(); val a = launch()
        val r = plainRow(doors)
        startAt(a, r.stops[0].first)
        tap(a, "More")
        val sheet = ShadowDialog.getLatestDialog().window!!.decorView
        val labels = ArrayList<String>()
        fun walk(v: View) { if (v is TextView && v.isClickable) labels += v.text.toString(); if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i)) }
        walk(sheet)
        check(labels.first().startsWith("Skip")) { "first choice: ${labels.first()}" }
        check(labels.last().startsWith("Don't knock")) { "last choice: ${labels.last()}" }
    }

    @Test fun u5_theLastHouseIsOneTapAwayToChangeItEvenAfterTheWalkTurned() {
        val doors = seed(); val a = launch()
        val r = plainRow(doors); val s = r.stops
        startAt(a, s[1].first)                      // second from the bottom: the walk goes up, the longer way
        tap(a, "Not home")                          // that house; now at s[2]
        a.pick(s[0].first)                          // you went to the bottom house instead
        tap(a, "Not interested")                    // recorded by mistake; nothing left that way, so the walk turns round
        val wrong = s[0].first
        val here = a.testCurrent()
        assertEquals(s[2].label, here)              // and ‹ from here leads to s[1], not to the house to correct
        tap(a, "${wrong.num}: Not interested")       // the line reads "<num>: Not interested  ·  change"
        assertEquals("change didn't take you back to the house you just did", wrong.num, a.testCurrent())
        tap(a, "Not home")                          // the right outcome
        assertEquals(Outcome.NOT_HOME, a.testDoor(wrong.id)?.outcome)
        assertEquals("after the correction you should be back where you were", here, a.testCurrent())
    }

    @Test fun u6_negativeAndPositiveButtonsHaveRoomBetweenThem() {
        val doors = seed(); val a = launch()
        startAt(a, plainRow(doors).stops[0].first)
        val ni = find(a.window.decorView, "Not interested")!!; val wt = find(a.window.decorView, "We talked")!!
        val p1 = IntArray(2).also { ni.getLocationOnScreen(it) }; val p2 = IntArray(2).also { wt.getLocationOnScreen(it) }
        val gap = (p2[0] - (p1[0] + ni.width)) / a.resources.displayMetrics.density
        check(gap >= 8f) { "only ${gap} dp between Not interested and We talked" }
    }
}
