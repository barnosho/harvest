package nl.barnosho.harvest

import android.Manifest
import android.app.Application
import android.location.Location
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ActivityController
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowDialog
import org.robolectric.shadows.ShadowLooper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * One test per confirmed bug in docs/STATE_MACHINES.md (issue numbers match). Each fails on the code before the fix.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w411dp-h891dp-xxhdpi")
class StateMachines {
    private val app get() = ApplicationProvider.getApplicationContext<Application>()
    private fun json(name: String) = JSONArray(javaClass.classLoader!!.getResource(name).readText()).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }
    private fun built() = Pdok.buildDoors("BU01530808", json("addr.json"), json("vbo.json"), json("nwb.json"))

    /** imported = false: the neighbourhood is known but its homes still have to be loaded. */
    private fun seed(imported: Boolean = true, user: String = "Aryo"): List<Door> {
        shadowOf(app).grantPermissions(Manifest.permission.ACCESS_FINE_LOCATION)
        val db = Db(app)
        db.set("user", user); db.putTerritory("BU01530808", "Eekmaat West", "Enschede")
        val doors = built()
        if (imported) db.saveAddresses("BU01530808", doors)
        db.set("work", "BU01530808"); db.close()
        return doors
    }

    @After fun reset() {
        MainActivity.addressSource = { Pdok.addresses(it) }
        MainActivity.syncRunner = { Sync.run(it) }
    }

    private fun launch(): ActivityController<MainActivity> {
        MainActivity.autoLoad = false; MainActivity.useMap = false
        return Robolectric.buildActivity(MainActivity::class.java).setup()
    }

    // ---------- small helpers ----------
    /** An exact label wins over one that only starts with it ("Not home" the button, not "Not home before"). */
    private fun find(v: View, label: String): View? = findBy(v) { it == label } ?: findBy(v) { it.startsWith(label) }
    private fun findBy(v: View, ok: (String) -> Boolean): View? {
        if (v is TextView && v !is EditText && ok(v.text.toString()) && v.isShown) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findBy(v.getChildAt(i), ok)?.let { return it }
        return null
    }
    private fun field(v: View, hint: String): EditText? {
        if (v is EditText && v.hint?.toString() == hint) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) field(v.getChildAt(i), hint)?.let { return it }
        return null
    }
    private fun tap(a: android.app.Activity, label: String) {
        val dlg = ShadowDialog.getLatestDialog()
        val v = (if (dlg != null && dlg.isShowing) find(dlg.window!!.decorView, label) else null) ?: find(a.window.decorView, label)
            ?: error("No button '$label'")
        var t: View = v
        while (!t.isClickable && t.parent is View) t = t.parent as View
        t.performClick(); ShadowLooper.idleMainLooper()
    }
    private fun confirm() {
        (ShadowDialog.getLatestDialog() as android.app.AlertDialog).getButton(android.app.AlertDialog.BUTTON_POSITIVE).performClick()
        ShadowLooper.idleMainLooper()
    }
    private fun at(a: MainActivity, d: Door) {
        a.onLocationChanged(Location("gps").apply { latitude = d.lat; longitude = d.lon; accuracy = 6f }); ShadowLooper.idleMainLooper()
    }
    private fun plainRows(doors: List<Door>, n: Int) = Walks.rows(doors).values.flatten()
        .filter { r -> r.stops.size >= n && r.stops.none { it.isBuilding } }.distinctBy { it.street }
    /** Background threads post to the main thread: keep running it until `done` or the time is up. */
    private fun waitFor(ms: Long = 5000, done: () -> Boolean): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) { ShadowLooper.idleMainLooper(); if (done()) return true; Thread.sleep(25) }
        ShadowLooper.idleMainLooper(); return done()
    }
    private fun startAt(a: MainActivity, d: Door) { at(a, d); a.pick(d); tap(a, "Start at") }

    // ---------- 1. late background results after the activity is gone ----------
    @Test fun issue1_aReloadFinishingAfterRecreateNeverReachesTheOldMap() {
        seed()
        val c = launch(); val a = c.get()
        val snap = a.testSnapshot()                 // a reload is under way...
        c.pause().stop().destroy()                  // ...when the dark-mode switch at sunset recreates the activity
        a.testDeliver(snap)                         // its result arrives
        ShadowLooper.idleMainLooper()
        // On a phone, MapLibre throws on every call to a destroyed map (Style.validateState): that was a crash
        assertEquals("the destroyed activity still pushed data into its destroyed map", 0, a.testMapLateCalls())
    }

    // ---------- 2. where you are in the row survives a recreate or process death ----------
    @Test fun issue2_yourHouseAndSkipsSurviveARecreate() {
        val doors = seed()
        var c = launch(); var a = c.get()
        val r = plainRows(doors, 6)[2]; val s = r.stops; val j = s.size / 2
        startAt(a, s[j].first)
        tap(a, "Not home"); tap(a, "Not home")
        val skippedLabel = a.testCurrent()!!
        tap(a, "More"); tap(a, "Skip")                // skip this one for now
        val here = a.testCurrent()!!
        assertNotEquals(skippedLabel, here)
        c = c.recreate(); a = c.get(); ShadowLooper.idleMainLooper()
        assertEquals("after a recreate the walk jumped elsewhere in the row", here, a.testCurrent())
        // the skipped house still waits until the end
        tap(a, "Not home")
        assertNotEquals("a skipped house came back straight away after the recreate", skippedLabel, a.testCurrent())
    }

    @Test fun issue2_withNothingSelectedTheWalkContinuesFromTheLastHouse() {
        val doors = seed()
        var c = launch(); var a = c.get()
        val r = plainRows(doors, 6)[2]; val s = r.stops; val j = s.size / 2
        startAt(a, s[j].first)
        tap(a, "Not home"); tap(a, "Not home")
        val here = a.testCurrent()!!
        Db(app).apply { set("sel", "") }           // as saved by 1.14 and earlier: no current house stored
        c = c.recreate(); a = c.get(); ShadowLooper.idleMainLooper()
        assertEquals("without a stored house the walk restarted at the end of the row", here, a.testCurrent())
    }

    // ---------- 3. a reload that read before your tap must not undo it ----------
    @Test fun issue3_aStaleReloadDoesNotPutAKnockedHouseBack() {
        val doors = seed()
        val c = launch(); val a = c.get()
        val r = plainRows(doors, 5).first()
        val first = r.stops.first().first
        startAt(a, first)
        val snap = a.testSnapshot()                 // a sync brought teammates' knocks; the reload is reading...
        tap(a, "Not home")                          // ...and you tap meanwhile
        val next = a.testCurrent()
        a.testDeliver(snap)                         // the read from before your tap arrives
        waitFor(800) { false }                      // and the fresh read it asks for
        assertEquals("the house you just recorded went back to open", Outcome.NOT_HOME, a.testDoor(first.id)?.outcome)
        assertEquals("the walk was sent back to the house you just did", next, a.testCurrent())
    }

    // ---------- 4. a failed import tries again by itself ----------
    @Test fun issue4_aFailedImportRetriesWithoutLeavingTheArea() {
        seed(imported = false)
        val calls = AtomicInteger()
        val doors = built()
        MainActivity.addressSource = { if (calls.incrementAndGet() == 1) throw java.io.IOException("no connection") else doors }
        val c = launch(); val a = c.get()
        check(waitFor { calls.get() == 1 }) { "the first import never ran" }
        waitFor(500) { false }
        assertEquals(0, a.testWorkSize())
        // you stay where you are (no new working set); time passes
        for (i in 0 until 12) { ShadowLooper.idleMainLooper(10, TimeUnit.SECONDS); if (calls.get() > 1) break }
        check(waitFor { a.testWorkSize() > 0 }) { "after a failure the neighbourhood never loaded again (tries: ${calls.get()})" }
    }

    // ---------- 5. leaving knock mode ----------
    @Test fun issue5_cancellingTheUnlockKeepsTheAppUntilTheScreenGoesOff() {
        val doors = seed()
        val c = launch(); val a = c.get()
        val r = plainRows(doors, 5).first()
        startAt(a, r.stops.first().first); tap(a, "Not home")
        val km = a.getSystemService(android.app.KeyguardManager::class.java)
        shadowOf(km).setKeyguardLocked(true)
        tap(a, "Finish"); confirm()
        shadowOf(km).setKeyguardLocked(true)        // the unlock request is cancelled (back on the bouncer, or replaced)
        ShadowLooper.idleMainLooper()
        check(shadowOf(a).getShowWhenLocked()) { "cancelling the unlock hid the app you were looking at" }
        c.pause().stop()
        check(!shadowOf(a).getShowWhenLocked()) { "once off screen, the planning map must not show over the lock screen" }
    }

    @Test fun issue5_aWalkLeftOverFromEarlierEndsWhenYouComeBack() {
        val doors = seed()
        val c = launch(); val a = c.get()
        val r = plainRows(doors, 5).first()
        startAt(a, r.stops.first().first); tap(a, "Not home")
        c.pause().stop()
        Db(app).set("walkAt", "${System.currentTimeMillis() - 9 * 3_600_000L}")   // you went home without Finish
        c.restart().resume(); ShadowLooper.idleMainLooper()
        check(!a.testKnocking()) { "a walk from 9 hours ago was still on" }
        check(!shadowOf(a).getShowWhenLocked()) { "yesterday's walk still showed over the lock screen" }
        val claim = Db(app).readableDatabase.rawQuery("SELECT street FROM claim WHERE id=?", arrayOf("Aryo")).use { if (it.moveToFirst()) it.getString(0) else "" }
        assertEquals("the street claim should be released", "", claim)
    }

    // ---------- 6. team sync ----------
    @Test fun issue6_syncIsNotStuckBehindALongImport() {
        seed(imported = false)
        val release = CountDownLatch(1)
        val doors = built()
        MainActivity.addressSource = { release.await(20, TimeUnit.SECONDS); doors }   // a slow neighbourhood import
        val synced = AtomicInteger()
        MainActivity.syncRunner = { synced.incrementAndGet(); Sync.Result(0, 0) }
        Db(app).apply { set("server", "https://example.invalid"); set("team", "abc") }
        val c = launch(); val a = c.get()
        a.testSyncNow()
        val ran = waitFor(3000) { synced.get() > 0 }
        release.countDown()
        check(ran) { "sync waited behind the import" }
    }

    @Test fun issue6_aSyncForTheOldTeamCannotMoveTheNewTeamsPosition() {
        val db = Db(app)
        db.setTeam("https://a.example", "A")
        db.setTeam(null, "")                        // you leave team A while its sync is under way
        db.setTeam("https://b.example", "B")        // and join team B
        check(!db.commitPull("A", 999)) { "team A's sync was allowed to commit" }
        assertEquals("team B would skip its first 999 events", "0", db.get("since"))
        check(db.commitPull("B", 7)); assertEquals("7", db.get("since"))
    }

    @Test fun issue6_joiningATeamNeedsYourOwnName() {
        seed(user = "Me")
        MainActivity.syncRunner = { Sync.Result(0, 0) }
        val c = launch(); val a = c.get()
        a.testShow(4); ShadowLooper.idleMainLooper()
        field(a.window.decorView, "Invite")!!.setText("harvest:https://harvest.example.workers.dev#abcdef")
        tap(a, "Join team")
        assertEquals("joined a team as \"Me\"", "", Db(app).get("team"))
        field(a.window.decorView, "Name")!!.setText("Aryo")
        tap(a, "Join team")
        assertEquals("abcdef", Db(app).get("team"))
        assertEquals("Aryo", Db(app).user)
    }

    // ---------- 7. a second try is one pass, also across rows ----------
    @Test fun issue7_switchingRowsDuringASecondTryDoesNotBringBackHomesAlreadyTried() {
        val doors = seed()
        val c = launch(); val a = c.get()
        val (ra, rb) = plainRows(doors, 5).let { it[0] to it[1] }
        startAt(a, ra.stops.first().first)
        while (a.testCurrent() != null) tap(a, "Not home")
        at(a, rb.stops.first().first); a.pick(rb.stops.first().first); tap(a, "Switch to")
        while (a.testCurrent() != null) tap(a, "Not home")
        tap(a, "Try the")
        val tried = doors.first { it.street == rb.street && it.num == a.testCurrent() }
        tap(a, "Not home")                          // tried again, still not home: done for this pass
        check(!a.testPending(tried.id))
        val other = ra.stops.first().first
        Thread.sleep(5)                             // a later moment than the retry above
        a.pick(other); tap(a, "Switch to")          // over to the other row's not-home homes
        check(a.testPending(other.id))
        check(!a.testPending(tried.id)) { "switching rows restarted the second try: ${tried.num} came back" }
    }

    // ---------- 8. follow-up "Map" ----------
    @Test fun issue8_theFollowUpMapPickSurvivesAReload() {
        val doors = seed()
        val c = launch(); val a = c.get()
        val r = plainRows(doors, 5)[1]
        val d = r.stops[1].first
        startAt(a, d)
        tap(a, "We talked"); tap(a, "Come back later"); tap(a, "Tomorrow")
        tap(a, "Finish"); confirm()
        // you look at another street on the map first, so "snapping back" would land somewhere visibly different
        val elsewhere = plainRows(doors, 5)[3]
        a.pick(elsewhere.stops.first().first)
        assertNotEquals(r.key, a.testPickKey())
        a.testShow(2); ShadowLooper.idleMainLooper()
        // the card's "Map" button (the tab bar has a "Map" too, but there the whole cell is the button)
        fun mapButton(v: View): View? {
            if (v is TextView && v.text.toString() == "Map" && v.hasOnClickListeners()) return v
            if (v is ViewGroup) for (i in 0 until v.childCount) mapButton(v.getChildAt(i))?.let { return it }
            return null
        }
        mapButton(a.window.decorView)!!.performClick(); ShadowLooper.idleMainLooper()
        val picked = a.testPickKey()
        assertEquals(r.key, picked)
        a.testDeliver(a.testSnapshot())             // any reload: an import, a teammate's knocks
        assertEquals("a reload snapped the map back to another street", picked, a.testPickKey())
    }
}
