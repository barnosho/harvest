plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "nl.barnosho.harvest"
    compileSdk = 35
    defaultConfig {
        applicationId = "nl.barnosho.harvest"
        minSdk = 26
        targetSdk = 35
        versionCode = 18
        versionName = "1.17"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }   // phones only: keeps the app small
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("harvest.jks"); storePassword = "harvest"
            keyAlias = "harvest"; keyPassword = "harvest"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("fixed") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests { isIncludeAndroidResources = true; all { it.maxHeapSize = "1200m"; it.jvmArgs("--add-opens=java.base/java.io=ALL-UNNAMED") } } }
}
dependencies {
    implementation("org.maplibre.gl:android-sdk:12.3.1")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
    testImplementation("androidx.test:core:1.6.1")
}
