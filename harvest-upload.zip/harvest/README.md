# Harvest

Aryo's Android app for door-to-door outreach: an OpenStreetMap map of the homes around you, one-tap knock recording, walking order that follows you along a row, flats, second tries, team sync, stats, and export/import of all data.

Package `nl.barnosho.harvest`, Kotlin, no AndroidX, MapLibre for the map. Minimum Android 8, targets Android 15.

## Build

Needs JDK 17 and the Android SDK (platform 35, build-tools 35.0.0). Set `sdk.dir` in `local.properties` or `ANDROID_HOME`.

```
./gradlew assembleRelease          # app/build/outputs/apk/release/app-release.apk
./gradlew testDebugUnitTest        # all tests (Robolectric), a few minutes
```

## Signing: keep this repo private

`app/harvest.jks` is the signing key. It's committed on purpose: an update only installs over the existing app when it's signed with the same key, so every build, from any machine or chat, must use it. That's also why this repository must stay private.

## Install on the phone

APK files aren't stored on the phone; install over adb, keeping data:

```
adb install -r app/build/outputs/apk/release/app-release.apk
```

If the install is silently blocked, Samsung Auto Blocker is on: turn it off, install, turn it back on.

## Where things are

- `docs/STATE_MACHINES.md`: every piece of app state, its rules and transitions, and the bugs found and fixed. Read this before changing the knocking flow.
- `docs/UX_AUDIT.md`: the interface audit with tap counts per task.
- `app/src/main/java/nl/barnosho/harvest/`:
  - `MainActivity.kt`: screens and the knocking flow.
  - `Db.kt`: database, sync rules, export/import.
  - `Net.kt`: PDOK address import and team sync.
  - `Walks.kt`: rows and walking order.
  - `MapLayer.kt`: the map.
  - `Ui.kt`: colours and controls.
- `app/src/test/`: tests. `StateMachines.kt`, `UxAudit.kt` and `ExportImport.kt` are each tied to the docs.

## Working on it with Claude

Start each new chat or Claude Code session from this repository, not from an old zip. When you change something, keep `docs/STATE_MACHINES.md` current, bump `versionCode`/`versionName` in `app/build.gradle.kts`, run the tests, and commit.
